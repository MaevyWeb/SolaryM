-- SolaryM_VersionCheck.lua
-- Version check raid + guilde
-- Affiche tout le monde : ceux qui ont l'addon ET ceux qui ne l'ont pas

SM.VersionCheck = SM.VersionCheck or {}
local VC = SM.VersionCheck

local AceComm   = LibStub and LibStub("AceComm-3.0", true)
local VC_PREFIX = "SolaryMVC"

-- Normalise un nom (retire le realm si présent)
local function NormName(name)
    if not name then return nil end
    return (name:match("^([^%-]+)")) or name
end

VC.responses  = {}   -- [name] = version string
VC.allMembers = {}   -- [name] = true (tous les membres du raid/guilde au moment de la requête)
VC.requestTime = nil
VC.waitTimer   = nil

-- ============================================================
-- COLLECTE DES MEMBRES
-- ============================================================
local function CollectRaidMembers()
    local members = {}
    local n = GetNumGroupMembers()
    if IsInRaid() then
        for i = 1, n do
            local name = NormName(UnitName("raid"..i))
            if name then members[name] = true end
        end
    elseif IsInGroup() then
        for i = 1, n-1 do
            local name = NormName(UnitName("party"..i))
            if name then members[name] = true end
        end
        local me = NormName(UnitName("player"))
        if me then members[me] = true end
    end
    return members
end

local function CollectGuildMembers()
    local members = {}
    if not IsInGuild() then return members end
    local n = GetNumGuildMembers()
    for i = 1, n do
        local name, _, _, _, _, _, _, _, online = GetGuildRosterInfo(i)
        if name and online then
            name = name:match("^([^%-]+)") or name
            members[name] = true
        end
    end
    return members
end

-- ============================================================
-- ENVOI / RÉCEPTION
-- ============================================================
function VC.SendRequest()
    if not AceComm then SM.Print("AceComm introuvable."); return end

    wipe(VC.responses)
    VC.requestTime = GetTime()

    -- S'inclure soi-même
    local me = NormName(UnitName("player"))
    if me then VC.responses[me] = SM.VERSION end

    -- Annuler le timer précédent
    if VC.waitTimer then VC.waitTimer:Cancel(); VC.waitTimer = nil end

    -- Collecter tous les membres avec leur source
    VC.allMembers  = {}  -- [name] = "raid" | "guild"
    local raidMembers  = CollectRaidMembers()
    local guildMembers = CollectGuildMembers()
    for name in pairs(raidMembers)  do VC.allMembers[name] = "raid"  end
    for name in pairs(guildMembers) do
        if not VC.allMembers[name] then VC.allMembers[name] = "guild" end
    end
    if me then VC.allMembers[me] = VC.allMembers[me] or "raid" end

    -- Broadcast : RAID en priorité (fonctionne en Midnight), GUILD en complément
    if IsInRaid() then
        AceComm:SendCommMessage(VC_PREFIX, "VER_REQUEST", "RAID")
    elseif IsInGroup() then
        AceComm:SendCommMessage(VC_PREFIX, "VER_REQUEST", "PARTY")
    end
    if IsInGuild() then
        AceComm:SendCommMessage(VC_PREFIX, "VER_REQUEST", "GUILD")
    end

    -- Refresh immédiat puis après 5s (laisser le temps aux réponses d'arriver)
    if VC.RefreshUI then VC.RefreshUI() end
    VC.waitTimer = C_Timer.NewTimer(5, function()
        VC.waitTimer = nil
        if VC.RefreshUI then VC.RefreshUI() end
    end)
end

function VC.SendReply(channel)
    if not AceComm then return end
    local me = NormName(UnitName("player")) or ""
    AceComm:SendCommMessage(VC_PREFIX, "VER_REPLY:"..me..":"..SM.VERSION, channel)
end

local function OnVCMessage(prefix, message, distribution, sender)
    if prefix ~= VC_PREFIX then return end
    local myName = UnitName("player")

    if message == "VER_REQUEST" then
        if NormName(sender) ~= myName then VC.SendReply(distribution) end
    elseif message:match("^VER_REPLY:") then
        local data = message:sub(11)
        local name, ver = data:match("^([^:]+):(.+)$")
        if name and ver then
            VC.responses[NormName(name)] = ver
        else
            VC.responses[NormName(sender)] = data
        end
        if VC.RefreshUI then VC.RefreshUI() end
    end
end

if AceComm then
    AceComm:RegisterComm(VC_PREFIX, OnVCMessage)
end

-- ============================================================
-- CONSTRUCTION DE L'ONGLET
-- ============================================================
function VC.BuildTab(parent, w, h)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(w, h); f:Hide()
    local bg = f:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints()
    bg:SetColorTexture(0.07,0.07,0.10,1)

    local y = -14

    local title = f:CreateFontString(nil,"OVERLAY","GameFontNormal")
    title:SetPoint("TOPLEFT",f,"TOPLEFT",14,y)
    title:SetTextColor(SM.OR[1],SM.OR[2],SM.OR[3],1)
    title:SetText("Version Check")
    y = y - 22

    local sub = f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    sub:SetPoint("TOPLEFT",f,"TOPLEFT",14,y); sub:SetPoint("RIGHT",f,"RIGHT",-14,0)
    sub:SetJustifyH("LEFT"); sub:SetTextColor(0.45,0.45,0.50,1)
    sub:SetText("Membres du raid/guilde ayant SolaryM installé. Version actuelle : "..SM.VERSION)
    y = y - 26

    local checkBtn = SM.BBtn(f,160,26,"Vérifier le raid / guilde",function()
        VC.SendRequest()
        sub:SetText("Requête envoyée — en attente des réponses (5s)...")
        sub:SetTextColor(SM.OR[1],SM.OR[2],SM.OR[3],1)
        C_Timer.NewTimer(5.5,function()
            sub:SetText("Membres du raid/guilde ayant SolaryM installé. Version actuelle : "..SM.VERSION)
            sub:SetTextColor(0.45,0.45,0.50,1)
        end)
    end)
    checkBtn:SetPoint("TOPLEFT",f,"TOPLEFT",14,y)

    local clearBtn = SM.RBtn(f,80,26,"Effacer",function()
        wipe(VC.responses); wipe(VC.allMembers)
        if VC.RefreshUI then VC.RefreshUI() end
    end)
    clearBtn:SetPoint("LEFT",checkBtn,"RIGHT",8,0)

    local countLbl = f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    countLbl:SetPoint("LEFT",clearBtn,"RIGHT",12,0)
    countLbl:SetTextColor(0.5,0.5,0.55,1); countLbl:SetText("")
    f._countLbl = countLbl

    y = y - 36

    local sep = f:CreateTexture(nil,"ARTWORK"); sep:SetSize(w-28,1)
    sep:SetPoint("TOPLEFT",f,"TOPLEFT",14,y)
    sep:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.3)
    y = y - 14

    -- Header
    local function MkH(label, x)
        local h = f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
        h:SetPoint("TOPLEFT",f,"TOPLEFT",x,y)
        h:SetTextColor(0.35,0.35,0.40,1); h:SetText(label)
    end
    MkH("NOM", 14); MkH("VERSION", 230); MkH("STATUT", 360)
    y = y - 20

    local scrollFrame = CreateFrame("ScrollFrame",nil,f,"UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT",f,"TOPLEFT",14,y)
    scrollFrame:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-30,8)

    local scrollContent = CreateFrame("Frame",nil,scrollFrame)
    scrollContent:SetSize(w-50,1)
    scrollFrame:SetScrollChild(scrollContent)

    -- ── Refresh ─────────────────────────────────────────────
    function VC.RefreshUI()
        for _, child in ipairs({scrollContent:GetChildren()}) do child:Hide() end

        local ROW_H = 22
        local HEADER_H = 28
        local ry = 0
        local count = 0

        -- Catégoriser : raid vs guilde × statut addon
        local raidOk, raidOutdated, raidNone = {}, {}, {}
        local guildOk, guildOutdated, guildNone = {}, {}, {}

        for name, ver in pairs(VC.responses) do
            local src = (VC.allMembers and VC.allMembers[name]) or "guild"
            local entry = {name=name, ver=ver}
            if ver == SM.VERSION then
                if src == "raid" then table.insert(raidOk, entry)
                else table.insert(guildOk, entry) end
            else
                if src == "raid" then table.insert(raidOutdated, entry)
                else table.insert(guildOutdated, entry) end
            end
        end
        for name, src in pairs(VC.allMembers or {}) do
            if not VC.responses[name] then
                local entry = {name=name}
                if src == "raid" then table.insert(raidNone, entry)
                else table.insert(guildNone, entry) end
            end
        end

        local function sort(t) table.sort(t, function(a,b) return a.name<b.name end) end
        sort(raidOk); sort(raidOutdated); sort(raidNone)
        sort(guildOk); sort(guildOutdated); sort(guildNone)

        local function AddSectionHeader(label, n)
            local row = CreateFrame("Frame",nil,scrollContent)
            row:SetSize(w-50, HEADER_H)
            row:SetPoint("TOPLEFT",scrollContent,"TOPLEFT",0,-ry)
            local bg=row:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints()
            bg:SetColorTexture(SM.OR[1]*0.3, SM.OR[2]*0.3, SM.OR[3]*0.3, 1)
            local lbl=row:CreateFontString(nil,"OVERLAY","GameFontNormal")
            lbl:SetPoint("LEFT",row,"LEFT",6,0)
            lbl:SetTextColor(SM.OR[1],SM.OR[2],SM.OR[3],1)
            lbl:SetText(label.." ("..n..")")
            ry = ry + HEADER_H
        end

        local function AddRow(name, ver, statusText, r,g,b)
            count = count + 1
            local row = CreateFrame("Frame",nil,scrollContent)
            row:SetSize(w-50,ROW_H)
            row:SetPoint("TOPLEFT",scrollContent,"TOPLEFT",0,-ry)
            if count%2==0 then
                local bg=row:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints()
                bg:SetColorTexture(0.10,0.10,0.13,1)
            end
            local nl=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            nl:SetPoint("LEFT",row,"LEFT",6,0)
            nl:SetTextColor(0.85,0.85,0.90,1); nl:SetText(name)

            local vl=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            vl:SetPoint("LEFT",row,"LEFT",216,0)
            vl:SetText(ver or "—"); vl:SetTextColor(r,g,b,1)

            local sl=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            sl:SetPoint("LEFT",row,"LEFT",346,0)
            sl:SetText(statusText); sl:SetTextColor(r,g,b,1)

            ry = ry + ROW_H
        end

        -- ── Section RAID ────────────────────────────────────
        local raidTotal = #raidOk + #raidOutdated + #raidNone
        if raidTotal > 0 then
            AddSectionHeader("⚔ RAID", raidTotal)
            for _,e in ipairs(raidOk)       do AddRow(e.name, e.ver, "À jour",        0.3, 0.85, 0.3)  end
            for _,e in ipairs(raidOutdated)  do AddRow(e.name, e.ver, "Outdated",      1.0, 0.45, 0.15) end
            for _,e in ipairs(raidNone)      do AddRow(e.name, "—",   "NON INSTALLÉ",  0.9, 0.15, 0.15) end
        end

        -- ── Section GUILDE ──────────────────────────────────
        local guildTotal = #guildOk + #guildOutdated + #guildNone
        if guildTotal > 0 then
            AddSectionHeader("🏰 GUILDE", guildTotal)
            for _,e in ipairs(guildOk)      do AddRow(e.name, e.ver, "À jour",        0.3, 0.85, 0.3)  end
            for _,e in ipairs(guildOutdated) do AddRow(e.name, e.ver, "Outdated",      1.0, 0.45, 0.15) end
            for _,e in ipairs(guildNone)     do AddRow(e.name, "—",   "NON INSTALLÉ",  0.9, 0.15, 0.15) end
        end

        scrollContent:SetHeight(math.max(ry,1))
        countLbl:SetText(count>0 and (count.." membres") or "")
    end

    VC.RefreshUI()
    return f
end
