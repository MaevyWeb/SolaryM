-- SolaryM_Panel.lua
-- v2.0.1 — Onglets : Spells | Boss Timers | Groupes | Invites | Memory Game | Paramètres | Changelogs | Reminders

local mainFrame = nil
local activeTab = 1

local tabBtns   = {}
local tabFrames = {}

local PANEL_W   = 700   -- largeur zone de contenu
local PANEL_H   = 680
local SIDEBAR_W = 150   -- sidebar gauche avec onglets verticaux
local TOTAL_W   = PANEL_W + SIDEBAR_W
local TAB_H     = 28    -- gardé pour compatibilité
local CONTENT_Y = -28   -- offset sous la barre de titre
local CONTENT_H = PANEL_H + CONTENT_Y - 8

-- ============================================================
-- TABS
-- ============================================================
local function ShowTab(idx)
    activeTab = idx
    -- Mettre à jour le style des onglets sidebar
    for i, tb in ipairs(tabBtns) do
        if tb._bg then
            if i == idx then
                tb._bg:SetColorTexture(0.13, 0.10, 0.04, 1)  -- fond chaud pour onglet actif
                if tb._lbl then tb._lbl:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1) end
                if tb._accent then tb._accent:Show() end
            else
                tb._bg:SetColorTexture(0.08, 0.08, 0.11, 1)
                if tb._lbl then tb._lbl:SetTextColor(0.55, 0.55, 0.6, 1) end
                if tb._accent then tb._accent:Hide() end
            end
        end
    end
    for i, f in ipairs(tabFrames) do if f then f:SetShown(i==idx) end end
end

-- ============================================================
-- ONGLET 1 : SPELLS — trié par Zone → Boss → Sort
-- ============================================================
local spellBtns     = {}
local selSpellId    = nil
-- Changements en attente de broadcast (vide après chaque envoi)
SM.PendingSpellChanges = {}

local function BuildSpellsTab(parent)
    local f = CreateFrame("Frame", nil, parent)
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", SIDEBAR_W, CONTENT_Y)
    f:SetSize(PANEL_W, CONTENT_H+8); f:Hide()
    SM.BG(f, 0.07, 0.07, 0.10, 1)  -- fond opaque

    local COL_L = 400
    local COL_R = PANEL_W - COL_L - 24
    local COL_H = CONTENT_H - 4

    -- ── Col gauche : liste triée ──────────────────────────────
    local cL = CreateFrame("Frame", nil, f)
    cL:SetSize(COL_L, COL_H); cL:SetPoint("TOPLEFT", f, "TOPLEFT", 8, -4)
    SM.BG(cL, SM.DK[1], SM.DK[2], SM.DK[3], 1)
    SM.Lbl(cL, SM.T("spells_header"), "GameFontNormal", 8, -8, SM.OR)

    local searchInput = SM.Input(cL, COL_L-16, 22, SM.T("search_placeholder"))
    searchInput:SetPoint("TOPLEFT", cL, "TOPLEFT", 8, -26)
    searchInput:SetScript("OnTextChanged", function() SM.RefreshSpellList() end)
    f._searchInput = searchInput

    local spellScroll = SM.Scroll(cL, COL_L-4, COL_H-54)
    spellScroll:SetPoint("TOPLEFT", cL, "TOPLEFT", 2, -52)
    f._spellScroll = spellScroll

    -- ── Col droite : édition ──────────────────────────────────
    local cR = CreateFrame("Frame", nil, f)
    cR:SetSize(COL_R, COL_H); cR:SetPoint("TOPLEFT", cL, "TOPRIGHT", 8, 0)
    SM.BG(cR, SM.DK[1], SM.DK[2], SM.DK[3], 1)
    SM.Lbl(cR, SM.T("edit_callout"), "GameFontNormal", 8, -8, SM.OR)

    local y = -28
    SM.Lbl(cR, SM.T("spell_id"), nil, 8, y)
    local idInput = SM.Input(cR, COL_R-16, 22, "Ex: 1249262")
    idInput:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y-14)
    f._idInput = idInput
    y = y - 40

    SM.Lbl(cR, SM.T("spell_name"), nil, 8, y)
    local nameDisplay = cR:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    nameDisplay:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y-14)
    nameDisplay:SetPoint("RIGHT", cR, "RIGHT", -8, 0)
    nameDisplay:SetJustifyH("LEFT")
    nameDisplay:SetTextColor(0.8,0.8,0.8,1); nameDisplay:SetText("—")
    f._nameDisplay = nameDisplay
    y = y - 30

    SM.Lbl(cR, SM.T("spell_note"), nil, 8, y)
    local noteDisplay = cR:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    noteDisplay:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y-14)
    noteDisplay:SetPoint("RIGHT", cR, "RIGHT", -8, 0)
    noteDisplay:SetJustifyH("LEFT")
    noteDisplay:SetTextColor(0.5,0.5,0.5,1); noteDisplay:SetText("—")
    f._noteDisplay = noteDisplay
    y = y - 42

    -- Lookup auto
    idInput:SetScript("OnTextChanged", function(s)
        local id = tonumber(SM.GetVal(s))
        if not id then nameDisplay:SetText("—"); noteDisplay:SetText("—"); return end
        local entry = SM.GetSpellEntry(id)
        if entry then
            local dname = (SM.LANG=="fr" and entry.fr~="" and entry.fr) or entry.en or tostring(entry.id)
            nameDisplay:SetText(dname)
            local dnote = entry.boss and ("["..entry.boss.."] "..entry.zone) or "—"
            noteDisplay:SetText(dnote)
        else
            local sname = C_Spell and C_Spell.GetSpellName(id) or (GetSpellInfo and GetSpellInfo(id)) or nil
            nameDisplay:SetText(sname or SM.T("unknown_spell"))
            noteDisplay:SetText("—")
        end
    end)

    SM.Lbl(cR, SM.T("callout_screen"), nil, 8, y)
    local calloutInput = SM.Input(cR, COL_R-16, 24, SM.T("callout_ph"))
    calloutInput:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y-16)
    f._calloutInput = calloutInput
    y = y - 46

    SM.Lbl(cR, SM.T("tts_label"), nil, 8, y)
    local ttsInput = SM.Input(cR, COL_R-16, 24, SM.T("tts_ph"))
    ttsInput:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y-16)
    f._ttsInput = ttsInput
    y = y - 46

    SM.Lbl(cR, SM.T("sound_label"), nil, 8, y)
    y = y - 20

    -- Dropdown son + bouton Test — liste dynamique depuis SM.MediaSounds
    local function GetSounds()
        local t = {"(aucun)"}
        for _, s in ipairs(SM.MediaSounds or {}) do table.insert(t, s) end
        return t
    end
    local selectedSnd = "(aucun)"

    -- Bouton dropdown
    local sndDropBtn = CreateFrame("Button", nil, cR)
    sndDropBtn:SetSize(COL_R-16-52, 24)
    sndDropBtn:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    local sndDropBg = sndDropBtn:CreateTexture(nil,"BACKGROUND")
    sndDropBg:SetAllPoints()
    sndDropBg:SetColorTexture(0.12,0.12,0.16,1)
    local sndDropBorder = sndDropBtn:CreateTexture(nil,"BORDER")
    sndDropBorder:SetAllPoints()
    sndDropBorder:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.25)
    local sndDropLbl = sndDropBtn:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    sndDropLbl:SetPoint("LEFT",sndDropBtn,"LEFT",8,0)
    sndDropLbl:SetText(selectedSnd)
    sndDropLbl:SetTextColor(0.9,0.9,0.9,1)
    local sndDropArrow = sndDropBtn:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    sndDropArrow:SetPoint("RIGHT",sndDropBtn,"RIGHT",-6,0)
    sndDropArrow:SetText("v")

    -- Bouton Test
    local sndTestBtn = SM.BBtn(cR, 46, 24, "Test", function()
        if selectedSnd ~= "(aucun)" then
            PlaySoundFile("Interface\\AddOns\\SolaryM\\Media\\Sounds\\"..selectedSnd..".ogg", "Master")
        end
    end)
    sndTestBtn:SetPoint("LEFT", sndDropBtn, "RIGHT", 4, 0)

    -- Menu déroulant
    local sndMenu = CreateFrame("Frame", nil, cR)
    sndMenu:SetSize(COL_R-16-52, 22)  -- taille initiale, ajustée à l'ouverture
    sndMenu:SetPoint("TOPLEFT", sndDropBtn, "BOTTOMLEFT", 0, -2)
    sndMenu:SetFrameStrata("TOOLTIP")
    local sndMenuBg = sndMenu:CreateTexture(nil,"BACKGROUND")
    sndMenuBg:SetAllPoints(); sndMenuBg:SetColorTexture(0.08,0.08,0.11,0.98)
    sndMenu:Hide()

    -- Reconstruire le menu à chaque ouverture
    sndDropBtn:SetScript("OnClick", function()
        if sndMenu:IsShown() then sndMenu:Hide(); return end
        -- Vider l'ancien contenu
        for _, c in ipairs({sndMenu:GetChildren()}) do c:Hide() end
        local SOUNDS = GetSounds()
        sndMenu:SetHeight(#SOUNDS * 22)
        for i, sname in ipairs(SOUNDS) do
            local item = CreateFrame("Button", nil, sndMenu)
            item:SetSize(COL_R-16-52, 22)
            item:SetPoint("TOPLEFT", sndMenu, "TOPLEFT", 0, -(i-1)*22)
            local ibg = item:CreateTexture(nil,"BACKGROUND"); ibg:SetAllPoints(); ibg:SetColorTexture(0,0,0,0)
            local ilbl = item:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            ilbl:SetPoint("LEFT",item,"LEFT",8,0); ilbl:SetText(sname); ilbl:SetTextColor(0.85,0.85,0.9,1)
            item:SetScript("OnEnter",function() ibg:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.2) end)
            item:SetScript("OnLeave",function() ibg:SetColorTexture(0,0,0,0) end)
            local sn = sname
            item:SetScript("OnClick",function()
                selectedSnd = sn; sndDropLbl:SetText(sn)
                SolaryMDB.spells_snd = SolaryMDB.spells_snd or {}
                -- sera sauvegardé au prochain Sauvegarder
                sndMenu:Hide()
            end)
        end
        sndMenu:Show()
    end)



    -- Exposer selectedSnd pour save/load via closure
    f._sndInput = {
        GetText = function() return selectedSnd ~= "(aucun)" and selectedSnd or "" end,
        SetText = function(_, v)
            selectedSnd = (v and v ~= "") and v or "(aucun)"
            sndDropLbl:SetText(selectedSnd)
        end,
    }

    y = y - 34

    local BW2 = math.floor((COL_R-16-6)/2)
    SM.OBtn(cR, BW2, 26, SM.T("btn_save"), function()
        local newId = tonumber(SM.GetVal(idInput))
        if not newId then SM.Print("Entre un spell ID.") return end
        local callout = SM.GetVal(calloutInput)
        if callout == "" then SM.Print("Entre un callout.") return end

        SolaryMDB.spellIdRemap = SolaryMDB.spellIdRemap or {}

        if selSpellId and selSpellId ~= newId then
            -- L'ID a changé : supprimer l'ancien callout, créer le remap
            SolaryMDB.spells[selSpellId] = nil
            SolaryMDB.spellIdRemap[selSpellId] = newId
            SM.PendingSpellChanges[selSpellId] = "__removed__"
        elseif selSpellId then
            -- Même ID (ou retour à l'ID d'origine) : supprimer le remap existant
            local oldRemapId = SolaryMDB.spellIdRemap[selSpellId]
            if oldRemapId then
                -- Nettoyer l'ancien callout sur l'ID remappé
                SolaryMDB.spells[oldRemapId] = nil
                -- Dire aux receivers de supprimer l'ancien ID remappé
                SM.PendingSpellChanges[oldRemapId] = "__removed__"
            end
            SolaryMDB.spellIdRemap[selSpellId] = nil
            -- Envoyer aussi le remap nettoyé pour que les receivers le suppriment
            SM.PendingSpellChanges["__remap_clear_" .. selSpellId] = "__remap_clear__"
        end

        SolaryMDB.spells[newId] = callout
        SM.PendingSpellChanges[newId] = callout
        -- Sauvegarder le TTS et l'inclure dans le broadcast
        local ttsText = SM.GetVal(ttsInput)
        SolaryMDB.spells_tts = SolaryMDB.spells_tts or {}
        if ttsText ~= "" then
            SolaryMDB.spells_tts[newId] = ttsText
            SM.PendingSpellChanges["__tts_"..newId] = ttsText
        else
            SolaryMDB.spells_tts[newId] = nil
            SM.PendingSpellChanges["__tts_"..newId] = "__removed__"
        end
        -- Sauvegarder le son
        local sndText = f._sndInput and f._sndInput:GetText() or ""
        SolaryMDB.spells_snd = SolaryMDB.spells_snd or {}
        if sndText ~= "" then
            SolaryMDB.spells_snd[newId] = sndText
        else
            SolaryMDB.spells_snd[newId] = nil
        end
        SM.SetVal(idInput,""); SM.SetVal(calloutInput,""); SM.SetVal(ttsInput,"")
        if f._sndInput then f._sndInput:SetText("") end
        nameDisplay:SetText("—"); noteDisplay:SetText("—")
        selSpellId = nil
        SM.RefreshSpellList()
        SM._UpdatePendingCount()
        SM.Print("Spell |cFFFFD700"..newId.."|r % \""..callout.."\"")
    end):SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)

    SM.RBtn(cR, BW2, 26, SM.T("btn_reset"), function()
        if not selSpellId then SM.Print("Sélectionne un sort.") return end
        local entry = SM.GetSpellEntry(selSpellId)
        -- Remettre le callout par défaut sur l'ID d'origine
        local defaultCallout = entry and ((SM.LANG=="fr" and entry.fr) or entry.en) or nil
        SolaryMDB.spells[selSpellId] = defaultCallout
        -- Si l'ID avait été remappé, supprimer le remap et effacer l'ancien callout custom
        SolaryMDB.spellIdRemap = SolaryMDB.spellIdRemap or {}
        local remappedId = SolaryMDB.spellIdRemap[selSpellId]
        if remappedId then
            SolaryMDB.spells[remappedId] = nil          -- effacer le callout sur le nouvel ID
            SolaryMDB.spellIdRemap[selSpellId] = nil    -- supprimer le remap
            SM.PendingSpellChanges[remappedId] = "__removed__"
        end
        -- Marquer la réinitialisation comme changement pending
        SM.PendingSpellChanges[selSpellId] = defaultCallout or "__removed__"
        SM._UpdatePendingCount()
        selSpellId = nil
        SM.SetVal(idInput,""); SM.SetVal(calloutInput,"")
        nameDisplay:SetText("—"); noteDisplay:SetText("—")
        SM.RefreshSpellList()
        SM.Print("Sort réinitialisé.")
    end):SetPoint("TOPLEFT", cR, "TOPLEFT", 8+BW2+6, y)
    y = y - 36

    SM.BBtn(cR, COL_R-16, 26, SM.T("btn_test2"), function()
        local callout = SM.GetVal(calloutInput)
        if callout == "" then
            callout = (selSpellId and SolaryMDB.spells[selSpellId]) or "SOAK"
        end
        SM.TestAlert(callout, 8)
    end):SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    y = y - 34

    -- Séparateur
    local sepBroadcast = cR:CreateTexture(nil,"ARTWORK"); sepBroadcast:SetSize(COL_R-16,1)
    sepBroadcast:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y); sepBroadcast:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.4)
    y = y - 14

    SM.Lbl(cR, SM.T("raid_sync"), "GameFontNormal", 8, y, SM.OR)
    y = y - 20
    local syncDesc = cR:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    syncDesc:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    syncDesc:SetPoint("RIGHT", cR, "RIGHT", -8, 0)
    syncDesc:SetJustifyH("LEFT")
    syncDesc:SetTextColor(0.5, 0.5, 0.55, 1)
    syncDesc:SetText(SM.T("raid_sync_desc"))
    y = y - 34

    -- Sélecteur image Media (dropdown natif WoW)
    SM.Lbl(cR, SM.T("img_label"), nil, 8, y)
    y = y - 18

    -- Dropdown des fichiers .tga/.png dans Media/
    local imgDropdown = CreateFrame("Frame", "SolaryMImgDropdown", cR, "UIDropDownMenuTemplate")
    imgDropdown:SetPoint("TOPLEFT", cR, "TOPLEFT", -4, y+4)
    UIDropDownMenu_SetWidth(imgDropdown, COL_R - 90)
    UIDropDownMenu_SetText(imgDropdown, SM.T("no_image"))

    -- Liste des images disponibles (scannées au chargement du panel)
    local mediaImages = {}
    local function ScanMediaImages()
        mediaImages = {}
        -- On liste les fichiers connus dans le dossier Media (WoW ne peut pas lister les dossiers)
        -- L'utilisateur place ses images dans Interface/AddOns/SolaryM/Media/
        -- On stocke dans SolaryMDB les fichiers connus
        local known = SolaryMDB.mediaFiles or {}
        for _, fname in ipairs(known) do
            table.insert(mediaImages, fname)
        end
        -- Toujours inclure break.tga par défaut
        local hasBreak = false
        for _, f in ipairs(mediaImages) do if f == "break" then hasBreak = true end end
        if not hasBreak then table.insert(mediaImages, 1, "break") end
    end
    ScanMediaImages()

    local selectedImg = nil
    UIDropDownMenu_Initialize(imgDropdown, function(self, level)
        local info = UIDropDownMenu_CreateInfo()
        -- Option "Aucune"
        info.text = SM.T("no_image_dash")
        info.value = nil
        info.func = function()
            selectedImg = nil
            UIDropDownMenu_SetText(imgDropdown, SM.T("no_image"))
        end
        info.checked = selectedImg == nil
        UIDropDownMenu_AddButton(info)
        -- Fichiers Media
        for _, fname in ipairs(mediaImages) do
            info = UIDropDownMenu_CreateInfo()
            info.text = fname
            info.value = fname
            local fn = fname
            info.func = function()
                selectedImg = fn
                UIDropDownMenu_SetText(imgDropdown, fn)
            end
            info.checked = selectedImg == fname
            UIDropDownMenu_AddButton(info)
        end
        -- Option "Rafraîchir"
        info = UIDropDownMenu_CreateInfo()
        info.text = "|cFFAAAAAA "..SM.T("refresh_list").."|r"
        info.value = "__refresh"
        info.func = function()
            ScanMediaImages()
            UIDropDownMenu_Refresh(imgDropdown)
        end
        UIDropDownMenu_AddButton(info)
    end)
    y = y - 32

    -- Lien vers le README
    local mediaInfo = cR:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    mediaInfo:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    mediaInfo:SetPoint("RIGHT", cR, "RIGHT", -8, 0)
    mediaInfo:SetJustifyH("LEFT"); mediaInfo:SetTextColor(0.4,0.4,0.4,1)
    mediaInfo:SetText(SM.T("media_info"))
    y = y - 26

    -- Compteur de changements en attente
    local pendingLbl = cR:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    pendingLbl:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    pendingLbl:SetPoint("RIGHT", cR, "RIGHT", -8, 0)
    pendingLbl:SetJustifyH("LEFT"); pendingLbl:SetTextColor(1, 0.82, 0, 1)
    pendingLbl:SetText(SM.T("pending_none"))
    f._pendingLbl = pendingLbl
    y = y - 22

    -- Bouton broadcast (changements pending uniquement)
    local broadcastBtn = SM.Btn(cR, COL_R-16, 30, SM.T("btn_broadcast"),
        SM.PRP[1], SM.PRP[2], SM.PRP[3], function()
        SM.BroadcastSpells(selectedImg)
    end)
    broadcastBtn:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    y = y - 38

    -- Statut broadcast
    local broadcastStatus = cR:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    broadcastStatus:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    broadcastStatus:SetPoint("RIGHT", cR, "RIGHT", -8, 0)
    broadcastStatus:SetJustifyH("LEFT"); broadcastStatus:SetTextColor(0.4,0.4,0.4,1)
    broadcastStatus:SetText(SM.T("last_broadcast"))
    f._broadcastStatus = broadcastStatus
    y = y - 24

    -- Info
    local info = cR:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    info:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    info:SetPoint("RIGHT", cR, "RIGHT", -8, 0)
    info:SetJustifyH("LEFT"); info:SetTextColor(0.4,0.4,0.4,1)
    info:SetText(SM.T("spell_info"))

    return f
end

-- ============================================================
-- REFRESH SPELLS — liste groupée par zone puis boss
-- ============================================================
function SM.RefreshSpellList()
    local f = tabFrames[1]
    if not f or not f._spellScroll then return end
    local scroll = f._spellScroll
    for _, b in ipairs(spellBtns) do b:Hide() end
    spellBtns = {}

    local filter  = f._searchInput and SM.GetVal(f._searchInput):lower() or ""
    local W       = scroll.content:GetWidth()
    local yOff    = 0
    local typeCol = { raid={1,0.6,0}, dungeon={0.4,0.8,1} }

    local function spellMatchesFilter(spell)
        if filter == "" then return true end
        local callout = SolaryMDB.spells[spell.id] or (SM.LANG=="fr" and spell.fr) or spell.en or ""
        local sname = spell.en or spell.fr or ""
        local boss  = spell.boss or ""
        return sname:lower():find(filter,1,true)
            or callout:lower():find(filter,1,true)
            or boss:lower():find(filter,1,true)
    end

    local function bossHasMatch(boss)
        for _, spell in ipairs(boss.spells) do
            if spellMatchesFilter(spell) then return true end
        end
        return false
    end

    local function zoneHasMatch(zone)
        for _, boss in ipairs(zone.bosses) do
            if bossHasMatch(boss) then return true end
        end
        return false
    end

    for _, zone in ipairs(SM.SpellDB) do
        if zoneHasMatch(zone) then
            local tc = typeCol[zone.type] or {0.7,0.7,0.7}

            -- En-tête zone
            local zRow = CreateFrame("Frame", nil, scroll.content)
            zRow:SetSize(W, 22); zRow:SetPoint("TOPLEFT", 0, -yOff)
            local zBg = zRow:CreateTexture(nil,"BACKGROUND"); zBg:SetAllPoints()
            zBg:SetColorTexture(tc[1]*0.2, tc[2]*0.2, tc[3]*0.2, 1)
            local zLbl = zRow:CreateFontString(nil,"OVERLAY","GameFontNormal")
            zLbl:SetPoint("LEFT",6,0); zLbl:SetPoint("RIGHT",zRow,"RIGHT",-60,0)
            zLbl:SetJustifyH("LEFT"); zLbl:SetTextColor(tc[1],tc[2],tc[3],1); zLbl:SetText(zone.zone)
            local zTag = zRow:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
            zTag:SetPoint("RIGHT",zRow,"RIGHT",-4,0)
            zTag:SetTextColor(tc[1]*0.8,tc[2]*0.8,tc[3]*0.8,1)
            zTag:SetText(zone.type == "raid" and "RAID" or SM.T("type_dungeon"))
            table.insert(spellBtns, zRow); yOff = yOff + 24

            for _, boss in ipairs(zone.bosses) do
                if bossHasMatch(boss) then
                    -- En-tête boss
                    local bRow = CreateFrame("Frame", nil, scroll.content)
                    bRow:SetSize(W, 20); bRow:SetPoint("TOPLEFT", 0, -yOff)
                    SM.BG(bRow, 0.12, 0.12, 0.16, 1)
                    local bLbl = bRow:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
                    bLbl:SetPoint("LEFT",14,0); bLbl:SetPoint("RIGHT",bRow,"RIGHT",-4,0)
                    bLbl:SetJustifyH("LEFT"); bLbl:SetTextColor(0.9,0.75,0.4,1)
                    bLbl:SetText(boss.boss)
                    table.insert(spellBtns, bRow); yOff = yOff + 22

                    -- Sorts
                    for _, spell in ipairs(boss.spells) do
                        if spellMatchesFilter(spell) then
                            local defCallout = (SM.LANG=="fr" and spell.fr) or spell.en or ""
                            -- Vérifier si cet ID a été remappé vers un nouvel ID
                            local remapId2   = SolaryMDB.spellIdRemap and SolaryMDB.spellIdRemap[spell.id]
                            local activeId2  = remapId2 or spell.id
                            local callout    = SolaryMDB.spells[activeId2] or defCallout
                            local isCustom   = (SolaryMDB.spells[activeId2] and SolaryMDB.spells[activeId2] ~= defCallout) or (remapId2 ~= nil)
                            local isSel    = (selSpellId == spell.id)

                            local btn = CreateFrame("Button", nil, scroll.content)
                            btn:SetSize(W, 26); btn:SetPoint("TOPLEFT", 0, -yOff)
                            local bg = btn:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints()
                            bg:SetColorTexture(isSel and 0.22 or 0.08, isSel and 0.15 or 0.08, isSel and 0.03 or 0.10, 1)
                            btn._bg = bg

                            -- Spells custom : différenciés par couleur uniquement (pas de marqueur)
                            local fCall = btn:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
                            fCall:SetPoint("LEFT",8,0); fCall:SetWidth(100); fCall:SetJustifyH("LEFT")
                            fCall:SetTextColor(isCustom and 1 or SM.OR[1], isCustom and 0.7 or SM.OR[2], isCustom and 0.1 or SM.OR[3], 1)
                            fCall:SetText(callout)
                            local fName = btn:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
                            fName:SetPoint("LEFT",btn,"LEFT",130,0); fName:SetPoint("RIGHT",btn,"RIGHT",-50,0)
                            fName:SetJustifyH("LEFT"); fName:SetTextColor(0.65,0.65,0.65,1)
                            fName:SetText((spell.boss or "")..(spell.en and (" — "..spell.en) or ""))
                            local fId = btn:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
                            fId:SetPoint("RIGHT",btn,"RIGHT",-4,0); fId:SetTextColor(0.35,0.35,0.35,1)
                            -- Afficher l'ID custom si remappé, sinon l'ID DB
                            local displayId = (SolaryMDB.spellIdRemap and SolaryMDB.spellIdRemap[spell.id]) or spell.id
                            fId:SetText(tostring(displayId))

                            local sid=spell.id
                            local sname_en = spell.en or ""
                            local sname_fr = spell.fr or ""
                            local scallout = callout
                            -- Récupérer boss/zone depuis l'index (pas dans spell directement)
                            local _idx = SM.SpellIndex and SM.SpellIndex[spell.id]
                            local sboss = (_idx and _idx.boss) or ""
                            local szone = (_idx and _idx.zone) or ""
                            btn:SetScript("OnClick", function()
                                selSpellId = sid  -- toujours l'ID DB original
                                -- Si remappé, montrer le nouvel ID dans le champ et charger le callout du nouvel ID
                                local remapId = SolaryMDB.spellIdRemap and SolaryMDB.spellIdRemap[sid]
                                local activeId = remapId or sid
                                if f._idInput      then SM.SetVal(f._idInput, tostring(activeId)) end
                                if f._calloutInput then SM.SetVal(f._calloutInput, SolaryMDB.spells[activeId] or scallout) end
                            if f._ttsInput then
                                local ttsData = SolaryMDB.spells_tts and SolaryMDB.spells_tts[activeId]
                                local ttsText = type(ttsData)=="string" and ttsData or ""
                                SM.SetVal(f._ttsInput, ttsText)
                            end
                            if f._sndInput then
                                local snd = SolaryMDB.spells_snd and SolaryMDB.spells_snd[activeId] or ""
                                if f._sndInput then f._sndInput:SetText(snd or "") end
                            end
                                if f._nameDisplay  then
                                    local dn = (SM.LANG=="fr" and sname_fr~="" and sname_fr) or sname_en
                                    f._nameDisplay:SetText(dn)
                                end
                                if f._noteDisplay  then
                                    f._noteDisplay:SetText(sboss~="" and ("["..sboss.."] "..szone) or "—")
                                end
                                SM.RefreshSpellList()
                            end)
                            btn:SetScript("OnEnter", function(s)
                                if selSpellId ~= sid then s._bg:SetColorTexture(0.15,0.15,0.18,1) end
                                GameTooltip:SetOwner(s,"ANCHOR_RIGHT")
                                GameTooltip:SetText(sname_en~="" and sname_en or tostring(sid), SM.OR[1],SM.OR[2],SM.OR[3])
                                if sname_fr~="" and sname_fr~=sname_en then
                                    GameTooltip:AddLine(sname_fr, 0.8, 0.8, 0.8, true)
                                end
                                GameTooltip:AddLine("Boss: "..sboss, 0.6, 0.6, 0.6, true)
                                GameTooltip:AddLine("Zone: "..szone, 0.5, 0.5, 0.5, true)
                                GameTooltip:AddLine("ID: "..sid, 0.4, 0.4, 0.4, true)
                                GameTooltip:Show()
                            end)
                            btn:SetScript("OnLeave", function(s)
                                if selSpellId ~= sid then s._bg:SetColorTexture(0.08,0.08,0.10,1) end
                                GameTooltip:Hide()
                            end)
                            table.insert(spellBtns, btn); yOff = yOff + 28
                        end
                    end
                end
            end
            yOff = yOff + 4
        end
    end
    scroll.content:SetHeight(math.max(yOff, 1))
end

-- ============================================================
-- ONGLET 2 : GROUPES
-- ============================================================
local function BuildGroupsTab(parent)
    local f = CreateFrame("Frame",nil,parent)
    f:SetPoint("TOPLEFT",parent,"TOPLEFT",SIDEBAR_W,CONTENT_Y)
    f:SetSize(PANEL_W,CONTENT_H+8); f:Hide()
    SM.BG(f, 0.07, 0.07, 0.10, 1)  -- fond opaque

    local HALF = math.floor((PANEL_W-24)/2)

    -- ── Ligne de boutons ─────────────────────────────────────
    local btnOE = SM.OBtn(f, math.floor(HALF*0.9), 28, SM.T("split_odd_even"), function()
        SM.Groups.SplitOddEven()
        SM.RefreshGroupsTab("default", f)
        local oeA, oeB = SM.Groups.GetSplitLabels()
        SM.Print(string.format("Split |cFFFFD700%s|r vs |cFFFFD700%s|r", oeA, oeB))
    end)
    btnOE:SetPoint("TOPLEFT",f,"TOPLEFT",8,-10)

    local btnH = SM.OBtn(f, math.floor(HALF*0.9), 28, SM.T("split_halves"), function()
        SM.Groups.SplitHalves()
        SM.RefreshGroupsTab("default", f)
        local _, _, hA, hB = SM.Groups.GetSplitLabels()
        SM.Print(string.format("Split |cFFFFD700%s|r vs |cFFFFD700%s|r", hA, hB))
    end)
    btnH:SetPoint("TOPLEFT",f,"TOPLEFT", 8 + math.floor(HALF*0.9) + 12, -10)

    -- Labels dynamiques sous les boutons (affichent ex: "Grp 1/3/5" / "Grp 2/4/6")
    local lblSplit = f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    lblSplit:SetPoint("TOPLEFT",f,"TOPLEFT",8,-44)
    lblSplit:SetTextColor(0.6,0.6,0.6,1)
    lblSplit:SetText("Raid 10/25 → Impairs (1/3/5) vs Pairs (2/4/6)   |   Mythic 20 → 1/3 vs 2/4")
    f._lblSplit = lblSplit

    -- ── Colonnes A / B ────────────────────────────────────────
    local colA = CreateFrame("Frame",nil,f)
    colA:SetSize(HALF, CONTENT_H-62); colA:SetPoint("TOPLEFT",f,"TOPLEFT",8,-58)
    SM.BG(colA,SM.DK[1],SM.DK[2],SM.DK[3],0.7)
    SM.Lbl(colA,SM.T("group_a"),"GameFontNormal",8,-8,SM.OR)
    local sA = SM.Scroll(colA,HALF-4,CONTENT_H-90)
    sA:SetPoint("TOPLEFT",colA,"TOPLEFT",2,-28)

    local colB = CreateFrame("Frame",nil,f)
    colB:SetSize(HALF, CONTENT_H-62); colB:SetPoint("TOPLEFT",f,"TOPLEFT",8+HALF+8,-58)
    SM.BG(colB,SM.DK[1],SM.DK[2],SM.DK[3],0.7)
    SM.Lbl(colB,SM.T("group_b"),"GameFontNormal",8,-8,SM.OR)
    local sB = SM.Scroll(colB,HALF-4,CONTENT_H-90)
    sB:SetPoint("TOPLEFT",colB,"TOPLEFT",2,-28)

    f._scrollA=sA; f._scrollB=sB
    return f
end

function SM.RefreshGroupsTab(bossName, f)
    f = f or tabFrames[3]
    if not f or not f._scrollA then return end
    local key = "default"
    local groups = SolaryMDB.groups[key] or {A={},B={}}
    local rc = {TANK={0.2,0.6,1},HEALER={0.1,0.9,0.3},DAMAGER={1,0.8,0.1},NONE={0.7,0.7,0.7}}
    local function Fill(scroll, list)
        for _, c in ipairs({scroll.content:GetChildren()}) do c:Hide() end
        local sorted = SM.Groups.SortByRole()
        local roleMap = {}
        for _, g in ipairs({sorted.tanks, sorted.healers, sorted.dps}) do
            for _, m in ipairs(g) do roleMap[m.name] = m.role end
        end
        local yOff = 0
        for _, name in ipairs(list) do
            local row = CreateFrame("Frame",nil,scroll.content)
            row:SetSize(scroll.content:GetWidth(),24); row:SetPoint("TOPLEFT",0,-yOff)
            SM.BG(row,0.1,0.1,0.13,1)
            local role = roleMap[name] or "NONE"
            local c = rc[role] or rc.NONE
            local ri = role=="TANK" and "T" or role=="HEALER" and "H" or "D"
            local fr = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            fr:SetPoint("LEFT",4,0); fr:SetWidth(14)
            fr:SetTextColor(c[1],c[2],c[3],1); fr:SetText(ri)
            local fn = row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            fn:SetPoint("LEFT",22,0); fn:SetPoint("RIGHT",row,"RIGHT",-4,0)
            fn:SetJustifyH("LEFT"); fn:SetTextColor(0.9,0.9,0.9,1); fn:SetText(name)
            yOff = yOff + 26
        end
        scroll.content:SetHeight(math.max(yOff,1))
    end
    Fill(f._scrollA, groups.A or {})
    Fill(f._scrollB, groups.B or {})

    if f._lblSplit then
        if IsInRaid() then
            local oeA, oeB, hA, hB = SM.Groups.GetSplitLabels()
            f._lblSplit:SetText(string.format("Impairs/Pairs : |cFFFFD700%s|r vs |cFFFFD700%s|r   |   Moitiés : |cFFFFD700%s|r vs |cFFFFD700%s|r", oeA, oeB, hA, hB))
        else
            f._lblSplit:SetText("Hors raid : split équilibré par rôle (T/H/DPS alternés)")
        end
    end
end

-- ============================================================
-- ONGLET 3 : INVITES
-- ============================================================
local function BuildInviteTab(parent)
    local f=CreateFrame("Frame",nil,parent)
    f:SetPoint("TOPLEFT",parent,"TOPLEFT",SIDEBAR_W,CONTENT_Y)
    f:SetSize(PANEL_W,CONTENT_H+8); f:Hide()
    SM.BG(f, 0.07, 0.07, 0.10, 1)  -- fond opaque

    local y=-14
    SM.Lbl(f,SM.T("autoinvite"),"GameFontNormal",8,y,SM.OR); y=y-20
    SM.Lbl(f,SM.T("autoinvite_desc"),nil,8,y); y=y-30

    local toggleBtn=SM.OBtn(f,160,26,SM.T("btn_enable"),function()
        local en=SM.Invite.IsAutoInviteEnabled()
        SM.Invite.SetAutoInvite(not en)
        if not en then
            f._toggle._fs:SetText(SM.T("btn_disable"))
            f._toggle._bg:SetColorTexture(SM.RED[1],SM.RED[2],SM.RED[3],0.88)
            f._toggle._r=SM.RED[1]; f._toggle._g=SM.RED[2]; f._toggle._b=SM.RED[3]
        else
            f._toggle._fs:SetText(SM.T("btn_enable"))
            f._toggle._bg:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.88)
            f._toggle._r=SM.OR[1]; f._toggle._g=SM.OR[2]; f._toggle._b=SM.OR[3]
        end
    end)
    toggleBtn:SetPoint("TOPLEFT",f,"TOPLEFT",8,y); f._toggle=toggleBtn

    local kwLbl=f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    kwLbl:SetPoint("LEFT",toggleBtn,"RIGHT",12,0); kwLbl:SetTextColor(0.6,0.6,0.6,1)
    local kws=SolaryMDB.invite and SolaryMDB.invite.keywords or {"inv","+1"}
    kwLbl:SetText(SM.T("keywords").." "..table.concat(kws,"  |  "))
    y=y-44

    local sep=f:CreateTexture(nil,"ARTWORK")
    sep:SetSize(PANEL_W-16,1); sep:SetPoint("TOPLEFT",f,"TOPLEFT",8,y)
    sep:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.4); y=y-16

    SM.Lbl(f,SM.T("guild_rank"),"GameFontNormal",8,y,SM.OR); y=y-20
    SM.Lbl(f,SM.T("guild_rank_desc"),nil,8,y); y=y-30

    local rf=CreateFrame("Frame",nil,f)
    rf:SetPoint("TOPLEFT",f,"TOPLEFT",8,y); rf:SetSize(PANEL_W-16,160)
    SM.BG(rf,SM.DK[1],SM.DK[2],SM.DK[3],0.7); f._rankFrame=rf
    y=y-170

    SM.BBtn(f,150,26,SM.T("btn_load_ranks"),function()
        SM.RefreshRankList(f)
    end):SetPoint("TOPLEFT",f,"TOPLEFT",8,y)

    SM.GBtn(f,150,26,SM.T("btn_invite_sel"),function()
        SM.Invite.InviteByRanks(f._selectedRanks or {})
    end):SetPoint("TOPLEFT",f,"TOPLEFT",166,y)

    f._selectedRanks={}
    return f
end

function SM.RefreshRankList(f)
    f=f or tabFrames[4]
    if not f or not f._rankFrame then return end
    local rf=f._rankFrame; f._selectedRanks={}
    for _,c in ipairs({rf:GetChildren()}) do c:Hide() end
    local ranks=SM.Invite.GetGuildRanks()
    if #ranks==0 then
        local lbl=rf:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
        lbl:SetPoint("CENTER"); lbl:SetText(SM.T("not_in_guild"))
        return
    end
    local BW,BH,COLS=165,28,4
    for i,rank in ipairs(ranks) do
        local col=(i-1)%COLS; local row=math.floor((i-1)/COLS)
        local btn=CreateFrame("Button",nil,rf)
        btn:SetSize(BW,BH); btn:SetPoint("TOPLEFT",rf,"TOPLEFT",8+col*(BW+6),-8-row*(BH+4))
        local bg=btn:CreateTexture(nil,"BACKGROUND")
        bg:SetAllPoints(); bg:SetColorTexture(0.1,0.1,0.13,1); btn._bg=bg
        local fs=btn:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        fs:SetAllPoints(); fs:SetJustifyH("CENTER"); fs:SetTextColor(0.8,0.8,0.8,1); fs:SetText(rank.name)
        local sel=false
        btn:SetScript("OnClick",function()
            sel=not sel
            if sel then
                bg:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.85); fs:SetTextColor(0.05,0.05,0.05,1)
                table.insert(f._selectedRanks,rank.index)
            else
                bg:SetColorTexture(0.1,0.1,0.13,1); fs:SetTextColor(0.8,0.8,0.8,1)
                for j,ri in ipairs(f._selectedRanks) do
                    if ri==rank.index then table.remove(f._selectedRanks,j); break end
                end
            end
        end)
    end
end

-- ============================================================
-- ONGLET 4 : PARAMÈTRES
-- ============================================================
local function MakeSlider(parent, label, minV, maxV, step, getValue, setValue, x, y, w)
    w = w or 200
    local H = 6   -- hauteur de la barre
    local THUMB = 12  -- taille du curseur

    -- Label + valeur sur la même ligne
    local lbl = parent:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    lbl:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    lbl:SetTextColor(0.65, 0.65, 0.7, 1)

    local valLbl = parent:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    valLbl:SetPoint("TOPLEFT", parent, "TOPLEFT", x + w + 8, y)
    valLbl:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
    valLbl:SetJustifyH("LEFT")

    -- Barre de fond (track)
    local track = parent:CreateTexture(nil, "ARTWORK")
    track:SetSize(w, H)
    track:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y - 16)
    track:SetColorTexture(0.15, 0.15, 0.20, 1)

    -- Barre de remplissage (fill)
    local fill = parent:CreateTexture(nil, "ARTWORK")
    fill:SetSize(1, H)
    fill:SetPoint("LEFT", track, "LEFT", 0, 0)
    fill:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 1)

    -- Curseur (thumb)
    local thumb = parent:CreateTexture(nil, "OVERLAY")
    thumb:SetSize(2, 14)
    thumb:SetPoint("CENTER", track, "LEFT", 0, 0)
    thumb:SetColorTexture(1, 1, 1, 1)

    -- Frame invisible pour capturer les clics/drag
    local hitbox = CreateFrame("Button", nil, parent)
    hitbox:SetSize(w, 18)
    hitbox:SetPoint("CENTER", track, "CENTER", 0, 0)
    hitbox:EnableMouse(true)

    local dragging = false
    local curVal = getValue()

    local function SetSliderValue(newVal)
        newVal = math.max(minV, math.min(maxV, newVal))
        newVal = math.floor(newVal / step + 0.5) * step
        curVal = newVal
        local pct = (newVal - minV) / (maxV - minV)
        fill:SetWidth(math.max(1, w * pct))
        thumb:SetPoint("CENTER", track, "LEFT", w * pct, 0)
        lbl:SetText(label .. " : " .. math.floor(newVal))
        valLbl:SetText(tostring(math.floor(newVal)))
        setValue(newVal)
    end

    local function GetMousePct()
        local mx = GetCursorPosition() / UIParent:GetEffectiveScale()
        local tx, _ = track:GetLeft(), track:GetBottom()
        local pct = math.max(0, math.min(1, (mx - tx) / w))
        return pct
    end

    hitbox:SetScript("OnMouseDown", function(s, btn)
        if btn == "LeftButton" then
            dragging = true
            SetSliderValue(minV + GetMousePct() * (maxV - minV))
        end
    end)
    hitbox:SetScript("OnMouseUp", function() dragging = false end)
    hitbox:SetScript("OnUpdate", function()
        if dragging then
            SetSliderValue(minV + GetMousePct() * (maxV - minV))
        end
    end)

    -- Scroll wheel
    hitbox:EnableMouseWheel(true)
    hitbox:SetScript("OnMouseWheel", function(_, delta)
        SetSliderValue(curVal + delta * step)
    end)

    SetSliderValue(curVal)
    return hitbox, y - 32
end

local function BuildSettingsTab(parent)
    local f=CreateFrame("Frame",nil,parent)
    f:SetPoint("TOPLEFT",parent,"TOPLEFT",SIDEBAR_W,CONTENT_Y)
    f:SetSize(PANEL_W,CONTENT_H+8); f:Hide()
    SM.BG(f, 0.07, 0.07, 0.10, 1)  -- fond opaque

    local y=-14
    local sep2=f:CreateTexture(nil,"ARTWORK"); sep2:SetSize(PANEL_W-16,1)
    sep2:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.4); y=y-10

    local alertCb = CreateFrame("CheckButton",nil,f,"UICheckButtonTemplate")
    alertCb:SetSize(22,22)
    alertCb:SetPoint("TOPLEFT",f,"TOPLEFT",8,y)
    alertCb:SetChecked(SolaryMDB.alerts_enabled ~= false)
    alertCb:SetScript("OnClick",function(s) SolaryMDB.alerts_enabled = s:GetChecked() end)
    local alertLbl = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    alertLbl:SetPoint("LEFT",alertCb,"RIGHT",4,0)
    alertLbl:SetText(SM.T("alerts_enabled"))
    alertLbl:SetTextColor(1,1,1,1)
    local alertDesc = f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    alertDesc:SetPoint("TOPLEFT",f,"TOPLEFT",34,y-18)
    alertDesc:SetTextColor(0.5,0.5,0.55,1)
    alertDesc:SetText(SM.T("alerts_desc"))
    y=y-46

    -- Pré-alerte boss
    local prealertLbl = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    prealertLbl:SetPoint("TOPLEFT",f,"TOPLEFT",8,y-4)
    prealertLbl:SetText(SM.T("prealert_label"))
    local prein=SM.Input(f,60,22,"5")
    prein:SetPoint("LEFT",prealertLbl,"RIGHT",6,0)
    SM.SetVal(prein,tostring((SolaryMDB.boss_timers and SolaryMDB.boss_timers.prealert_sec) or 5))
    prein:SetScript("OnTextChanged",function(s)
        local v=tonumber(SM.GetVal(s))
        if v and v>=1 and v<=30 then
            SolaryMDB.boss_timers=SolaryMDB.boss_timers or {}
            SolaryMDB.boss_timers.prealert_sec=v
        end
    end)
    y=y-34

    -- Private Aura Warning Text
    local pawCb = CreateFrame("CheckButton",nil,f,"UICheckButtonTemplate")
    pawCb:SetSize(22,22)
    pawCb:SetPoint("TOPLEFT",f,"TOPLEFT",8,y)
    pawCb:SetChecked(SolaryMDB.paw_enabled ~= false)
    pawCb:SetScript("OnClick",function(s)
        SolaryMDB.paw_enabled = s:GetChecked()
        SM.SetupPrivateWarningText()
    end)
    local pawLbl = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    pawLbl:SetPoint("LEFT",pawCb,"RIGHT",4,0)
    pawLbl:SetText(SM.T("paw_label"))
    pawLbl:SetTextColor(1,1,1,1)
    y=y-26

    -- Slider échelle
    local scaleVal = SolaryMDB.paw_scale or 2
    local scaleLbl = f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    scaleLbl:SetPoint("TOPLEFT",f,"TOPLEFT",32,y)
    scaleLbl:SetTextColor(0.55,0.55,0.6,1)
    scaleLbl:SetText(SM.T("paw_scale")..scaleVal)
    local scaleSlider = CreateFrame("Slider",nil,f,"MinimalSliderTemplate")
    scaleSlider:SetSize(160,16)
    scaleSlider:SetPoint("TOPLEFT",f,"TOPLEFT",100,y+2)
    scaleSlider:SetMinMaxValues(0.5,4)
    scaleSlider:SetValueStep(0.5)
    scaleSlider:SetValue(scaleVal)
    scaleSlider:SetScript("OnValueChanged",function(s,v)
        v = math.floor(v*10+0.5)/10
        SolaryMDB.paw_scale = v
        scaleLbl:SetText(SM.T("paw_scale")..v)
        SM.SetupPrivateWarningText()
    end)
    y=y-30

    -- Sons Private Auras — fenêtre séparée
    SM.Lbl(f,SM.T("pa_sounds"),"GameFontNormal",8,y,SM.OR); y=y-22

    -- Checkbox defaults
    local defCb = CreateFrame("CheckButton",nil,f,"UICheckButtonTemplate")
    defCb:SetSize(22,22); defCb:SetPoint("TOPLEFT",f,"TOPLEFT",8,y)
    defCb:SetChecked(SolaryMDB.pa_use_defaults ~= false)
    defCb:SetScript("OnClick",function(s)
        SolaryMDB.pa_use_defaults = s:GetChecked()
        SM.RegisterAllPASounds()
    end)
    local defLbl=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    defLbl:SetPoint("LEFT",defCb,"RIGHT",4,0)
    defLbl:SetText(SM.T("pa_defaults"))
    defLbl:SetTextColor(1,1,1,1)
    y=y-30

    SM.BBtn(f,200,26,SM.T("btn_edit_pa"),function()
        SM.OpenPASoundsWindow()
    end):SetPoint("TOPLEFT",f,"TOPLEFT",8,y)
    y=y-34

    local sepA=f:CreateTexture(nil,"ARTWORK"); sepA:SetSize(PANEL_W-16,1)
    sepA:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.4); y=y-12

    SM.Lbl(f,SM.T("frames_pos"),"GameFontNormal",8,y,SM.OR); y=y-20
    SM.Lbl(f,SM.T("frames_cmd"),nil,8,y)
    y=y-24

    SM.RBtn(f,200,24,SM.T("btn_lock"),function()
        if SM.LockAllFrames then SM.LockAllFrames() end
        SM.MoveMode = false
        
    end):SetPoint("TOPLEFT",f,"TOPLEFT",8,y)
    SM.OBtn(f,200,24,SM.T("btn_move"),function()
        if SM.UnlockAllFrames then SM.UnlockAllFrames() end
        SM.MoveMode = true
    end):SetPoint("TOPLEFT",f,"TOPLEFT",216,y)
    y=y-36

    local sep3=f:CreateTexture(nil,"ARTWORK"); sep3:SetSize(PANEL_W-16,1)
    sep3:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.4); y=y-16

    -- ── Apparence des alertes ─────────────────────────────
    SM.Lbl(f,SM.T("alert_appearance"),"GameFontNormal",8,y,SM.OR); y=y-26

    local function GetAlertW()  return (SolaryMDB.alert and SolaryMDB.alert.width)    or 380 end
    local function GetAlertFS() return (SolaryMDB.alert and SolaryMDB.alert.fontSize) or 22  end

    local slW, ny = MakeSlider(f, SM.T("alert_width"), 150, 700, 1, GetAlertW, function(v)
        SolaryMDB.alert = SolaryMDB.alert or {}
        SolaryMDB.alert.width = math.floor(v)
        if SM.SetAlertWidth then SM.SetAlertWidth(math.floor(v)) end
    end, 8, y, PANEL_W-200)
    y = ny

    local slFS, ny2 = MakeSlider(f, SM.T("alert_fontsize"), 10, 48, 1, GetAlertFS, function(v)
        SolaryMDB.alert = SolaryMDB.alert or {}
        SolaryMDB.alert.fontSize = math.floor(v)
    end, 8, y, PANEL_W-200)
    y = ny2

    local sep3b=f:CreateTexture(nil,"ARTWORK"); sep3b:SetSize(PANEL_W-16,1)
    sep3b:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.4); y=y-16

    SM.Lbl(f,SM.T("status_lbl"),"GameFontNormal",8,y,SM.OR); y=y-24
    local st=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    st:SetPoint("TOPLEFT",f,"TOPLEFT",8,y); st:SetTextColor(0.8,0.8,0.8,1)
    local bwS=BigWigsLoader and "|cFF55FF55BigWigs OK|r" or "|cFFAAAAAA—BigWigs|r"
    local dbS=DBM and "|cFF55FF55DBM OK|r" or "|cFFAAAAAA—DBM|r"
    local edS=SM.IsEditor() and ("|cFF55FF55"..SM.T("editor_lbl").."|r") or ("|cFFAAAAAAAA"..SM.T("reception_lbl").."|r")
    local spS="|cFFFFD700"..tostring(#SM.DefaultSpells).." "..SM.T("spells_loaded").."|r"
    st:SetText(bwS.."   "..dbS.."   "..edS.."   "..spS)
    y=y-30

    -- Break timer
    local sep3=f:CreateTexture(nil,"ARTWORK"); sep3:SetSize(PANEL_W-16,1)
    sep3:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.4); y=y-8

    if SM.IsEditor() or UnitIsGroupLeader("player") or UnitIsGroupAssistant("player") then
    SM.Lbl(f,SM.T("break_timer"),"GameFontNormal",8,y,SM.OR); y=y-16
    SM.Lbl(f,SM.T("break_desc"),nil,8,y); y=y-20

    -- Dropdown image break
    local breakImgSel = SM.T("random_lbl")
    local breakImgBtn = CreateFrame("Button",nil,f)
    breakImgBtn:SetSize(120,24); breakImgBtn:SetPoint("TOPLEFT",f,"TOPLEFT",8,y)
    local biBg=breakImgBtn:CreateTexture(nil,"BACKGROUND"); biBg:SetAllPoints(); biBg:SetColorTexture(0.12,0.12,0.16,1)
    local biBdr=breakImgBtn:CreateTexture(nil,"BORDER"); biBdr:SetAllPoints(); biBdr:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.25)
    local biLbl=breakImgBtn:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    biLbl:SetPoint("LEFT",breakImgBtn,"LEFT",6,0); biLbl:SetText(breakImgSel); biLbl:SetTextColor(0.9,0.9,0.9,1)
    local biArrow=breakImgBtn:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    biArrow:SetPoint("RIGHT",breakImgBtn,"RIGHT",-4,0); biArrow:SetText("v")

    local biMenu=CreateFrame("Frame",nil,f); biMenu:SetFrameStrata("TOOLTIP")
    biMenu:SetSize(120,22); biMenu:SetPoint("BOTTOMLEFT",breakImgBtn,"TOPLEFT",0,2)
    local biMenuBg=biMenu:CreateTexture(nil,"BACKGROUND"); biMenuBg:SetAllPoints(); biMenuBg:SetColorTexture(0.08,0.08,0.11,0.98)
    biMenu:Hide()

    breakImgBtn:SetScript("OnClick",function()
        if biMenu:IsShown() then biMenu:Hide(); return end
        for _,c in ipairs({biMenu:GetChildren()}) do c:Hide() end
        local imgs = {SM.T("random_lbl")}
        for _,n in ipairs(SM.MediaBreak or {}) do table.insert(imgs, n) end
        biMenu:SetHeight(#imgs*22)
        for i,name in ipairs(imgs) do
            local item=CreateFrame("Button",nil,biMenu)
            item:SetSize(120,22); item:SetPoint("TOPLEFT",biMenu,"TOPLEFT",0,-(i-1)*22)
            local ibg=item:CreateTexture(nil,"BACKGROUND"); ibg:SetAllPoints(); ibg:SetColorTexture(0,0,0,0)
            local ilbl=item:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            ilbl:SetPoint("LEFT",item,"LEFT",6,0); ilbl:SetText(name); ilbl:SetTextColor(0.85,0.85,0.9,1)
            item:SetScript("OnEnter",function() ibg:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.2) end)
            item:SetScript("OnLeave",function() ibg:SetColorTexture(0,0,0,0) end)
            local sn=name
            item:SetScript("OnClick",function()
                breakImgSel=sn; biLbl:SetText(sn); biMenu:Hide()
            end)
        end
        biMenu:Show()
    end)

    local durInput = SM.Input(f, 44, 24, "5")
    durInput:SetPoint("TOPLEFT",f,"TOPLEFT",134,y)
    SM.Lbl(f,"min",nil,184,y+6)

    local launchBreakBtn = SM.GBtn(f,110,26,SM.T("btn_launch_break"),function()
        biMenu:Hide()
        SM._breakForcedImage = (breakImgSel ~= SM.T("random_lbl")) and breakImgSel or nil
        local mins = tonumber(SM.GetVal(durInput)) or 5
        if SM.BroadcastBreak then SM.BroadcastBreak(mins * 60) end
    end)
    launchBreakBtn:SetPoint("TOPLEFT",f,"TOPLEFT",202,y)
    end -- fin if éditeur break



    return f
end

-- ============================================================
-- ONGLET 5 : NOTES / ASSIGNATIONS
-- ============================================================

-- ============================================================
-- BUILD + TOGGLE
-- ============================================================
-- ONGLET BOSS TIMERS
-- ============================================================
-- ============================================================
-- HELPER : Slider style BigWigs
-- ============================================================
local function BuildBossTimerTab(parent)
    local f = CreateFrame("Frame", nil, parent)
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", SIDEBAR_W, CONTENT_Y)
    f:SetSize(PANEL_W, CONTENT_H+8); f:Hide()
    SM.BG(f, 0.07, 0.07, 0.10, 1)

    local COL_W = math.floor((PANEL_W - 28) / 2)  -- deux colonnes égales

    -- ── COLONNE GAUCHE : Mécaniques intelligentes ────────
    local cL = CreateFrame("Frame", nil, f)
    cL:SetSize(COL_W, CONTENT_H-4)
    cL:SetPoint("TOPLEFT", f, "TOPLEFT", 8, -4)
    SM.BG(cL, SM.DK[1], SM.DK[2], SM.DK[3], 1)

    SM.Lbl(cL, SM.T("smart_header"), "GameFontNormal", 8, -8, SM.OR)
    SM.Lbl(cL, SM.T("smart_desc"), nil, 8, -26)

    local ly = -52
    if SM.SmartAlert then
        for _, mech in ipairs(SM.SmartAlert.GetMechanics()) do
            local ROW_H = 72
            local row = CreateFrame("Frame", nil, cL)
            row:SetSize(COL_W-16, ROW_H)
            row:SetPoint("TOPLEFT", cL, "TOPLEFT", 8, ly)
            SM.BG(row, 0.10, 0.10, 0.14, 1)

            local accent = row:CreateTexture(nil,"ARTWORK")
            accent:SetSize(2, ROW_H); accent:SetPoint("LEFT")
            accent:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 1)

            local cb = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
            cb:SetSize(22, 22)
            cb:SetPoint("LEFT", row, "LEFT", 8, 4)
            cb:SetChecked(SM.SmartAlert.IsEnabled(mech.id))
            local mechID = mech.id
            cb:SetScript("OnClick", function(s)
                SM.SmartAlert.SetEnabled(mechID, s:GetChecked())
            end)

            local _belorenSim = 0
            local _soakCast   = 0
            local testBtn = SM.GBtn(row, 44, 22, "Go", function()
                if mech.type == "group_soak_fixed" then
                    _soakCast = _soakCast + 1
                    local isOdd = (_soakCast % 2 == 1)
                    local sub = 1
                    local name = UnitName("player")
                    for i=1,40 do
                        local n,_,sg = GetRaidRosterInfo(i)
                        if n == name and sg then sub = sg; break end
                    end
                    local iMyTurn = (isOdd and sub <= 2) or (not isOdd and sub >= 3)
                    local msg
                    if iMyTurn then
                        msg = "|cFF00FF00SOAK|r"
                    else
                        msg = (SM.LANG == "fr") and "|cFFFF4444SOAK PAS|r" or "|cFFFF4444DONT SOAK|r"
                    end
                    if SM.ShowTimedAlert then SM.ShowTimedAlert(msg, nil, mech.duration) end
                elseif mech.type == "beloren_feather" then
                    _belorenSim = _belorenSim + 1
                    if _belorenSim % 2 == 1 then
                        if SM.Beloren then SM.Beloren._simulate("light") end
                    else
                        if SM.Beloren then SM.Beloren._simulate("void") end
                    end
                end
            end)
            testBtn:SetPoint("TOPRIGHT", row, "TOPRIGHT", -6, -8)

            local nameLbl = row:CreateFontString(nil,"OVERLAY","GameFontNormal")
            nameLbl:SetPoint("TOPLEFT", row, "TOPLEFT", 36, -8)
            nameLbl:SetPoint("RIGHT", testBtn, "LEFT", -6, 0)
            nameLbl:SetJustifyH("LEFT")
            nameLbl:SetTextColor(0.9, 0.9, 0.95, 1)
            nameLbl:SetText(mech.label)

            local descLbl = row:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
            descLbl:SetPoint("TOPLEFT", row, "TOPLEFT", 36, -24)
            descLbl:SetPoint("RIGHT", testBtn, "LEFT", -8, 0)
            descLbl:SetJustifyH("LEFT")
            descLbl:SetTextColor(0.5, 0.5, 0.55, 1)
            descLbl:SetText(SM.LANG == "fr" and (mech.desc_fr or mech.desc_en) or (mech.desc_en or mech.desc_fr))

            local bossLbl = row:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
            bossLbl:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", 36, 12)
            bossLbl:SetPoint("RIGHT", row, "RIGHT", -8, 0)
            bossLbl:SetJustifyH("LEFT")
            bossLbl:SetTextColor(SM.OR[1]*0.6, SM.OR[2]*0.6, SM.OR[3]*0.6, 1)
            bossLbl:SetText(mech.boss)

            ly = ly - (ROW_H + 6)
        end
    end

    -- ── COLONNE DROITE : Barres de cast ──────────────────
    local cR = CreateFrame("Frame", nil, f)
    cR:SetSize(COL_W, CONTENT_H-4)
    cR:SetPoint("TOPLEFT", cL, "TOPRIGHT", 12, 0)
    SM.BG(cR, SM.DK[1], SM.DK[2], SM.DK[3], 1)

    SM.Lbl(cR, SM.T("castbar_header"), "GameFontNormal", 8, -8, SM.OR)
    SM.Lbl(cR, SM.T("castbar_desc"), nil, 8, -26)

    local ry = -52
    if SM.CastBar then
        local testCBBtn = SM.GBtn(cR, 44, 22, "Go", function()
            -- Tester la première mécanique cochée
            for _, mech in ipairs(SM.CastBar.GetMechanics()) do
                if SM.CastBar.IsEnabled(mech.id) then
                    if SM.CastBar.Test then SM.CastBar.Test(mech.label, mech.duration) end
                    return
                end
            end
        end)
        testCBBtn:SetPoint("TOPRIGHT", cR, "TOPRIGHT", -8, -8)

        for _, mech in ipairs(SM.CastBar.GetMechanics()) do
            local ROW_H = 36
            local row = CreateFrame("Frame", nil, cR)
            row:SetSize(COL_W-16, ROW_H)
            row:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, ry)
            SM.BG(row, 0.10, 0.10, 0.14, 1)

            local accent = row:CreateTexture(nil,"ARTWORK")
            accent:SetSize(2, ROW_H); accent:SetPoint("LEFT")
            accent:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 1)

            local cb = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
            cb:SetSize(22, 22)
            cb:SetPoint("LEFT", row, "LEFT", 8, 0)
            cb:SetChecked(SM.CastBar.IsEnabled(mech.id))
            local mechID = mech.id
            cb:SetScript("OnClick", function(s)
                SM.CastBar.SetEnabled(mechID, s:GetChecked())
            end)

            local nameLbl = row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            nameLbl:SetPoint("TOPLEFT", row, "TOPLEFT", 36, -5)
            nameLbl:SetPoint("RIGHT", row, "RIGHT", -8, 0)
            nameLbl:SetJustifyH("LEFT")
            nameLbl:SetTextColor(0.9, 0.9, 0.95, 1)
            nameLbl:SetText(mech.label)

            local bossLbl = row:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
            bossLbl:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", 36, 5)
            bossLbl:SetPoint("RIGHT", row, "RIGHT", -8, 0)
            bossLbl:SetJustifyH("LEFT")
            bossLbl:SetTextColor(SM.OR[1]*0.6, SM.OR[2]*0.6, SM.OR[3]*0.6, 1)
            bossLbl:SetText(mech.boss)

            ry = ry - (ROW_H + 4)
        end
    end

    -- ── Section Mythic Casts ──────────────────────────────
    if SM.MythicCasts then
        ry = ry - 16
        SM.Lbl(cR, SM.T("mythic_casts_header"), "GameFontNormal", 8, ry + 6, SM.OR)

        local mcDesc = cR:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        mcDesc:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, ry - 10)
        mcDesc:SetPoint("RIGHT", cR, "RIGHT", -8, 0)
        mcDesc:SetJustifyH("LEFT")
        mcDesc:SetText(SM.T("mythic_casts_desc"))

        local mcUnlocked = false
        local goBtn = SM.GBtn(cR, 44, 22, "Go", function() end)
        goBtn:SetScript("OnClick", function()
            if mcUnlocked then
                mcUnlocked = false
                goBtn._fs:SetText("Go")
                if SM.MythicCasts.Lock then SM.MythicCasts.Lock() end
            else
                mcUnlocked = true
                goBtn._fs:SetText("Lock")
                if SM.MythicCasts.Unlock then SM.MythicCasts.Unlock() end
            end
        end)
        goBtn:SetPoint("TOPRIGHT", cR, "TOPRIGHT", -8, ry + 6)

        ry = ry - 28

        -- Checkbox activer/désactiver
        local mcRow = CreateFrame("Frame", nil, cR)
        local ROW_H2 = 30
        mcRow:SetSize(COL_W - 16, ROW_H2)
        mcRow:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, ry)
        SM.BG(mcRow, 0.10, 0.10, 0.14, 1)

        local mcAccent = mcRow:CreateTexture(nil, "ARTWORK")
        mcAccent:SetSize(2, ROW_H2); mcAccent:SetPoint("LEFT")
        mcAccent:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 1)

        local mcCB = CreateFrame("CheckButton", nil, mcRow, "UICheckButtonTemplate")
        mcCB:SetSize(22, 22)
        mcCB:SetPoint("LEFT", mcRow, "LEFT", 8, 0)
        mcCB:SetChecked(SM.MythicCasts.IsEnabled())
        mcCB:SetScript("OnClick", function(s)
            SM.MythicCasts.SetEnabled(s:GetChecked())
        end)

        local mcLbl = mcRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        mcLbl:SetPoint("TOPLEFT", mcRow, "TOPLEFT", 36, -5)
        mcLbl:SetPoint("RIGHT", mcRow, "RIGHT", -8, 0)
        mcLbl:SetJustifyH("LEFT")
        mcLbl:SetTextColor(0.9, 0.9, 0.95, 1)
        mcLbl:SetText(SM.T("mythic_casts_enable"))

        -- Slider de taille (scale)
        ry = ry - ROW_H2 - 4
        local scaleRow = CreateFrame("Frame", nil, cR)
        scaleRow:SetSize(COL_W - 16, ROW_H2)
        scaleRow:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, ry)
        SM.BG(scaleRow, 0.10, 0.10, 0.14, 1)
        local scAccent = scaleRow:CreateTexture(nil, "ARTWORK")
        scAccent:SetSize(2, ROW_H2); scAccent:SetPoint("LEFT")
        scAccent:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 1)

        local scTitleLbl = scaleRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        scTitleLbl:SetPoint("LEFT", scaleRow, "LEFT", 10, 0)
        scTitleLbl:SetTextColor(0.9, 0.9, 0.95, 1)
        scTitleLbl:SetText(SM.T("mythic_casts_scale"))

        local curScale = SM.MythicCasts.GetScale and SM.MythicCasts.GetScale() or 1.0
        local scValLbl = scaleRow:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        scValLbl:SetPoint("CENTER", scaleRow, "CENTER", 0, 0)
        scValLbl:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
        scValLbl:SetText(math.floor(curScale * 100 + 0.5) .. "%")

        local function applyScale(s)
            s = math.max(0.50, math.min(2.0, s))
            s = math.floor(s * 20 + 0.5) / 20  -- arrondi au 5% près
            scValLbl:SetText(math.floor(s * 100 + 0.5) .. "%")
            if SM.MythicCasts.SetScale then SM.MythicCasts.SetScale(s) end
            return s
        end

        local scMinBtn = SM.OBtn(scaleRow, 26, 22, "−", function()
            local s = (SM.MythicCasts.GetScale and SM.MythicCasts.GetScale() or 1.0) - 0.05
            applyScale(s)
        end)
        scMinBtn:SetPoint("RIGHT", scaleRow, "RIGHT", -36, 0)

        local scPlusBtn = SM.OBtn(scaleRow, 26, 22, "+", function()
            local s = (SM.MythicCasts.GetScale and SM.MythicCasts.GetScale() or 1.0) + 0.05
            applyScale(s)
        end)
        scPlusBtn:SetPoint("RIGHT", scaleRow, "RIGHT", -8, 0)
    end

    return f
end

-- ============================================================
local function BuildMemoryTab(parent)
    local f = CreateFrame("Frame", nil, parent)
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", SIDEBAR_W, CONTENT_Y)
    f:SetSize(PANEL_W, CONTENT_H+8); f:Hide()
    SM.BG(f, 0.07, 0.07, 0.10, 1)
    if SM.MemoryGame and SM.MemoryGame.BuildInputPanel then
        local p = SM.MemoryGame.BuildInputPanel(f, PANEL_W, CONTENT_H)
        p:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0)
    end
    return f
end

local function BuildVersionTab(parent)
    if SM.VersionCheck and SM.VersionCheck.BuildTab then
        local f = SM.VersionCheck.BuildTab(parent, PANEL_W, CONTENT_H+8)
        f:SetPoint("TOPLEFT", parent, "TOPLEFT", SIDEBAR_W, CONTENT_Y)
        return f
    end
    -- Fallback si module non chargé
    local f = CreateFrame("Frame", nil, parent)
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", SIDEBAR_W, CONTENT_Y)
    f:SetSize(PANEL_W, CONTENT_H+8); f:Hide()
    SM.BG(f, 0.07, 0.07, 0.10, 1)
    return f
end

local CHANGELOGS = {
    {
        version = "2.0.1",
        date    = "22 Avril 2026",
        fr = {
            "TOC — Passer en version 12.0.5 ",
            "Reminders — Erreur LUA du aux changements API fixé",
            "Reminders — Bouton Envoyer au raid a été placé sous la note, il ne gêne plus la box",
        },
        en = {
            "TOC — Updated to match 12.0.5",
            "Reminders — LUA errors caused by API changes fixed",
            "Reminders — Send to raid button is now under the note, no longer inside the box"
        },
    },
    {
        version = "2.0.0",
        date    = "21 Avril 2026",
        fr = {
            "Memory Game — L'ura (Midnight Falls) : affichage des runes en combat via CHAT_MSG_RAID",
            "Memory Game — icônes affichées via FontString + SetFormattedText",
            "Memory Game — bridge propre : RegisterEvent depuis contexte non-tainté (C_Timer + OnUpdate)",
            "Memory Game — icônes redimensionnées à 256px pour une lisibilité optimale en raid",
            "Memory Game — macros SOLMG_1..5 (7242384, etc.)",
            "Reminder — zone de collage de note avec scroll (plus de débordement sur les boutons)",
        },
        en = {
            "Memory Game — L'ura (Midnight Falls): rune display in combat via CHAT_MSG_RAID",
            "Memory Game — icons displayed via FontString + SetFormattedText",
            "Memory Game — clean bridge: RegisterEvent from untainted context (C_Timer + OnUpdate)",
            "Memory Game — icons resized to 256px for optimal raid readability",
            "Memory Game — SOLMG_1..5 (7242384, etc.)",
            "Reminder — note paste box now has a scroll (no more overflow onto buttons)",
        },
    },
    {
        version = "1.1.2",
        date    = "18 Avril 2026",
        fr = {
            "Mythic Casts — barre verte (interruptible) / grise (non interruptible)",
            "Mythic Casts — timer (ex: 3.2s) affiché à droite, coloré selon temps restant",
            "Mythic Casts — target inline à droite du nom du sort, colorée par classe",
            "Mythic Casts — filtrage des mobs hors combat avec le joueur",
            "Mythic Casts — icône affichée par-dessus la barre (corrige le recouvrement)",
            "Mythic Casts — slider de taille (50%–200%) dans le panel, sauvegardé",
            "Mythic Casts — correction du bouton Go (preview) dans le panel",
            "Correction erreur ADDON_ACTION_FORBIDDEN au login (RegisterEvent déplacé dans PLAYER_LOGIN)",
        },
        en = {
            "Mythic Casts — green bar (interruptible) / grey (not interruptible)",
            "Mythic Casts — timer (e.g. 3.2s) displayed on the right, color-coded by time left",
            "Mythic Casts — target inline right of spell name, class-colored",
            "Mythic Casts — filter out mobs not in combat with the player",
            "Mythic Casts — icon rendered above the bar fill (fixes overlap)",
            "Mythic Casts — size slider (50%–200%) in panel, saved between sessions",
            "Mythic Casts — fixed Go button (preview) in panel",
            "Fix ADDON_ACTION_FORBIDDEN error on login (RegisterEvent moved to PLAYER_LOGIN)",
        },
    },
    {
        version = "1.1.1",
        date    = "17 Avril 2026",
        fr = {
            "Module Mythic Casts — casts des adds en M+ et en raid (nameplates)",
            "Mythic Casts — affichage texte avec icône, décompte et target ciblée",
            "Mythic Casts — accent orange (interruptible) ou rouge (non interruptible)",
            "Mythic Casts — conteneur indépendant, déplaçable via Paramètres",
            "Mythic Casts — système de callouts : alerte centrale sur casts critiques",
            "Demiar (Crown) — callout STOP CAST sur Interrupting Tremor (1243743)",
            "Boutons — redesign : fond solide sombre, accent coloré gauche, hover propre",
            "Mode Move — les cadres désactivés n'apparaissent plus lors du déplacement",
            "Suppression des traductions FR de la SpellDB (193 entrées)",
        },
        en = {
            "Mythic Casts module — add casts in M+ and raid (nameplates)",
            "Mythic Casts — text display with icon, countdown and spell target",
            "Mythic Casts — orange accent (interruptible) or red (not interruptible)",
            "Mythic Casts — independent container, movable via Settings",
            "Mythic Casts — callout system: central alert on critical casts",
            "Demiar (Crown) — STOP CAST callout on Interrupting Tremor (1243743)",
            "Buttons — redesign: solid dark background, colored left accent, clean hover",
            "Move mode — disabled frames no longer appear when repositioning",
            "Removed FR translations from SpellDB (193 entries)",
        },
    },
    {
        version = "1.1.0",
        date    = "16 Avril 2026",
        fr = {
            "SmartCast — onglet renommé, réorganisé avec deux colonnes (mécaniques / alertes cast)",
            "Alertes cast — affichage texte décompté, conteneur séparé des alertes boss",
            "Alertes cast — support fixed, phased et spell_cast (détection CLEU)",
            "L'ura — Glaives, Transition (6.5s) et Intermission (30s) ajoutées",
            "Belo'ren — fenêtre Rebirth 30s détectée via CLEU (spellID 1263412)",
            "Belo'ren — icônes Light/Void depuis C_Spell.GetSpellTexture en simulation",
            "SmartAlert — descriptions traduites (desc_fr / desc_en)",
            "SmartAlert — SOAK / DONT SOAK sans labels de groupe",
            "Internationalisation complète FR/EN — bouton bascule dans le panel",
            "Pré-alerte déplacée dans Paramètres, s'applique aux alertes boss en général",
            "Suppression du doublon Media/break.tga (-1.4 Mo)",
        },
        en = {
            "SmartCast — tab renamed, reorganised with two columns (mechanics / cast alerts)",
            "Cast alerts — counted-down text display, container separate from boss alerts",
            "Cast alerts — fixed, phased and spell_cast support (CLEU detection)",
            "L'ura — Glaives, Transition (6.5s) and Intermission (30s) added",
            "Belo'ren — Rebirth 30s window detected via CLEU (spellID 1263412)",
            "Belo'ren — Light/Void icons from C_Spell.GetSpellTexture in simulation",
            "SmartAlert — translated descriptions (desc_fr / desc_en)",
            "SmartAlert — SOAK / DONT SOAK without group labels",
            "Full FR/EN internationalisation — toggle button in panel",
            "Pre-alert moved to Settings, applies to boss alerts in general",
            "Removed duplicate Media/break.tga (-1.4 MB)",
        },
    },
    {
        version = "1.0.5",
        date    = "15 Avril 2026",
        fr = {
            "Onglets dynamiques selon le rôle — éditeurs et non-éditeurs voient des onglets différents",
            "Non-éditeurs : uniquement Boss Timers, Paramètres, Changelogs",
            "Éditeurs : accès complet à tous les onglets",
            "Break Timer masqué pour les non-éditeurs",
            "Memory Game restreint aux éditeurs (envoi des symboles uniquement)",
            "Onglet Invites masqué pour les non-éditeurs",
            "Onglet Versions masqué pour les non-éditeurs",
            "Bouton Stop Break supprimé",
        },
        en = {
            "Dynamic tabs based on role — editors and non-editors see different tabs",
            "Non-editors: Boss Timers, Settings, Changelogs only",
            "Editors: full access to all tabs",
            "Break Timer hidden for non-editors",
            "Memory Game restricted to editors (symbol sending only)",
            "Invites tab hidden for non-editors",
            "Versions tab hidden for non-editors",
            "Stop Break button removed",
        },
    },
    {
        version = "1.0.4",
        date    = "15 Avril 2026",
        fr = {
            "Bouton minimap — icône Solary cliquable autour de la minimap via LibDBIcon",
            "Break Timer — images aléatoires sans répétition (shuffle)",
            "Break Timer — dropdown pour choisir une image spécifique ou aléatoire",
            "Break Timer — correction du bug stop/restart (timer de fade annulé proprement)",
            "Break Timer — correction du stop broadcast qui se déclenchait sur soi-même",
            "Sons Private Auras — sons baseline Midnight S1 Raid (29 sorts)",
            "Sons Private Auras — fenêtre dédiée avec liste scrollable",
            "Onglet Changelogs avec toggle Français/English",
        },
        en = {
            "Minimap button — Solary icon around the minimap via LibDBIcon",
            "Break Timer — random images without repetition (shuffle)",
            "Break Timer — dropdown to pick a specific or random image",
            "Break Timer — fixed stop/restart bug (fade timer properly cancelled)",
            "Break Timer — fixed stop broadcast triggering on self",
            "Private Aura Sounds — Midnight S1 Raid baseline sounds (29 spells)",
            "Private Aura Sounds — dedicated window with scrollable list",
            "Changelogs tab with French/English toggle",
        },
    },
    {
        version = "1.0.3",
        date    = "14 Avril 2026",
        fr = {
            "Sons Private Auras — fenêtre dédiée avec liste scrollable",
            "Sons Private Auras baseline Midnight S1 Raid intégrés (29 sorts)",
            "Activation/désactivation des sons par défaut via checkbox",
            "Correction Belo'ren — plus de gate ENCOUNTER_START, détection via UNIT_AURA directement",
            "Correction BossTimer — ProcessBWBar hors de portée (nil value)",
            "Correction Alert — barText secret ne plante plus sur :lower()",
            "Break Timer — images aléatoires depuis Media/Break/",
            "Scan automatique Media/Sounds et Media/Break au login",
            "Dropdown sons dynamique (liste depuis scan, pas hardcodée)",
            "Dropdown sons dans l'onglet Spells pour chaque mécanique",
            "Private Aura Warning Text — repositionnement précis via deux frames",
            "Suppression de la liste des éditeurs de l'onglet Paramètres",
        },
        en = {
            "Private Aura Sounds — dedicated window with scrollable list",
            "Midnight S1 Raid baseline PA sounds built-in (29 spells)",
            "Enable/disable default PA sounds via checkbox",
            "Belo'ren fix — removed ENCOUNTER_START gate, direct UNIT_AURA detection",
            "BossTimer fix — ProcessBWBar out of scope (nil value)",
            "Alert fix — secret barText no longer crashes on :lower()",
            "Break Timer — random images from Media/Break/",
            "Auto-scan Media/Sounds and Media/Break on login",
            "Dynamic sound dropdown (from scan, not hardcoded)",
            "Sound dropdown in Spells tab per mechanic",
            "Private Aura Warning Text — precise repositioning via two frames",
            "Removed editors list from Settings tab",
        },
    },
    {
        version = "1.0.2",
        date    = "13 Avril 2026",
        fr = {
            "Module Belo'ren — détection Light/Void Feather via filtrage UNIT_AURA",
            "Affichage icône de la plume au centre de l'écran pendant 5 secondes",
            "Private Aura Warning Text — repositionner le texte Blizzard via SetPrivateWarningTextAnchor",
            "Son par mécanique — dropdown dans l'onglet Spells",
            "Suppression de SolaryM_Auras.lua (inutilisé)",
        },
        en = {
            "Belo'ren module — Light/Void Feather detection via UNIT_AURA filter",
            "Feather icon display centered on screen for 5 seconds",
            "Private Aura Warning Text — reposition Blizzard text via SetPrivateWarningTextAnchor",
            "Sound per mechanic — dropdown in Spells tab",
            "Removed SolaryM_Auras.lua (unused)",
        },
    },
    {
        version = "1.0.1",
        date    = "12 Avril 2026",
        fr = {
            "Version Check — sections RAID et GUILDE séparées",
            "Version Check — affiche les membres sans l'addon en rouge (NON INSTALLÉ)",
            "Version Check — réponses via canal RAID/GUILD (WHISPER bloqué en Midnight)",
            "Break Timer — Stop Break broadcast au raid (cache l'image chez tout le monde)",
            "TTS — joue 2 secondes avant l'impact de la mécanique",
            "Paramètres — compactage pour faire rentrer le Break Timer dans le cadre",
        },
        en = {
            "Version Check — separate RAID and GUILD sections",
            "Version Check — members without addon shown in red (NOT INSTALLED)",
            "Version Check — replies via RAID/GUILD channel (WHISPER blocked in Midnight)",
            "Break Timer — Stop Break broadcast to raid (hides image for everyone)",
            "TTS — plays 2 seconds before mechanic impact",
            "Settings — compacted to fit Break Timer inside frame",
        },
    },
    {
        version = "1.0.0",
        date    = "11 Avril 2026",
        fr = {
            "Sortie initiale de SolaryM",
            "Onglet Spells — callouts par sort avec TTS, broadcast raid",
            "Boss Timers — alertes visuelles via hook BigWigs",
            "Invites — gestion des invitations raid",
            "Memory Game L'ura — barre de saisie + broadcast en temps réel",
            "Version Check — vérifier qui a l'addon dans le raid/guilde",
            "Paramètres — seuil d'affichage, taille alertes, break timer",
        },
        en = {
            "Initial release of SolaryM",
            "Spells tab — per-spell callouts with TTS, raid broadcast",
            "Boss Timers — visual alerts via BigWigs hook",
            "Invites — raid invitation management",
            "Memory Game L'ura — input bar + real-time broadcast",
            "Version Check — see who has the addon in raid/guild",
            "Settings — display threshold, alert size, break timer",
        },
    },
}

local function BuildChangelogsTab(parent)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(PANEL_W, CONTENT_H+8)
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", SIDEBAR_W, CONTENT_Y)
    f:Hide()
    local bg = f:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints()
    bg:SetColorTexture(0.07,0.07,0.10,1)

    local y = -14

    local title = f:CreateFontString(nil,"OVERLAY","GameFontNormal")
    title:SetPoint("TOPLEFT",f,"TOPLEFT",14,y)
    title:SetTextColor(SM.OR[1],SM.OR[2],SM.OR[3],1)
    title:SetText("Changelogs — SolaryM")
    y = y - 28

    -- Toggle langue
    local lang = "fr"
    local langBtn = SM.BBtn(f, 80, 22, "English", nil)
    langBtn:SetPoint("TOPRIGHT", f, "TOPRIGHT", -14, y+24)

    -- Scroll
    local scroll = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", f, "TOPLEFT", 14, y)
    scroll:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -30, 8)
    local scrollContent = CreateFrame("Frame", nil, scroll)
    scrollContent:SetSize(PANEL_W - 50, 1)
    scroll:SetScrollChild(scrollContent)

    -- Pré-créer toutes les FontStrings et les stocker pour update rapide
    local lineLabels = {}  -- { {vhdr, lines={}}, ... }

    local function BuildLines()
        local ry = 0
        for _, entry in ipairs(CHANGELOGS) do
            local vhdr = scrollContent:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
            vhdr:SetPoint("TOPLEFT", scrollContent, "TOPLEFT", 0, -ry)
            vhdr:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
            ry = ry + 22

            local sep = scrollContent:CreateTexture(nil,"ARTWORK")
            sep:SetSize(PANEL_W-60, 1)
            sep:SetPoint("TOPLEFT", scrollContent, "TOPLEFT", 0, -ry)
            sep:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.3)
            ry = ry + 8

            local entryLines = {}
            local maxLines = math.max(#entry.fr, #entry.en)
            for i = 1, maxLines do
                local dot = scrollContent:CreateFontString(nil,"OVERLAY","GameFontHighlight")
                dot:SetPoint("TOPLEFT", scrollContent, "TOPLEFT", 4, -ry)
                dot:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 0.7)
                dot:SetText("•")

                local lbl = scrollContent:CreateFontString(nil,"OVERLAY","GameFontHighlight")
                lbl:SetPoint("TOPLEFT", scrollContent, "TOPLEFT", 16, -ry)
                lbl:SetPoint("RIGHT", scrollContent, "RIGHT", -4, 0)
                lbl:SetJustifyH("LEFT")
                lbl:SetTextColor(0.8, 0.8, 0.85, 1)
                table.insert(entryLines, {dot=dot, lbl=lbl})
                ry = ry + 22
            end
            table.insert(lineLabels, {vhdr=vhdr, lines=entryLines, entry=entry})
            ry = ry + 20
        end
        scrollContent:SetHeight(math.max(ry, 1))
    end

    local function Rebuild()
        for _, block in ipairs(lineLabels) do
            local entry = block.entry
            block.vhdr:SetText("v"..entry.version.."  |cFF666666"..entry.date.."|r")
            local lines = lang == "fr" and entry.fr or entry.en
            for i, pair in ipairs(block.lines) do
                local txt = lines[i] or ""
                pair.lbl:SetText(txt)
                pair.dot:SetShown(txt ~= "")
                pair.lbl:SetShown(txt ~= "")
            end
        end
    end

    BuildLines()

    langBtn:SetScript("OnClick", function()
        if lang == "fr" then
            lang = "en"
            if langBtn._fs then langBtn._fs:SetText("Français") end
        else
            lang = "fr"
            if langBtn._fs then langBtn._fs:SetText("English") end
        end
        Rebuild()
    end)

    Rebuild()
    return f
end

-- ============================================================
-- ONGLET REMINDERS
-- ============================================================
local function BuildRemindersTab(parent)
    local RN = SM.ReminderNote
    local f = CreateFrame("Frame", nil, parent)
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", SIDEBAR_W, CONTENT_Y)
    f:SetSize(PANEL_W, CONTENT_H+8); f:Hide()
    SM.BG(f, 0.07, 0.07, 0.10, 1)

    local PAD = 14
    local COL = PANEL_W - PAD * 2
    local y = -PAD

    -- ── Pseudo / surnom ──────────────────────────────────────
    local nickHdr = f:CreateFontString(nil,"OVERLAY","GameFontNormal")
    nickHdr:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y)
    nickHdr:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
    nickHdr:SetText(SM.T("rem_nick_label"))
    y = y - 20

    local nickInput = SM.Input(f, 200, 22, SM.T("rem_nick_ph"))
    nickInput:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y)
    if SolaryMDB and SolaryMDB.reminder_nick then
        SM.SetVal(nickInput, SolaryMDB.reminder_nick)
    end
    nickInput:SetScript("OnTextChanged", function(s)
        SolaryMDB = SolaryMDB or {}
        SolaryMDB.reminder_nick = SM.GetVal(s)
    end)
    y = y - 34

    -- ── Séparateur ───────────────────────────────────────────
    local sep1 = f:CreateTexture(nil,"ARTWORK"); sep1:SetSize(COL, 1)
    sep1:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y)
    sep1:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.25)
    y = y - 12

    -- ── Import ───────────────────────────────────────────────
    local impHdr = f:CreateFontString(nil,"OVERLAY","GameFontNormal")
    impHdr:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y)
    impHdr:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
    impHdr:SetText(SM.T("rem_import_header"))
    y = y - 20

    local nameInput = SM.Input(f, COL, 22, SM.T("rem_name_ph"))
    nameInput:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y)
    y = y - 28

    -- Zone de texte multi-ligne dans un ScrollFrame pour éviter le débordement
    local pasteScroll = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
    pasteScroll:SetSize(COL - 20, 90)
    pasteScroll:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y)
    SM.BG(pasteScroll, 0.05, 0.05, 0.08, 1)
    local pasteBorder = pasteScroll:CreateTexture(nil, "BORDER")
    pasteBorder:SetHeight(1); pasteBorder:SetPoint("BOTTOMLEFT"); pasteBorder:SetPoint("BOTTOMRIGHT")
    pasteBorder:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.5)

    local pasteBox = CreateFrame("EditBox", nil, pasteScroll)
    pasteBox:SetWidth(COL - 38)
    pasteBox:SetAutoFocus(false)
    pasteBox:SetFontObject("GameFontHighlightSmall")
    pasteBox:SetTextColor(1, 1, 1, 1)
    pasteBox:SetMaxLetters(0)
    pasteBox:SetMultiLine(true)
    pasteBox:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
    pasteBox._hint = SM.T("rem_paste_ph") or ""
    pasteBox:SetText(pasteBox._hint)
    pasteBox:SetTextColor(0.45, 0.45, 0.45, 1)
    pasteBox:SetScript("OnEditFocusGained", function(s)
        if s:GetText() == (s._hint or "") then s:SetText(""); s:SetTextColor(1,1,1,1) end
    end)
    pasteBox:SetScript("OnEditFocusLost", function(s)
        if s:GetText() == "" then s:SetText(s._hint or ""); s:SetTextColor(0.45,0.45,0.45,1) end
    end)
    pasteScroll:SetScrollChild(pasteBox)
    y = y - 100

    local broadcastBtn = SM.BBtn(f, 130, 22, SM.T("rem_btn_broadcast") or "Envoyer au raid", nil)
    broadcastBtn:SetPoint("TOPRIGHT", f, "TOPRIGHT", -PAD, y + 0)
    broadcastBtn:SetScript("OnClick", function()
        if RN then RN.BroadcastNote() end
    end)

    local impBtn = SM.OBtn(f, 90, 22, SM.T("rem_btn_import"), nil)
    impBtn:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y)
    impBtn:SetScript("OnClick", function()
        if not RN then return end
        local name = SM.GetVal(nameInput)
        local content = SM.GetVal(pasteBox)
        if name == "" or content == "" then return end
        RN.Import(name, content)
        SM.SetVal(nameInput, "")
        SM.SetVal(pasteBox, "")
        f._refreshList()
    end)
    y = y - 36

    -- ── Séparateur ───────────────────────────────────────────
    local sep2 = f:CreateTexture(nil,"ARTWORK"); sep2:SetSize(COL, 1)
    sep2:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y)
    sep2:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.25)
    y = y - 12

    -- ── Notes sauvegardées ────────────────────────────────────
    local savedHdr = f:CreateFontString(nil,"OVERLAY","GameFontNormal")
    savedHdr:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y)
    savedHdr:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
    savedHdr:SetText(SM.T("rem_saved_header"))
    y = y - 20

    -- Note active
    local activeLbl = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    activeLbl:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y)
    activeLbl:SetTextColor(0.4, 0.9, 0.4, 1)
    activeLbl:SetText("")
    y = y - 20

    -- Bouton afficher note + test row
    local showNoteBtn = SM.BBtn(f, 120, 22, SM.T("rem_btn_shownote"), nil)
    showNoteBtn:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, y)
    showNoteBtn:SetScript("OnClick", function()
        if RN then RN.ToggleNote() end
    end)

    local encInput = SM.Input(f, 80, 22, "EncID")
    encInput:SetPoint("LEFT", showNoteBtn, "RIGHT", 10, 0)

    local testBtn = SM.OBtn(f, 60, 22, "Test", nil)
    testBtn:SetPoint("LEFT", encInput, "RIGHT", 4, 0)
    testBtn:SetScript("OnClick", function()
        if not RN then return end
        local id = SM.GetVal(encInput)
        if id == "" and RN.GetEncounterIDs then
            local ids = RN.GetEncounterIDs()
            id = ids[1] and tostring(ids[1]) or ""
        end
        if id ~= "" then RN.TestEncounter(id) end
    end)

    local stopBtn = SM.Btn(f, 60, 22, "Stop", SM.RED[1], SM.RED[2], SM.RED[3], nil)
    stopBtn:SetPoint("LEFT", testBtn, "RIGHT", 4, 0)
    stopBtn:SetScript("OnClick", function()
        if RN then RN.StopTest() end
    end)
    y = y - 34

    -- Liste scrollable des notes
    local listY = y
    local listScroll = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
    listScroll:SetSize(COL - 18, CONTENT_H + y - 8)
    listScroll:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, listY)
    local listContent = CreateFrame("Frame", nil, listScroll)
    listContent:SetSize(COL - 18, 1)
    listScroll:SetScrollChild(listContent)

    local rowFrames = {}

    local function RefreshList()
        -- Mettre à jour le label actif
        local active = SolaryMDB and SolaryMDB.active_reminder
        if active and active ~= "" then
            activeLbl:SetText(SM.T("rem_active_prefix") .. "|cffffffff" .. active .. "|r")
        else
            activeLbl:SetText("")
        end

        -- Cacher tous les anciens rows
        for _, row in ipairs(rowFrames) do row:Hide() end

        if not RN then return end
        local names = RN.GetNames()
        if #names == 0 then
            if not listContent._emptyLbl then
                listContent._emptyLbl = listContent:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
                listContent._emptyLbl:SetPoint("TOPLEFT", listContent, "TOPLEFT", 0, -8)
                listContent._emptyLbl:SetTextColor(0.4,0.4,0.45,1)
            end
            listContent._emptyLbl:SetText(SM.T("rem_no_notes"))
            listContent._emptyLbl:Show()
            listContent:SetHeight(30)
            return
        end
        if listContent._emptyLbl then listContent._emptyLbl:Hide() end

        local ry = 0
        for i, name in ipairs(names) do
            local row = rowFrames[i]
            if not row then
                row = CreateFrame("Frame", nil, listContent, "BackdropTemplate")
                row:SetSize(COL - 18, 28)
                row:SetBackdrop({bgFile="Interface\\Buttons\\WHITE8X8"})
                table.insert(rowFrames, row)
            end
            row:SetPoint("TOPLEFT", listContent, "TOPLEFT", 0, -ry)
            local isActive = (SolaryMDB and SolaryMDB.active_reminder == name)
            row:SetBackdropColor(isActive and 0.08 or 0.05, isActive and 0.10 or 0.05, isActive and 0.05 or 0.05, 1)

            if not row._nameLbl then
                row._nameLbl = row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
                row._nameLbl:SetPoint("LEFT", row, "LEFT", 6, 0)
                row._nameLbl:SetPoint("RIGHT", row, "RIGHT", -326, 0)
                row._nameLbl:SetJustifyH("LEFT")
            end
            row._nameLbl:SetText(name)
            row._nameLbl:SetTextColor(isActive and 0.4 or 0.8, isActive and 0.9 or 0.8, isActive and 0.4 or 0.85, 1)

            if not row._actBtn then
                row._actBtn = SM.OBtn(row, 80, 20, SM.T("rem_btn_activate"), nil)
                row._actBtn:SetPoint("RIGHT", row, "RIGHT", -240, 0)
            end
            row._actBtn:SetScript("OnClick", function()
                if RN then RN.SetActive(name) end
                f._refreshList()
            end)

            if not row._editBtn then
                row._editBtn = SM.Btn(row, 70, 20, "Éditer", 0.1, 0.2, 0.45, nil)
                row._editBtn:SetPoint("RIGHT", row, "RIGHT", -164, 0)
            end
            row._editBtn:SetScript("OnClick", function()
                if RN then RN.OpenNoteInEditMode(name) end
            end)

            if not row._sendBtn then
                row._sendBtn = SM.Btn(row, 70, 20, "Envoyer", 0.1, 0.35, 0.1, nil)
                row._sendBtn:SetPoint("RIGHT", row, "RIGHT", -88, 0)
            end
            row._sendBtn:SetScript("OnClick", function()
                if RN then RN.SendNote(name) end
            end)

            if not row._delBtn then
                row._delBtn = SM.Btn(row, 80, 20, SM.T("rem_btn_delete"), SM.RED[1], SM.RED[2], SM.RED[3], nil)
                row._delBtn:SetPoint("RIGHT", row, "RIGHT", -2, 0)
            end
            row._delBtn:SetScript("OnClick", function()
                if RN then RN.Delete(name) end
                f._refreshList()
            end)

            row:Show()
            ry = ry + 30
        end
        listContent:SetHeight(math.max(ry, 1))
    end

    f._refreshList = RefreshList
    f:SetScript("OnShow", RefreshList)
    return f
end

-- ============================================================
-- FENÊTRE PRIVATE AURA SOUNDS
-- ============================================================
local paSoundsWindow = nil


local function Build()
    if mainFrame then return end

    -- ─── Frame principale ─────────────────────────────────
    mainFrame = CreateFrame("Frame","SolaryMPanel",UIParent,"BasicFrameTemplateWithInset")
    mainFrame:SetSize(TOTAL_W, PANEL_H)
    mainFrame:SetPoint("CENTER")
    mainFrame:SetMovable(true); mainFrame:EnableMouse(true)
    mainFrame:RegisterForDrag("LeftButton")
    mainFrame:SetScript("OnDragStart", mainFrame.StartMoving)
    mainFrame:SetScript("OnDragStop",  mainFrame.StopMovingOrSizing)
    mainFrame:SetFrameStrata("DIALOG")
    mainFrame.TitleText:SetText("|cFFFFAA00SolaryM|r  —  RL Suite")

    -- Bouton langue FR / EN — en haut à droite, à gauche du CloseButton
    local langBtn = CreateFrame("Button", nil, mainFrame)
    langBtn:SetSize(38, 18)
    langBtn:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", -24, -5)
    local langBg = langBtn:CreateTexture(nil, "BACKGROUND")
    langBg:SetAllPoints(); langBg:SetColorTexture(0.12, 0.12, 0.16, 1)
    local langBdr = langBtn:CreateTexture(nil, "BORDER")
    langBdr:SetAllPoints(); langBdr:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.5)
    local langLbl = langBtn:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    langLbl:SetPoint("CENTER"); langLbl:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
    langLbl:SetText(SM.LANG == "fr" and "FR" or "EN")
    langBtn:SetScript("OnClick", function()
        SM.SetLang(SM.LANG == "fr" and "en" or "fr")
        local prevTab = activeTab
        mainFrame:Hide()
        mainFrame = nil
        wipe(tabBtns)
        wipe(tabFrames)
        Build()
        ShowTab(prevTab <= #tabFrames and prevTab or 1)
        if SM.IsEditor() and prevTab == 1 then SM.RefreshSpellList() end
        mainFrame:Show()
    end)
    langBtn:SetScript("OnEnter", function() langBdr:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 1) end)
    langBtn:SetScript("OnLeave", function() langBdr:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.5) end)

    -- Fond opaque couvrant tout le panel
    local panelBg = mainFrame:CreateTexture(nil, "BACKGROUND", nil, -7)
    panelBg:SetAllPoints()
    panelBg:SetColorTexture(0.07, 0.07, 0.10, 1)

    -- Ligne orange sous le titre
    local titleLine = mainFrame:CreateTexture(nil,"ARTWORK")
    titleLine:SetSize(TOTAL_W-20, 1)
    titleLine:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 10, -26)
    titleLine:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.6)

    -- ─── Sidebar gauche ───────────────────────────────────
    local sidebar = CreateFrame("Frame", nil, mainFrame)
    sidebar:SetSize(SIDEBAR_W, PANEL_H - 30)
    sidebar:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 6, -28)
    SM.BG(sidebar, 0.07, 0.07, 0.10, 1)

    -- Ligne de séparation sidebar / contenu
    local sideDiv = mainFrame:CreateTexture(nil,"ARTWORK")
    sideDiv:SetSize(1, PANEL_H - 30)
    sideDiv:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", SIDEBAR_W + 6, -28)
    sideDiv:SetColorTexture(0.18, 0.18, 0.22, 1)

    -- Logo / titre dans la sidebar
    local sideLogo = sidebar:CreateFontString(nil,"OVERLAY","GameFontNormal")
    sideLogo:SetPoint("TOPLEFT", sidebar, "TOPLEFT", 10, -12)
    sideLogo:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
    sideLogo:SetText("|cFFFFAA00S|rolaryM")

    local sideVer = sidebar:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    sideVer:SetPoint("TOPLEFT", sidebar, "TOPLEFT", 10, -28)
    sideVer:SetTextColor(0.35, 0.35, 0.35, 1)
    sideVer:SetText("v"..SM.VERSION)

    -- ─── Onglets verticaux ────────────────────────────────
    local tabNames
    if SM.IsEditor() then
        tabNames = {SM.T("tab_spells"),SM.T("tab_smartcast"),SM.T("tab_invites"),SM.T("tab_memory"),SM.T("tab_versions"),SM.T("tab_settings"),SM.T("tab_changelogs"),SM.T("tab_reminders")}
    else
        tabNames = {SM.T("tab_smartcast"),SM.T("tab_settings"),SM.T("tab_changelogs"),SM.T("tab_reminders")}
    end
    local TAB_BTN_H = 32
    local TAB_BTN_W = SIDEBAR_W - 2

    local function MakeSideTab(idx, name, yOff)
        local tb = CreateFrame("Button", nil, sidebar)
        tb:SetSize(TAB_BTN_W, TAB_BTN_H)
        tb:SetPoint("TOPLEFT", sidebar, "TOPLEFT", 0, yOff)

        local bg = tb:CreateTexture(nil,"BACKGROUND")
        bg:SetAllPoints(); bg:SetColorTexture(0.08, 0.08, 0.11, 1)
        tb._bg = bg

        -- Trait actif sur la gauche
        local accent = tb:CreateTexture(nil,"ARTWORK")
        accent:SetSize(2, TAB_BTN_H)
        accent:SetPoint("LEFT", tb, "LEFT", 0, 0)
        accent:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 1)
        accent:Hide()
        tb._accent = accent

        local lbl = tb:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
        lbl:SetPoint("LEFT", tb, "LEFT", 14, 0)
        lbl:SetJustifyH("LEFT")
        lbl:SetTextColor(0.55, 0.55, 0.6, 1)
        lbl:SetText(name)
        tb._lbl = lbl

        tb:SetScript("OnEnter", function(s)
            if activeTab ~= idx then
                s._bg:SetColorTexture(0.12, 0.12, 0.15, 1)
                s._lbl:SetTextColor(0.9, 0.9, 0.9, 1)
            end
        end)
        tb:SetScript("OnLeave", function(s)
            if activeTab ~= idx then
                s._bg:SetColorTexture(0.08, 0.08, 0.11, 1)
                s._lbl:SetTextColor(0.55, 0.55, 0.6, 1)
            end
        end)

        local i = idx
        tb:SetScript("OnClick", function() ShowTab(i) end)
        table.insert(tabBtns, tb)
    end

    local startY = -52
    for i, name in ipairs(tabNames) do
        MakeSideTab(i, name, startY - (i-1) * (TAB_BTN_H + 2))
    end

    -- ─── Contenu des onglets ─────────────────────────────
    if SM.IsEditor() then
        tabFrames[1] = BuildSpellsTab(mainFrame)
        SM._spellTabFrame = tabFrames[1]
        tabFrames[2] = BuildBossTimerTab(mainFrame)
        tabFrames[3] = BuildInviteTab(mainFrame)
        tabFrames[4] = BuildMemoryTab(mainFrame)
        tabFrames[5] = BuildVersionTab(mainFrame)
        tabFrames[6] = BuildSettingsTab(mainFrame)
        tabFrames[7] = BuildChangelogsTab(mainFrame)
        tabFrames[8] = BuildRemindersTab(mainFrame)
    else
        tabFrames[1] = BuildBossTimerTab(mainFrame)
        tabFrames[2] = BuildSettingsTab(mainFrame)
        tabFrames[3] = BuildChangelogsTab(mainFrame)
        tabFrames[4] = BuildRemindersTab(mainFrame)
    end

    mainFrame:Hide()
end

function SM.TogglePanel()
    Build()
    if mainFrame:IsShown() then
        mainFrame:Hide()
    else
        SolaryMDB=SolaryMDB or {}
        if SM.IsEditor() then
            ShowTab(1)
            SM.RefreshSpellList()
        else
            ShowTab(1)  -- Boss Timers est tab 1 pour non-éditeurs
        end
        mainFrame:Show()
    end
end

-- SM.OpenPanel = alias pour SM.TogglePanel (appelé par Core)
-- Met à jour le label "N changements en attente" dans l'onglet Spells
function SM._UpdatePendingCount()
    local f = SM._spellTabFrame
    if not f or not f._pendingLbl then return end
    local n = 0
    for _ in pairs(SM.PendingSpellChanges) do n = n + 1 end
    if n == 0 then
        f._pendingLbl:SetText(SM.T("pending_none"))
        f._pendingLbl:SetTextColor(0.5, 0.5, 0.5, 1)
    elseif n == 1 then
        f._pendingLbl:SetText("|cFFFFAA00"..SM.T("pending_one").."|r — "..SM.T("pending_ready"))
        f._pendingLbl:SetTextColor(1, 0.82, 0, 1)
    else
        f._pendingLbl:SetText("|cFFFFAA00"..n.." "..SM.T("pending_multi").."|r — "..SM.T("pending_ready_pl"))
        f._pendingLbl:SetTextColor(1, 0.82, 0, 1)
    end
end

SM.OpenPanel = SM.TogglePanel


-- ============================================================
-- ONGLET CHANGELOGS
-- ============================================================

function SM.OpenPASoundsWindow()
    if paSoundsWindow then
        if paSoundsWindow:IsShown() then paSoundsWindow:Hide() else paSoundsWindow:Show() end
        return
    end

    local W, H = 500, 560
    paSoundsWindow = CreateFrame("Frame", "SolaryMPASoundsWindow", UIParent, "BackdropTemplate")
    paSoundsWindow:SetSize(W, H)
    paSoundsWindow:SetPoint("CENTER", UIParent, "CENTER", 200, 0)
    paSoundsWindow:SetFrameStrata("DIALOG")
    paSoundsWindow:SetMovable(true)
    paSoundsWindow:EnableMouse(true)
    paSoundsWindow:RegisterForDrag("LeftButton")
    paSoundsWindow:SetScript("OnDragStart", paSoundsWindow.StartMoving)
    paSoundsWindow:SetScript("OnDragStop", paSoundsWindow.StopMovingOrSizing)
    paSoundsWindow:SetBackdrop({bgFile="Interface\Buttons\WHITE8X8", edgeFile="Interface\Buttons\WHITE8X8", edgeSize=1})
    paSoundsWindow:SetBackdropColor(0.06,0.06,0.09,0.98)
    paSoundsWindow:SetBackdropBorderColor(SM.OR[1],SM.OR[2],SM.OR[3],0.5)

    -- Titre
    local title = paSoundsWindow:CreateFontString(nil,"OVERLAY","GameFontNormal")
    title:SetPoint("TOP",paSoundsWindow,"TOP",0,-10)
    title:SetTextColor(SM.OR[1],SM.OR[2],SM.OR[3],1)
    title:SetText("Sons Private Auras")

    -- Bouton fermer
    SM.RBtn(paSoundsWindow,60,22,SM.T("btn_close"),function() paSoundsWindow:Hide() end):SetPoint("TOPRIGHT",paSoundsWindow,"TOPRIGHT",-8,-6)

    -- Background complet (titre + liste + barre ajout)
    local fullBg=paSoundsWindow:CreateTexture(nil,"BACKGROUND")
    fullBg:SetPoint("TOPLEFT",paSoundsWindow,"TOPLEFT",1,-1)
    fullBg:SetPoint("BOTTOMRIGHT",paSoundsWindow,"BOTTOMRIGHT",-1,1)
    fullBg:SetColorTexture(0.06,0.06,0.09,1)

    -- Background zone liste (légèrement différent)
    local listBg=paSoundsWindow:CreateTexture(nil,"BACKGROUND")
    listBg:SetPoint("TOPLEFT",paSoundsWindow,"TOPLEFT",8,-28)
    listBg:SetPoint("BOTTOMRIGHT",paSoundsWindow,"BOTTOMRIGHT",-8,88)
    listBg:SetColorTexture(0.04,0.04,0.07,1)

    -- Headers
    local function Hdr(txt,x)
        local h=paSoundsWindow:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
        h:SetPoint("TOPLEFT",paSoundsWindow,"TOPLEFT",x,-32)
        h:SetTextColor(0.35,0.35,0.4,1); h:SetText(txt)
    end
    Hdr(SM.T("col_spell"),12); Hdr("SPELLID",230); Hdr(SM.T("col_sound"),310)

    local sep=paSoundsWindow:CreateTexture(nil,"ARTWORK"); sep:SetSize(W-16,1)
    sep:SetPoint("TOPLEFT",paSoundsWindow,"TOPLEFT",8,-44)
    sep:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.3)

    -- Scroll list
    local scroll=CreateFrame("ScrollFrame",nil,paSoundsWindow,"UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT",paSoundsWindow,"TOPLEFT",8,-50)
    scroll:SetPoint("BOTTOMRIGHT",paSoundsWindow,"BOTTOMRIGHT",-28,90)
    local scrollContent=CreateFrame("Frame",nil,scroll)
    scrollContent:SetSize(W-36,1)
    scroll:SetScrollChild(scrollContent)

    local function MakeDropdown(parent, x, y, w, getVal, onSelect)
        local btn=CreateFrame("Button",nil,parent)
        btn:SetSize(w,22); btn:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
        local bg=btn:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints(); bg:SetColorTexture(0.1,0.1,0.14,1)
        local bdr=btn:CreateTexture(nil,"BORDER"); bdr:SetAllPoints(); bdr:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.2)
        local lbl=btn:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        lbl:SetPoint("LEFT",btn,"LEFT",6,0); lbl:SetText(getVal()); lbl:SetTextColor(0.9,0.9,0.9,1)
        local arr=btn:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
        arr:SetPoint("RIGHT",btn,"RIGHT",-4,0); arr:SetText("v")

        local menu=CreateFrame("Frame",nil,paSoundsWindow); menu:SetFrameStrata("TOOLTIP")
        menu:SetSize(w,22); menu:SetPoint("TOPLEFT",btn,"BOTTOMLEFT",0,-2)
        local mbg=menu:CreateTexture(nil,"BACKGROUND"); mbg:SetAllPoints(); mbg:SetColorTexture(0.06,0.06,0.09,0.98)
        menu:Hide()

        btn:SetScript("OnClick",function()
            if menu:IsShown() then menu:Hide(); return end
            for _,c in ipairs({menu:GetChildren()}) do c:Hide() end
            local sounds={"(aucun)"}
            for _, s in ipairs(SM.MediaSounds or {}) do table.insert(sounds, s) end
            menu:SetHeight(#sounds*22)
            for i,sname in ipairs(sounds) do
                local item=CreateFrame("Button",nil,menu)
                item:SetSize(w,22); item:SetPoint("TOPLEFT",menu,"TOPLEFT",0,-(i-1)*22)
                local ibg=item:CreateTexture(nil,"BACKGROUND"); ibg:SetAllPoints(); ibg:SetColorTexture(0,0,0,0)
                local ilbl=item:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
                ilbl:SetPoint("LEFT",item,"LEFT",6,0); ilbl:SetText(sname); ilbl:SetTextColor(0.85,0.85,0.9,1)
                item:SetScript("OnEnter",function() ibg:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.2) end)
                item:SetScript("OnLeave",function() ibg:SetColorTexture(0,0,0,0) end)
                local sn=sname
                item:SetScript("OnClick",function() lbl:SetText(sn); onSelect(sn); menu:Hide() end)
            end
            menu:Show()
        end)
        return btn, lbl
    end

    local function RefreshList()
        for _,c in ipairs({scrollContent:GetChildren()}) do c:Hide() end
        SolaryMDB.pa_sounds = SolaryMDB.pa_sounds or {}

        -- Construire liste combinée : defaults + custom
        local rows = {}
        if SolaryMDB.pa_use_defaults ~= false then
            for id, snd in pairs(SM.PA_DEFAULTS_RAID) do
                local custom = SolaryMDB.pa_sounds[id]
                rows[id] = {sound=custom or snd, isDefault=(custom==nil), isCustom=(custom~=nil)}
            end
        end
        for id, snd in pairs(SolaryMDB.pa_sounds) do
            if not rows[id] then rows[id]={sound=snd, isDefault=false, isCustom=true} end
        end

        -- Trier par nom de sort
        local sorted = {}
        for id, info in pairs(rows) do
            local si = C_Spell.GetSpellInfo(id)
            table.insert(sorted, {id=id, name=(si and si.name or "SpellID "..id), sound=info.sound, isDefault=info.isDefault, isCustom=info.isCustom})
        end
        table.sort(sorted, function(a,b) return a.name < b.name end)

        local ry = 0
        local ROW_H = 26
        for i, entry in ipairs(sorted) do
            local row=CreateFrame("Frame",nil,scrollContent)
            row:SetSize(W-36,ROW_H); row:SetPoint("TOPLEFT",scrollContent,"TOPLEFT",0,-ry)
            local rb=row:CreateTexture(nil,"BACKGROUND"); rb:SetAllPoints()
            if i%2==0 then rb:SetColorTexture(0.09,0.09,0.12,1) else rb:SetColorTexture(0.06,0.06,0.09,1) end

            -- Nom du sort
            local nl=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            nl:SetPoint("LEFT",row,"LEFT",4,0); nl:SetWidth(218)
            nl:SetJustifyH("LEFT")
            -- Truncate name to avoid overflow
            local dispName = entry.name
            nl:SetText(dispName)
            nl:SetTextColor(entry.isDefault and 0.5 or 0.9, entry.isDefault and 0.5 or 0.9, entry.isDefault and 0.55 or 0.9, 1)

            -- SpellID
            local il=row:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
            il:SetPoint("LEFT",row,"LEFT",222,0)
            il:SetText(tostring(entry.id)); il:SetTextColor(0.35,0.35,0.4,1)

            -- Dropdown son
            local eid = entry.id
            local _, sndLbl = MakeDropdown(row, 300, -2, 130, function() return entry.sound end, function(sn)
                SolaryMDB.pa_sounds[eid] = sn
                SM.RegisterPASound(eid, sn)
                RefreshList()
            end)
            sndLbl:SetText(entry.sound)

            -- Bouton supprimer (custom seulement)
            if entry.isCustom or not entry.isDefault then
                SM.RBtn(row,22,20,"x",function()
                    SolaryMDB.pa_sounds[eid]=nil
                    SM.RegisterPASound(eid,nil)
                    RefreshList()
                end):SetPoint("RIGHT",row,"RIGHT",-2,0)
            end

            ry = ry + ROW_H
        end

        if #sorted == 0 then
            local el=scrollContent:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
            el:SetPoint("TOPLEFT",scrollContent,"TOPLEFT",4,0)
            el:SetTextColor(0.4,0.4,0.45,1); el:SetText(SM.T("pa_empty"))
        end

        scrollContent:SetHeight(math.max(ry,22))
    end

    -- Barre d'ajout — ancrée en bas de la fenêtre
    local addBar=CreateFrame("Frame",nil,paSoundsWindow)
    addBar:SetSize(W-16,32); addBar:SetPoint("BOTTOMLEFT",paSoundsWindow,"BOTTOMLEFT",8,52)

    local addId=SM.Input(addBar,90,24,"SpellID")
    addId:SetPoint("LEFT",addBar,"LEFT",0,0)

    local addSndSel = (SM.MediaSounds and SM.MediaSounds[1]) or "Soak"
    local _, addSndLbl = MakeDropdown(addBar, 96, -3, 150, function() return addSndSel end, function(sn)
        addSndSel = sn
    end)

    SM.GBtn(addBar,60,24,"Add",function()
        local id=tonumber(SM.GetVal(addId))
        if not id then SM.Print(SM.T("invalid_spellid")); return end
        SolaryMDB.pa_sounds=SolaryMDB.pa_sounds or {}
        SolaryMDB.pa_sounds[id]=addSndSel
        SM.RegisterPASound(id,addSndSel)
        SM.SetVal(addId,"")
        RefreshList()
    end):SetPoint("LEFT",addBar,"LEFT",252,0)

    SM.RBtn(addBar,100,24,SM.T("btn_delete_all"),function()
        SolaryMDB.pa_sounds={}
        SM.PASoundIDs={}
        RefreshList()
    end):SetPoint("RIGHT",addBar,"RIGHT",-4,0)

    local sep2=paSoundsWindow:CreateTexture(nil,"ARTWORK"); sep2:SetSize(W-16,1)
    sep2:SetPoint("BOTTOMLEFT",paSoundsWindow,"BOTTOMLEFT",8,86)
    sep2:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.3)

    RefreshList()
    paSoundsWindow:Show()
end
