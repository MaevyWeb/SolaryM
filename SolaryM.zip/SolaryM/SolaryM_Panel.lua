-- SolaryM_Panel.lua
-- v2.0.5 — Onglets : Spells | Boss Timers | Groupes | Invites | Memory Game | Paramètres | Changelogs | Notes

local mainFrame = nil
local activeTab = 1

local tabBtns   = {}
local tabFrames = {}

local PANEL_W   = 940   -- largeur zone de contenu
local PANEL_H   = 780
local HEADER_H  = 48    -- hauteur header custom
local SIDEBAR_W = 200   -- sidebar gauche avec onglets verticaux
local TOTAL_W   = PANEL_W + SIDEBAR_W
local TAB_H     = 32    -- gardé pour compatibilité
local CONTENT_Y = -HEADER_H  -- offset sous le header
local CONTENT_H = PANEL_H + CONTENT_Y - 8

-- ============================================================
-- TABS
-- ============================================================
local function ShowTab(idx)
    activeTab = idx
    for i, tb in ipairs(tabBtns) do
        if tb._bg then
            if i == idx then
                tb._bg:SetColorTexture(0.12, 0.07, 0.20, 1)
                if tb._lbl    then tb._lbl:SetTextColor(0.90, 0.82, 1.0, 1) end
                if tb._accent then tb._accent:Show() end
                if tb._ico    then tb._ico:SetVertexColor(SM.OR[1], SM.OR[2], SM.OR[3], 1) end
            else
                tb._bg:SetColorTexture(0, 0, 0, 0)
                if tb._lbl    then tb._lbl:SetTextColor(0.55, 0.50, 0.62, 1) end
                if tb._accent then tb._accent:Hide() end
                if tb._ico    then tb._ico:SetVertexColor(0.48, 0.42, 0.58, 1) end
            end
        end
    end
    for i, f in ipairs(tabFrames) do if f then f:SetShown(i==idx) end end
end

-- ============================================================
-- MODAL : AJOUTER UN SORT
-- ============================================================
local addSpellModal = nil

local function OpenAddSpellModal()
    if addSpellModal then
        addSpellModal._reset()
        addSpellModal:ClearAllPoints()
        addSpellModal:SetPoint("TOPLEFT", mainFrame, "TOPRIGHT", 8, 0)
        addSpellModal:Show()
        addSpellModal:Raise()
        return
    end

    local W, H = 440, 360
    local modal = CreateFrame("Frame", "SolaryMAddSpellModal", UIParent)
    addSpellModal = modal
    modal:SetSize(W, H)
    modal:SetPoint("TOPLEFT", mainFrame, "TOPRIGHT", 8, 0)
    modal:SetFrameStrata("FULLSCREEN_DIALOG")
    modal:SetMovable(true)
    modal:EnableMouse(true)
    modal:RegisterForDrag("LeftButton")
    modal:SetScript("OnDragStart", modal.StartMoving)
    modal:SetScript("OnDragStop",  modal.StopMovingOrSizing)
    tinsert(UISpecialFrames, "SolaryMAddSpellModal")

    -- Bordure + fond
    local bdr = modal:CreateTexture(nil, "BORDER")
    bdr:SetAllPoints(); bdr:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.6)
    local bg = modal:CreateTexture(nil, "BACKGROUND")
    bg:SetPoint("TOPLEFT", 1, -1); bg:SetPoint("BOTTOMRIGHT", -1, 1)
    bg:SetColorTexture(0.05, 0.04, 0.09, 0.97)

    -- Header
    local hdr = CreateFrame("Frame", nil, modal)
    hdr:SetPoint("TOPLEFT"); hdr:SetPoint("TOPRIGHT"); hdr:SetHeight(36)
    local hBg = hdr:CreateTexture(nil, "BACKGROUND"); hBg:SetAllPoints(); hBg:SetColorTexture(0.04, 0.04, 0.08, 1)
    local hSep = hdr:CreateTexture(nil, "ARTWORK")
    hSep:SetPoint("BOTTOMLEFT"); hSep:SetPoint("BOTTOMRIGHT"); hSep:SetHeight(1)
    hSep:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.5)
    hdr:EnableMouse(true); hdr:RegisterForDrag("LeftButton")
    hdr:SetScript("OnDragStart", function() modal:StartMoving() end)
    hdr:SetScript("OnDragStop",  function() modal:StopMovingOrSizing() end)
    local hTitle = hdr:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    hTitle:SetPoint("LEFT", hdr, "LEFT", 12, 0)
    hTitle:SetTextColor(0.85, 0.80, 1.0, 1)
    hTitle:SetText(SM.T("add_spell_btn") or "AJOUTER UN SORT")

    local xBtn = CreateFrame("Button", nil, hdr)
    xBtn:SetSize(28, 28); xBtn:SetPoint("RIGHT", hdr, "RIGHT", -4, 0)
    local xBg = xBtn:CreateTexture(nil,"BACKGROUND"); xBg:SetAllPoints(); xBg:SetColorTexture(0.32,0.07,0.07,0.85)
    local xLbl = xBtn:CreateFontString(nil,"OVERLAY","GameFontNormal"); xLbl:SetAllPoints()
    xLbl:SetText("\195\151"); xLbl:SetTextColor(1,0.5,0.5,1)
    xBtn:SetScript("OnClick", function() modal:Hide() end)

    local PAD = 14
    local y = -48

    -- Spell ID
    SM.Lbl(modal, "ID du Sort", nil, PAD, y)
    local idIn = SM.Input(modal, W - PAD*2, 22, "Ex: 1249262")
    idIn:SetPoint("TOPLEFT", modal, "TOPLEFT", PAD, y - 16)
    y = y - 44

    local nameLbl = modal:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    nameLbl:SetPoint("TOPLEFT", modal, "TOPLEFT", PAD, y)
    nameLbl:SetPoint("RIGHT", modal, "RIGHT", -PAD, 0)
    nameLbl:SetJustifyH("LEFT"); nameLbl:SetTextColor(0.75, 0.68, 0.92, 1); nameLbl:SetText("—")
    y = y - 24

    idIn:SetScript("OnTextChanged", function(s)
        local id = tonumber(SM.GetVal(s))
        if not id then nameLbl:SetText("—"); return end
        local entry = SM.GetSpellEntry(id)
        if entry then
            local dname = (SM.LANG=="fr" and entry.fr and entry.fr~="" and entry.fr) or entry.en or tostring(id)
            nameLbl:SetText("|cFF88FF88"..dname.."|r  ["..entry.boss.."] "..entry.zone)
        else
            local sname = C_Spell and C_Spell.GetSpellName(id) or (GetSpellInfo and GetSpellInfo(id)) or nil
            nameLbl:SetText(sname and ("|cFFFFD700"..sname.."|r") or "|cFFAAAAAA? Sort inconnu|r")
        end
    end)

    -- Callout
    SM.Lbl(modal, "Callout (texte affiché à l'écran)", nil, PAD, y)
    local callIn = SM.Input(modal, W - PAD*2, 22, "Ex: DODGE")
    callIn:SetPoint("TOPLEFT", modal, "TOPLEFT", PAD, y - 16)
    y = y - 44

    -- TTS
    SM.Lbl(modal, "TTS (optionnel, texte lu à voix haute)", nil, PAD, y)
    local ttsIn = SM.Input(modal, W - PAD*2, 22, "Ex: dodge")
    ttsIn:SetPoint("TOPLEFT", modal, "TOPLEFT", PAD, y - 16)
    y = y - 44

    -- Zone + Boss dropdowns
    local HALF = math.floor((W - PAD*2 - 8) / 2)
    SM.Lbl(modal, "Zone / Instance", nil, PAD, y)
    SM.Lbl(modal, "Boss", nil, PAD + HALF + 8, y)

    local selectedZone = nil
    local selectedBoss = nil

    local function MakeDropBtn(parent, x, w, hint)
        local btn = CreateFrame("Button", nil, parent)
        btn:SetSize(w, 22); btn:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y - 16)
        local bg  = btn:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints();  bg:SetColorTexture(0.10,0.08,0.16,1)
        local bdr = btn:CreateTexture(nil,"BORDER");     bdr:SetAllPoints(); bdr:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.25)
        local lbl = btn:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        lbl:SetPoint("LEFT",btn,"LEFT",8,0); lbl:SetPoint("RIGHT",btn,"RIGHT",-14,0)
        lbl:SetJustifyH("LEFT"); lbl:SetTextColor(0.55,0.50,0.68,1); lbl:SetText(hint)
        local arr = btn:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
        arr:SetPoint("RIGHT",btn,"RIGHT",-4,0); arr:SetText("v")
        btn._lbl  = lbl
        return btn
    end

    local zDropBtn = MakeDropBtn(modal, PAD,            HALF, "— choisir —")
    local bDropBtn = MakeDropBtn(modal, PAD + HALF + 8, HALF, "— choisir —")

    local zMenu = CreateFrame("Frame", nil, UIParent)
    zMenu:SetFrameStrata("TOOLTIP"); zMenu:Hide()
    local zMBg = zMenu:CreateTexture(nil,"BACKGROUND"); zMBg:SetAllPoints(); zMBg:SetColorTexture(0.08,0.06,0.14,0.98)

    local bMenu = CreateFrame("Frame", nil, UIParent)
    bMenu:SetFrameStrata("TOOLTIP"); bMenu:Hide()
    local bMBg = bMenu:CreateTexture(nil,"BACKGROUND"); bMBg:SetAllPoints(); bMBg:SetColorTexture(0.08,0.06,0.14,0.98)

    local function MakeMenuItem(parent, w, i, text, onClick)
        local item = CreateFrame("Button", nil, parent)
        item:SetSize(w, 22); item:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, -(i-1)*22)
        local ibg = item:CreateTexture(nil,"BACKGROUND"); ibg:SetAllPoints(); ibg:SetColorTexture(0,0,0,0)
        local ilbl = item:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        ilbl:SetPoint("LEFT",item,"LEFT",8,0); ilbl:SetText(text); ilbl:SetTextColor(0.82,0.75,0.95,1)
        item:SetScript("OnEnter",function() ibg:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.2) end)
        item:SetScript("OnLeave",function() ibg:SetColorTexture(0,0,0,0) end)
        item:SetScript("OnClick", onClick)
    end

    local function RebuildBossMenu()
        for _, c in ipairs({bMenu:GetChildren()}) do c:Hide() end
        local bosses = {}
        if selectedZone then
            for _, z in ipairs(SM.SpellDB) do
                if z.zone == selectedZone then
                    for _, b in ipairs(z.bosses) do table.insert(bosses, b.boss) end
                    break
                end
            end
        end
        if #bosses == 0 then bMenu:Hide(); return end
        bMenu:SetSize(HALF, #bosses * 22)
        for i, bname in ipairs(bosses) do
            local bn = bname
            MakeMenuItem(bMenu, HALF, i, bname, function()
                selectedBoss = bn
                bDropBtn._lbl:SetText(bn); bDropBtn._lbl:SetTextColor(0.82,0.75,0.95,1)
                bMenu:Hide()
            end)
        end
    end

    local function RebuildZoneMenu()
        for _, c in ipairs({zMenu:GetChildren()}) do c:Hide() end
        local zones = {}
        for _, z in ipairs(SM.SpellDB) do table.insert(zones, z.zone) end
        zMenu:SetSize(HALF, #zones * 22)
        for i, zname in ipairs(zones) do
            local zn = zname
            MakeMenuItem(zMenu, HALF, i, zname, function()
                selectedZone = zn
                zDropBtn._lbl:SetText(zn); zDropBtn._lbl:SetTextColor(0.82,0.75,0.95,1)
                selectedBoss = nil
                bDropBtn._lbl:SetText("— choisir —"); bDropBtn._lbl:SetTextColor(0.55,0.50,0.68,1)
                zMenu:Hide()
            end)
        end
    end

    zDropBtn:SetScript("OnClick", function()
        if zMenu:IsShown() then zMenu:Hide(); return end
        bMenu:Hide(); RebuildZoneMenu()
        zMenu:ClearAllPoints(); zMenu:SetPoint("TOPLEFT", zDropBtn, "BOTTOMLEFT", 0, -2); zMenu:Show()
    end)
    bDropBtn:SetScript("OnClick", function()
        if bMenu:IsShown() then bMenu:Hide(); return end
        zMenu:Hide(); RebuildBossMenu()
        bMenu:ClearAllPoints(); bMenu:SetPoint("TOPLEFT", bDropBtn, "BOTTOMLEFT", 0, -2); bMenu:Show()
    end)
    y = y - 44

    -- Son
    SM.Lbl(modal, "Son (optionnel)", nil, PAD, y)
    y = y - 18
    local selectedSnd = "(aucun)"
    local SND_W = W - PAD*2 - 54
    local sndDrop = CreateFrame("Button", nil, modal)
    sndDrop:SetSize(SND_W, 24); sndDrop:SetPoint("TOPLEFT", modal, "TOPLEFT", PAD, y)
    local sBg = sndDrop:CreateTexture(nil,"BACKGROUND"); sBg:SetAllPoints(); sBg:SetColorTexture(0.10,0.08,0.16,1)
    local sBdr = sndDrop:CreateTexture(nil,"BORDER"); sBdr:SetAllPoints(); sBdr:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.25)
    local sLbl = sndDrop:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    sLbl:SetPoint("LEFT",sndDrop,"LEFT",8,0); sLbl:SetText(selectedSnd); sLbl:SetTextColor(0.9,0.9,0.9,1)
    local sArr = sndDrop:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    sArr:SetPoint("RIGHT",sndDrop,"RIGHT",-6,0); sArr:SetText("v")
    local sTest = SM.BBtn(modal, 46, 24, "Test", function()
        if selectedSnd ~= "(aucun)" then
            PlaySoundFile("Interface\\AddOns\\SolaryM\\Media\\Sounds\\"..selectedSnd..".ogg","Master")
        end
    end)
    sTest:SetPoint("LEFT", sndDrop, "RIGHT", 4, 0)
    local sMenu = CreateFrame("Frame", nil, UIParent)
    sMenu:SetSize(SND_W, 22); sMenu:SetFrameStrata("TOOLTIP"); sMenu:Hide()
    local sMBg = sMenu:CreateTexture(nil,"BACKGROUND"); sMBg:SetAllPoints(); sMBg:SetColorTexture(0.08,0.06,0.14,0.98)
    sndDrop:SetScript("OnClick", function()
        if sMenu:IsShown() then sMenu:Hide(); return end
        for _, c in ipairs({sMenu:GetChildren()}) do c:Hide() end
        local SNDS = {"(aucun)"}
        for _, s in ipairs(SM.MediaSounds or {}) do table.insert(SNDS, s) end
        sMenu:SetHeight(#SNDS * 22)
        for i, sn in ipairs(SNDS) do
            local item = CreateFrame("Button", nil, sMenu)
            item:SetSize(SND_W, 22); item:SetPoint("TOPLEFT", sMenu, "TOPLEFT", 0, -(i-1)*22)
            local ibg = item:CreateTexture(nil,"BACKGROUND"); ibg:SetAllPoints(); ibg:SetColorTexture(0,0,0,0)
            local ilbl = item:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            ilbl:SetPoint("LEFT",item,"LEFT",8,0); ilbl:SetText(sn); ilbl:SetTextColor(0.85,0.85,0.9,1)
            item:SetScript("OnEnter",function() ibg:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.2) end)
            item:SetScript("OnLeave",function() ibg:SetColorTexture(0,0,0,0) end)
            local sv = sn
            item:SetScript("OnClick",function() selectedSnd=sv; sLbl:SetText(sv); sMenu:Hide() end)
        end
        sMenu:ClearAllPoints()
        sMenu:SetPoint("TOPLEFT", sndDrop, "BOTTOMLEFT", 0, -2)
        sMenu:Show()
    end)

    -- Boutons
    local BW = math.floor((W - PAD*2 - 8) / 2)
    local saveBtn = SM.OBtn(modal, BW, 28, "ENREGISTRER", function()
        local id = tonumber(SM.GetVal(idIn))
        if not id then SM.Print("Entre un spell ID valide."); return end
        local callout = SM.GetVal(callIn)
        if callout == "" then SM.Print("Entre un callout."); return end
        local tts  = SM.GetVal(ttsIn)
        local snd  = selectedSnd ~= "(aucun)" and selectedSnd or ""
        local zone = selectedZone or "Personnalisé"
        local boss = selectedBoss or "Personnalisé"

        SolaryMDB.customSpells = SolaryMDB.customSpells or {}
        for i = #SolaryMDB.customSpells, 1, -1 do
            if SolaryMDB.customSpells[i].id == id then table.remove(SolaryMDB.customSpells, i) end
        end
        table.insert(SolaryMDB.customSpells, {
            id=id, callout=callout,
            tts=tts~="" and tts or nil,
            snd=snd~="" and snd or nil,
            zone=zone, boss=boss,
        })

        SolaryMDB.spells[id] = callout
        SM.PendingSpellChanges[id] = callout
        SolaryMDB.spells_tts = SolaryMDB.spells_tts or {}
        if tts ~= "" then
            SolaryMDB.spells_tts[id] = tts
            SM.PendingSpellChanges["__tts_"..id] = tts
        else
            SolaryMDB.spells_tts[id] = nil
            SM.PendingSpellChanges["__tts_"..id] = "__removed__"
        end
        SolaryMDB.spells_snd = SolaryMDB.spells_snd or {}
        if snd ~= "" then SolaryMDB.spells_snd[id] = snd else SolaryMDB.spells_snd[id] = nil end

        SM.InjectCustomSpell({ id=id, callout=callout, zone=zone, boss=boss })
        SM._UpdatePendingCount()
        SM.RefreshSpellList()
        SM.Print("Sort |cFFFFD700"..id.."|r ajouté : \""..callout.."\"")
        modal:Hide()
    end)
    saveBtn:SetPoint("BOTTOMLEFT", modal, "BOTTOMLEFT", PAD, 14)

    local cancelBtn = SM.RBtn(modal, BW, 28, "ANNULER", function() modal:Hide() end)
    cancelBtn:SetPoint("BOTTOMRIGHT", modal, "BOTTOMRIGHT", -PAD, 14)

    modal._reset = function()
        SM.SetVal(idIn, ""); SM.SetVal(callIn, ""); SM.SetVal(ttsIn, "")
        nameLbl:SetText("—")
        selectedSnd = "(aucun)"; sLbl:SetText("(aucun)")
        selectedZone = nil; zDropBtn._lbl:SetText("— choisir —"); zDropBtn._lbl:SetTextColor(0.55,0.50,0.68,1)
        selectedBoss = nil; bDropBtn._lbl:SetText("— choisir —"); bDropBtn._lbl:SetTextColor(0.55,0.50,0.68,1)
        idIn:SetFocus()
    end

    modal:Show()
    modal:Raise()
    idIn:SetFocus()
end

-- ============================================================
-- ONGLET 1 : SPELLS — trié par Zone → Boss → Sort
-- ============================================================
local spellBtns     = {}
local selSpellId    = nil
-- Changements en attente de broadcast (vide après chaque envoi)
SM.PendingSpellChanges = {}

local function BuildSpellsTab(parent)
    local f = CreateFrame("Frame", nil, parent)
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", SIDEBAR_W, CONTENT_Y)
    f:SetSize(PANEL_W, CONTENT_H+8); f:Hide()
    SM.BG(f, 0.07, 0.06, 0.10, 1)

    local COL_L  = 420
    local COL_R  = PANEL_W - COL_L - 16
    local COL_H  = CONTENT_H + 4
    local HDR_H  = 44
    local FILT_H = 40

    -- ═══════════════════════════════════════════════════
    -- COLONNE GAUCHE
    -- ═══════════════════════════════════════════════════
    local cL = CreateFrame("Frame", nil, f)
    cL:SetSize(COL_L, COL_H); cL:SetPoint("TOPLEFT", f, "TOPLEFT", 8, -4)

    -- Header gauche
    local cLHdr = CreateFrame("Frame", nil, cL)
    cLHdr:SetPoint("TOPLEFT", cL, "TOPLEFT", 0, 0)
    cLHdr:SetPoint("TOPRIGHT", cL, "TOPRIGHT", 0, 0)
    cLHdr:SetHeight(HDR_H)
    local cLHBg = cLHdr:CreateTexture(nil,"BACKGROUND")
    cLHBg:SetAllPoints(); cLHBg:SetColorTexture(0.05, 0.04, 0.09, 1)
    local cLHSep = cLHdr:CreateTexture(nil,"ARTWORK")
    cLHSep:SetPoint("BOTTOMLEFT"); cLHSep:SetPoint("BOTTOMRIGHT"); cLHSep:SetHeight(1)
    cLHSep:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.4)

    local cLTitle = cLHdr:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    cLTitle:SetPoint("LEFT", cLHdr, "LEFT", 12, 0)
    cLTitle:SetTextColor(0.85, 0.80, 1.0, 1)
    cLTitle:SetText(SM.T("spells_header"))

    local addBtn = SM.OBtn(cLHdr, 138, 24, SM.T("add_spell_btn") or "AJOUTER UN SORT", function()
        OpenAddSpellModal()
    end)
    addBtn:SetPoint("RIGHT", cLHdr, "RIGHT", -8, 0)

    -- Rangée filtre
    local cLFilt = CreateFrame("Frame", nil, cL)
    cLFilt:SetPoint("TOPLEFT",  cL, "TOPLEFT",  0, -HDR_H)
    cLFilt:SetPoint("TOPRIGHT", cL, "TOPRIGHT", 0, -HDR_H)
    cLFilt:SetHeight(FILT_H)
    local cLFBg = cLFilt:CreateTexture(nil,"BACKGROUND")
    cLFBg:SetAllPoints(); cLFBg:SetColorTexture(0.06, 0.05, 0.10, 1)

    local ZONE_W = 152
    local searchInput = SM.Input(cLFilt, COL_L - ZONE_W - 20, 26, SM.T("search_placeholder"))
    searchInput:SetPoint("LEFT", cLFilt, "LEFT", 6, 0)
    searchInput:SetScript("OnTextChanged", function() SM.RefreshSpellList() end)
    f._searchInput = searchInput

    -- Dropdown zone
    local zoneFilter = nil
    local zDropBtn = CreateFrame("Button", nil, cLFilt)
    zDropBtn:SetSize(ZONE_W, 26)
    zDropBtn:SetPoint("RIGHT", cLFilt, "RIGHT", -6, 0)
    local zDropBg = zDropBtn:CreateTexture(nil,"BACKGROUND")
    zDropBg:SetAllPoints(); zDropBg:SetColorTexture(0.10, 0.08, 0.16, 1)
    local zDropBdr = zDropBtn:CreateTexture(nil,"BORDER")
    zDropBdr:SetAllPoints(); zDropBdr:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.25)
    local zDropLbl = zDropBtn:CreateFontString(nil,"OVERLAY","GameFontNormal")
    zDropLbl:SetPoint("LEFT", zDropBtn, "LEFT", 6, 0)
    zDropLbl:SetPoint("RIGHT", zDropBtn, "RIGHT", -14, 0)
    zDropLbl:SetJustifyH("LEFT")
    zDropLbl:SetTextColor(0.75, 0.68, 0.92, 1)
    zDropLbl:SetText(SM.T("all_zones") or "Toutes les zones")
    local zDropArr = zDropBtn:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    zDropArr:SetPoint("RIGHT", zDropBtn, "RIGHT", -4, 0); zDropArr:SetText("v")

    local zMenu = CreateFrame("Frame", nil, UIParent)
    zMenu:SetSize(ZONE_W, 22)
    zMenu:SetFrameStrata("TOOLTIP"); zMenu:Hide()
    local zMenuBg = zMenu:CreateTexture(nil,"BACKGROUND")
    zMenuBg:SetAllPoints(); zMenuBg:SetColorTexture(0.08, 0.06, 0.14, 0.98)

    local function RebuildZoneMenu()
        for _, c in ipairs({zMenu:GetChildren()}) do c:Hide() end
        local zones = {}
        table.insert(zones, {z="__all__", d=SM.T("all_zones") or "Toutes les zones"})
        for _, zn in ipairs(SM.SpellDB or {}) do
            table.insert(zones, {z=zn.zone, d=zn.zone})
        end
        zMenu:SetHeight(#zones * 22)
        for i, entry in ipairs(zones) do
            local item = CreateFrame("Button", nil, zMenu)
            item:SetSize(ZONE_W, 22)
            item:SetPoint("TOPLEFT", zMenu, "TOPLEFT", 0, -(i-1)*22)
            local ibg = item:CreateTexture(nil,"BACKGROUND"); ibg:SetAllPoints(); ibg:SetColorTexture(0,0,0,0)
            local ilbl = item:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            ilbl:SetPoint("LEFT",item,"LEFT",8,0); ilbl:SetJustifyH("LEFT")
            ilbl:SetText(entry.d); ilbl:SetTextColor(0.82, 0.75, 0.95, 1)
            item:SetScript("OnEnter",function() ibg:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.2) end)
            item:SetScript("OnLeave",function() ibg:SetColorTexture(0,0,0,0) end)
            local ez, ed = entry.z, entry.d
            item:SetScript("OnClick",function()
                if ez == "__all__" then zoneFilter = nil else zoneFilter = ez end
                zDropLbl:SetText(ed); zMenu:Hide(); SM.RefreshSpellList()
            end)
        end
    end
    zDropBtn:SetScript("OnClick", function()
        if zMenu:IsShown() then zMenu:Hide(); return end
        RebuildZoneMenu()
        zMenu:ClearAllPoints()
        zMenu:SetPoint("TOPLEFT", zDropBtn, "BOTTOMLEFT", 0, -2)
        zMenu:Show()
    end)
    f._zoneFilter = function() return zoneFilter end

    -- Liste de sorts
    local listH = COL_H - HDR_H - FILT_H - 22
    local spellScroll = SM.Scroll(cL, COL_L - 4, listH)
    spellScroll:SetPoint("TOPLEFT", cL, "TOPLEFT", 2, -(HDR_H + FILT_H))
    f._spellScroll = spellScroll

    -- Compteur
    local countLbl = cL:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    countLbl:SetPoint("BOTTOMLEFT", cL, "BOTTOMLEFT", 8, 4)
    countLbl:SetTextColor(0.45, 0.40, 0.58, 1)
    countLbl:SetText("0 sorts trouvés")
    f._countLbl = countLbl

    -- ═══════════════════════════════════════════════════
    -- COLONNE DROITE
    -- ═══════════════════════════════════════════════════
    local cR = CreateFrame("Frame", nil, f)
    cR:SetSize(COL_R, COL_H); cR:SetPoint("TOPLEFT", cL, "TOPRIGHT", 8, 0)
    SM.BG(cR, SM.DK[1], SM.DK[2], SM.DK[3], 1)

    -- Header droit
    local cRHdr = CreateFrame("Frame", nil, cR)
    cRHdr:SetPoint("TOPLEFT", cR, "TOPLEFT", 0, 0)
    cRHdr:SetPoint("TOPRIGHT", cR, "TOPRIGHT", 0, 0)
    cRHdr:SetHeight(HDR_H)
    local cRHBg = cRHdr:CreateTexture(nil,"BACKGROUND")
    cRHBg:SetAllPoints(); cRHBg:SetColorTexture(0.05, 0.04, 0.09, 1)
    local cRHSep = cRHdr:CreateTexture(nil,"ARTWORK")
    cRHSep:SetPoint("BOTTOMLEFT"); cRHSep:SetPoint("BOTTOMRIGHT"); cRHSep:SetHeight(1)
    cRHSep:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.4)
    local cRTitle = cRHdr:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    cRTitle:SetPoint("LEFT", cRHdr, "LEFT", 12, 0)
    cRTitle:SetTextColor(0.85, 0.80, 1.0, 1)
    cRTitle:SetText(SM.T("edit_callout"))

    local y = -(HDR_H + 12)

    SM.Lbl(cR, SM.T("spell_id"), nil, 8, y)
    local idInput = SM.Input(cR, COL_R-16, 22, "Ex: 1249262")
    idInput:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y-14)
    f._idInput = idInput
    y = y - 40

    SM.Lbl(cR, SM.T("spell_name"), nil, 8, y)
    local nameDisplay = cR:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    nameDisplay:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y-14)
    nameDisplay:SetPoint("RIGHT", cR, "RIGHT", -8, 0)
    nameDisplay:SetJustifyH("LEFT"); nameDisplay:SetTextColor(0.8,0.8,0.8,1); nameDisplay:SetText("—")
    f._nameDisplay = nameDisplay
    y = y - 28

    SM.Lbl(cR, SM.T("spell_note"), nil, 8, y)
    local noteDisplay = cR:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    noteDisplay:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y-14)
    noteDisplay:SetPoint("RIGHT", cR, "RIGHT", -8, 0)
    noteDisplay:SetJustifyH("LEFT"); noteDisplay:SetTextColor(0.5,0.5,0.5,1); noteDisplay:SetText("—")
    f._noteDisplay = noteDisplay
    y = y - 36

    idInput:SetScript("OnTextChanged", function(s)
        local id = tonumber(SM.GetVal(s))
        if not id then nameDisplay:SetText("—"); noteDisplay:SetText("—"); return end
        local entry = SM.GetSpellEntry(id)
        if entry then
            local dname = (SM.LANG=="fr" and entry.fr~="" and entry.fr) or entry.en or tostring(entry.id)
            nameDisplay:SetText(dname)
            noteDisplay:SetText(entry.boss and ("["..entry.boss.."] "..entry.zone) or "—")
        else
            local sname = C_Spell and C_Spell.GetSpellName(id) or (GetSpellInfo and GetSpellInfo(id)) or nil
            nameDisplay:SetText(sname or SM.T("unknown_spell")); noteDisplay:SetText("—")
        end
    end)

    SM.Lbl(cR, SM.T("callout_screen"), nil, 8, y)
    local calloutInput = SM.Input(cR, COL_R-16, 24, SM.T("callout_ph"))
    calloutInput:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y-16)
    f._calloutInput = calloutInput
    y = y - 46

    SM.Lbl(cR, SM.T("tts_label"), nil, 8, y)
    local ttsInput = SM.Input(cR, COL_R-16, 24, SM.T("tts_ph"))
    ttsInput:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y-16)
    f._ttsInput = ttsInput
    y = y - 46

    SM.Lbl(cR, SM.T("sound_label"), nil, 8, y)
    y = y - 20

    local function GetSounds()
        local t = {"(aucun)"}
        for _, s in ipairs(SM.MediaSounds or {}) do table.insert(t, s) end
        return t
    end
    local selectedSnd = "(aucun)"

    local sndDropBtn = CreateFrame("Button", nil, cR)
    sndDropBtn:SetSize(COL_R-16-52, 24)
    sndDropBtn:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    local sndDropBg = sndDropBtn:CreateTexture(nil,"BACKGROUND")
    sndDropBg:SetAllPoints(); sndDropBg:SetColorTexture(0.10, 0.08, 0.16, 1)
    local sndDropBdr = sndDropBtn:CreateTexture(nil,"BORDER")
    sndDropBdr:SetAllPoints(); sndDropBdr:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.25)
    local sndDropLbl = sndDropBtn:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    sndDropLbl:SetPoint("LEFT",sndDropBtn,"LEFT",8,0); sndDropLbl:SetText(selectedSnd); sndDropLbl:SetTextColor(0.9,0.9,0.9,1)
    local sndDropArr = sndDropBtn:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    sndDropArr:SetPoint("RIGHT",sndDropBtn,"RIGHT",-6,0); sndDropArr:SetText("v")

    local sndTestBtn = SM.BBtn(cR, 46, 24, "Test", function()
        if selectedSnd ~= "(aucun)" then
            PlaySoundFile("Interface\\AddOns\\SolaryM\\Media\\Sounds\\"..selectedSnd..".ogg", "Master")
        end
    end)
    sndTestBtn:SetPoint("LEFT", sndDropBtn, "RIGHT", 4, 0)

    local sndMenu = CreateFrame("Frame", nil, cR)
    sndMenu:SetSize(COL_R-16-52, 22)
    sndMenu:SetPoint("TOPLEFT", sndDropBtn, "BOTTOMLEFT", 0, -2)
    sndMenu:SetFrameStrata("TOOLTIP")
    local sndMenuBg = sndMenu:CreateTexture(nil,"BACKGROUND")
    sndMenuBg:SetAllPoints(); sndMenuBg:SetColorTexture(0.08,0.06,0.14,0.98)
    sndMenu:Hide()

    sndDropBtn:SetScript("OnClick", function()
        if sndMenu:IsShown() then sndMenu:Hide(); return end
        for _, c in ipairs({sndMenu:GetChildren()}) do c:Hide() end
        local SOUNDS = GetSounds()
        sndMenu:SetHeight(#SOUNDS * 22)
        for i, sname in ipairs(SOUNDS) do
            local item = CreateFrame("Button", nil, sndMenu)
            item:SetSize(COL_R-16-52, 22)
            item:SetPoint("TOPLEFT", sndMenu, "TOPLEFT", 0, -(i-1)*22)
            local ibg = item:CreateTexture(nil,"BACKGROUND"); ibg:SetAllPoints(); ibg:SetColorTexture(0,0,0,0)
            local ilbl = item:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            ilbl:SetPoint("LEFT",item,"LEFT",8,0); ilbl:SetText(sname); ilbl:SetTextColor(0.85,0.85,0.9,1)
            item:SetScript("OnEnter",function() ibg:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.2) end)
            item:SetScript("OnLeave",function() ibg:SetColorTexture(0,0,0,0) end)
            local sn = sname
            item:SetScript("OnClick",function() selectedSnd=sn; sndDropLbl:SetText(sn); sndMenu:Hide() end)
        end
        sndMenu:Show()
    end)

    f._sndInput = {
        GetText = function() return selectedSnd ~= "(aucun)" and selectedSnd or "" end,
        SetText = function(_, v)
            selectedSnd = (v and v ~= "") and v or "(aucun)"
            sndDropLbl:SetText(selectedSnd)
        end,
    }
    y = y - 34

    local BW2 = math.floor((COL_R-16-6)/2)
    SM.OBtn(cR, BW2, 26, SM.T("btn_save"), function()
        local newId = tonumber(SM.GetVal(idInput))
        if not newId then SM.Print("Entre un spell ID.") return end
        local callout = SM.GetVal(calloutInput)
        if callout == "" then SM.Print("Entre un callout.") return end
        SolaryMDB.spellIdRemap = SolaryMDB.spellIdRemap or {}
        if selSpellId and selSpellId ~= newId then
            SolaryMDB.spells[selSpellId] = nil
            SolaryMDB.spellIdRemap[selSpellId] = newId
            SM.PendingSpellChanges[selSpellId] = "__removed__"
        elseif selSpellId then
            local oldRemapId = SolaryMDB.spellIdRemap[selSpellId]
            if oldRemapId then
                SolaryMDB.spells[oldRemapId] = nil
                SM.PendingSpellChanges[oldRemapId] = "__removed__"
            end
            SolaryMDB.spellIdRemap[selSpellId] = nil
            SM.PendingSpellChanges["__remap_clear_" .. selSpellId] = "__remap_clear__"
        end
        SolaryMDB.spells[newId] = callout
        SM.PendingSpellChanges[newId] = callout
        local ttsText = SM.GetVal(ttsInput)
        SolaryMDB.spells_tts = SolaryMDB.spells_tts or {}
        if ttsText ~= "" then
            SolaryMDB.spells_tts[newId] = ttsText
            SM.PendingSpellChanges["__tts_"..newId] = ttsText
        else
            SolaryMDB.spells_tts[newId] = nil
            SM.PendingSpellChanges["__tts_"..newId] = "__removed__"
        end
        local sndText = f._sndInput and f._sndInput:GetText() or ""
        SolaryMDB.spells_snd = SolaryMDB.spells_snd or {}
        if sndText ~= "" then SolaryMDB.spells_snd[newId] = sndText
        else SolaryMDB.spells_snd[newId] = nil end
        SM.SetVal(idInput,""); SM.SetVal(calloutInput,""); SM.SetVal(ttsInput,"")
        if f._sndInput then f._sndInput:SetText("") end
        nameDisplay:SetText("—"); noteDisplay:SetText("—")
        selSpellId = nil
        SM.RefreshSpellList(); SM._UpdatePendingCount()
        SM.Print("Spell |cFFFFD700"..newId.."|r % \""..callout.."\"")
    end):SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)

    SM.RBtn(cR, BW2, 26, SM.T("btn_reset"), function()
        if not selSpellId then SM.Print("Sélectionne un sort.") return end
        local entry = SM.GetSpellEntry(selSpellId)
        local defaultCallout = entry and ((SM.LANG=="fr" and entry.fr) or entry.en) or nil
        SolaryMDB.spells[selSpellId] = defaultCallout
        SolaryMDB.spellIdRemap = SolaryMDB.spellIdRemap or {}
        local remappedId = SolaryMDB.spellIdRemap[selSpellId]
        if remappedId then
            SolaryMDB.spells[remappedId] = nil
            SolaryMDB.spellIdRemap[selSpellId] = nil
            SM.PendingSpellChanges[remappedId] = "__removed__"
        end
        SM.PendingSpellChanges[selSpellId] = defaultCallout or "__removed__"
        SM._UpdatePendingCount()
        selSpellId = nil
        SM.SetVal(idInput,""); SM.SetVal(calloutInput,"")
        nameDisplay:SetText("—"); noteDisplay:SetText("—")
        SM.RefreshSpellList(); SM.Print("Sort réinitialisé.")
    end):SetPoint("TOPLEFT", cR, "TOPLEFT", 8+BW2+6, y)
    y = y - 34

    SM.BBtn(cR, COL_R-16, 26, SM.T("btn_test2"), function()
        local callout = SM.GetVal(calloutInput)
        if callout == "" then callout = (selSpellId and SolaryMDB.spells[selSpellId]) or "SOAK" end
        SM.TestAlert(callout, 8)
    end):SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    y = y - 34

    SM.RBtn(cR, COL_R-16, 26, "SUPPRIMER LE SORT", function()
        if not selSpellId then SM.Print("Sélectionne un sort d'abord."); return end
        local id = selSpellId

        SolaryMDB.customSpells = SolaryMDB.customSpells or {}
        local isCustom = false
        for i = #SolaryMDB.customSpells, 1, -1 do
            if SolaryMDB.customSpells[i].id == id then
                table.remove(SolaryMDB.customSpells, i); isCustom = true
            end
        end

        SolaryMDB.spells[id] = nil
        SolaryMDB.spells_tts = SolaryMDB.spells_tts or {}; SolaryMDB.spells_tts[id] = nil
        SolaryMDB.spells_snd = SolaryMDB.spells_snd or {}; SolaryMDB.spells_snd[id] = nil
        SM.PendingSpellChanges[id] = "__removed__"
        SM.PendingSpellChanges["__tts_"..id] = "__removed__"

        if isCustom then
            SM.RemoveCustomSpell(id)
            SM.Print("Sort |cFFFFD700"..id.."|r supprimé.")
        else
            SM.Print("Sort |cFFFFD700"..id.."|r : callout supprimé (sort de base conservé).")
        end

        selSpellId = nil
        SM.SetVal(idInput,""); SM.SetVal(calloutInput,""); SM.SetVal(ttsInput,"")
        if f._sndInput then f._sndInput:SetText("") end
        nameDisplay:SetText("—"); noteDisplay:SetText("—")
        SM._UpdatePendingCount(); SM.RefreshSpellList()
    end):SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    y = y - 34

    -- ── Section SYNCHRONISATION RAID ──────────────────────────
    local sepSync = cR:CreateTexture(nil,"ARTWORK")
    sepSync:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    sepSync:SetPoint("TOPRIGHT", cR, "TOPRIGHT", -8, y)
    sepSync:SetHeight(1); sepSync:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.35)
    y = y - 14

    SM.Lbl(cR, SM.T("raid_sync"), "GameFontNormal", 8, y, SM.OR)
    y = y - 20

    local syncDesc = cR:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    syncDesc:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    syncDesc:SetPoint("RIGHT", cR, "RIGHT", -8, 0)
    syncDesc:SetJustifyH("LEFT"); syncDesc:SetTextColor(0.45, 0.40, 0.58, 1)
    syncDesc:SetText(SM.T("raid_sync_desc"))
    y = y - 30

    SM.Lbl(cR, SM.T("img_label"), nil, 8, y)
    y = y - 18

    local imgDropdown = CreateFrame("Frame", "SolaryMImgDropdown", cR, "UIDropDownMenuTemplate")
    imgDropdown:SetPoint("TOPLEFT", cR, "TOPLEFT", -4, y+4)
    UIDropDownMenu_SetWidth(imgDropdown, COL_R - 90)
    UIDropDownMenu_SetText(imgDropdown, SM.T("no_image"))

    local mediaImages = {}
    local function ScanMediaImages()
        mediaImages = {}
        local known = SolaryMDB.mediaFiles or {}
        for _, fname in ipairs(known) do table.insert(mediaImages, fname) end
        local hasBreak = false
        for _, ff in ipairs(mediaImages) do if ff == "break" then hasBreak = true end end
        if not hasBreak then table.insert(mediaImages, 1, "break") end
    end
    ScanMediaImages()

    local selectedImg = nil
    UIDropDownMenu_Initialize(imgDropdown, function(self, level)
        local info = UIDropDownMenu_CreateInfo()
        info.text = SM.T("no_image_dash"); info.value = nil
        info.func = function() selectedImg=nil; UIDropDownMenu_SetText(imgDropdown, SM.T("no_image")) end
        info.checked = selectedImg == nil; UIDropDownMenu_AddButton(info)
        for _, fname in ipairs(mediaImages) do
            info = UIDropDownMenu_CreateInfo()
            info.text = fname; info.value = fname
            local fn = fname
            info.func = function() selectedImg=fn; UIDropDownMenu_SetText(imgDropdown, fn) end
            info.checked = selectedImg == fname; UIDropDownMenu_AddButton(info)
        end
        info = UIDropDownMenu_CreateInfo()
        info.text = "|cFFAAAAAA "..SM.T("refresh_list").."|r"; info.value = "__refresh"
        info.func = function() ScanMediaImages(); UIDropDownMenu_Refresh(imgDropdown) end
        UIDropDownMenu_AddButton(info)
    end)
    y = y - 32

    local mediaInfo = cR:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    mediaInfo:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    mediaInfo:SetPoint("RIGHT", cR, "RIGHT", -8, 0)
    mediaInfo:SetJustifyH("LEFT"); mediaInfo:SetTextColor(0.38,0.34,0.50,1)
    mediaInfo:SetText(SM.T("media_info"))
    y = y - 22

    local pendingLbl = cR:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    pendingLbl:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    pendingLbl:SetPoint("RIGHT", cR, "RIGHT", -8, 0)
    pendingLbl:SetJustifyH("LEFT")
    pendingLbl:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
    pendingLbl:SetText(SM.T("pending_none"))
    f._pendingLbl = pendingLbl
    y = y - 22

    local broadcastBtn = SM.Btn(cR, COL_R-16, 30, SM.T("btn_broadcast"),
        SM.PRP[1], SM.PRP[2], SM.PRP[3], function()
        SM.BroadcastSpells(selectedImg)
    end)
    broadcastBtn:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    y = y - 38

    local broadcastStatus = cR:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    broadcastStatus:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    broadcastStatus:SetPoint("RIGHT", cR, "RIGHT", -8, 0)
    broadcastStatus:SetJustifyH("LEFT"); broadcastStatus:SetTextColor(0.38,0.34,0.50,1)
    broadcastStatus:SetText(SM.T("last_broadcast"))
    f._broadcastStatus = broadcastStatus
    y = y - 22

    local info = cR:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    info:SetPoint("TOPLEFT", cR, "TOPLEFT", 8, y)
    info:SetPoint("RIGHT", cR, "RIGHT", -8, 0)
    info:SetJustifyH("LEFT"); info:SetTextColor(0.38,0.34,0.50,1)
    info:SetText(SM.T("spell_info"))

    return f
end

-- ============================================================
-- REFRESH SPELLS — liste groupée par zone puis boss
-- ============================================================
function SM.RefreshSpellList()
    local f = tabFrames[1]
    if not f or not f._spellScroll then return end
    local scroll = f._spellScroll
    for _, b in ipairs(spellBtns) do b:Hide() end
    spellBtns = {}

    local filter     = f._searchInput and SM.GetVal(f._searchInput):lower() or ""
    local zoneFilter = f._zoneFilter and f._zoneFilter()
    local W          = scroll.content:GetWidth()
    local yOff       = 0
    local spellCount = 0
    local typeCol    = { raid={1,0.6,0}, dungeon={0.4,0.8,1}, custom={0.80,0.55,1.0} }

    local function spellMatchesFilter(spell)
        if filter == "" then return true end
        local callout = SolaryMDB.spells[spell.id] or (SM.LANG=="fr" and spell.fr) or spell.en or ""
        local sname = spell.en or spell.fr or ""
        local boss  = spell.boss or ""
        return sname:lower():find(filter,1,true)
            or callout:lower():find(filter,1,true)
            or boss:lower():find(filter,1,true)
    end

    local function bossHasMatch(boss)
        for _, spell in ipairs(boss.spells) do
            if spellMatchesFilter(spell) then return true end
        end
        return false
    end

    local function zoneHasMatch(zone)
        for _, boss in ipairs(zone.bosses) do
            if bossHasMatch(boss) then return true end
        end
        return false
    end

    for _, zone in ipairs(SM.SpellDB) do
        if (not zoneFilter or zone.zone == zoneFilter) and zoneHasMatch(zone) then
            local tc = typeCol[zone.type] or {0.7,0.7,0.7}

            -- En-tête zone
            local zRow = CreateFrame("Frame", nil, scroll.content)
            zRow:SetSize(W, 28); zRow:SetPoint("TOPLEFT", 0, -yOff)
            local zBg = zRow:CreateTexture(nil,"BACKGROUND"); zBg:SetAllPoints()
            zBg:SetColorTexture(tc[1]*0.18, tc[2]*0.14, tc[3]*0.22, 1)
            local zLbl = zRow:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
            zLbl:SetPoint("LEFT",8,0); zLbl:SetPoint("RIGHT",zRow,"RIGHT",-60,0)
            zLbl:SetJustifyH("LEFT"); zLbl:SetTextColor(tc[1],tc[2],tc[3],1); zLbl:SetText(zone.zone)
            local zTag = zRow:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            zTag:SetPoint("RIGHT",zRow,"RIGHT",-6,0)
            zTag:SetTextColor(tc[1]*0.8,tc[2]*0.8,tc[3]*0.8,1)
            zTag:SetText(zone.type == "raid" and "RAID" or SM.T("type_dungeon"))
            table.insert(spellBtns, zRow); yOff = yOff + 30

            for _, boss in ipairs(zone.bosses) do
                if bossHasMatch(boss) then
                    -- En-tête boss
                    local bRow = CreateFrame("Frame", nil, scroll.content)
                    bRow:SetSize(W, 26); bRow:SetPoint("TOPLEFT", 0, -yOff)
                    SM.BG(bRow, 0.10, 0.08, 0.18, 1)
                    local bLbl = bRow:CreateFontString(nil,"OVERLAY","GameFontNormal")
                    bLbl:SetPoint("LEFT",16,0); bLbl:SetPoint("RIGHT",bRow,"RIGHT",-4,0)
                    bLbl:SetJustifyH("LEFT"); bLbl:SetTextColor(0.85, 0.72, 0.98, 1)
                    bLbl:SetText(boss.boss)
                    table.insert(spellBtns, bRow); yOff = yOff + 28

                    for _, spell in ipairs(boss.spells) do
                        if spellMatchesFilter(spell) then
                            spellCount = spellCount + 1
                            local defCallout = (SM.LANG=="fr" and spell.fr) or spell.en or ""
                            local remapId2   = SolaryMDB.spellIdRemap and SolaryMDB.spellIdRemap[spell.id]
                            local activeId2  = remapId2 or spell.id
                            local callout    = SolaryMDB.spells[activeId2] or defCallout
                            local isCustom   = (SolaryMDB.spells[activeId2] and SolaryMDB.spells[activeId2] ~= defCallout) or (remapId2 ~= nil)
                            local isSel      = (selSpellId == spell.id)

                            local btn = CreateFrame("Button", nil, scroll.content)
                            btn:SetSize(W, 30); btn:SetPoint("TOPLEFT", 0, -yOff)
                            local bg = btn:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints()
                            bg:SetColorTexture(
                                isSel and 0.18 or 0.08,
                                isSel and 0.08 or 0.06,
                                isSel and 0.28 or 0.12, 1)
                            btn._bg = bg

                            local fCall = btn:CreateFontString(nil,"OVERLAY","GameFontNormal")
                            fCall:SetPoint("LEFT",10,0); fCall:SetWidth(130); fCall:SetJustifyH("LEFT")
                            fCall:SetTextColor(
                                isCustom and SM.OR[1] or 0.92,
                                isCustom and SM.OR[2] or 0.90,
                                isCustom and SM.OR[3] or 0.98, 1)
                            fCall:SetText(callout)
                            local fName = btn:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
                            fName:SetPoint("LEFT",btn,"LEFT",152,0); fName:SetPoint("RIGHT",btn,"RIGHT",-56,0)
                            fName:SetJustifyH("LEFT"); fName:SetTextColor(0.58,0.54,0.68,1)
                            fName:SetText((spell.boss or "")..(spell.en and (" — "..spell.en) or ""))
                            local fId = btn:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
                            fId:SetPoint("RIGHT",btn,"RIGHT",-6,0); fId:SetTextColor(0.38,0.34,0.50,1)
                            local displayId = (SolaryMDB.spellIdRemap and SolaryMDB.spellIdRemap[spell.id]) or spell.id
                            fId:SetText(tostring(displayId))

                            local sid      = spell.id
                            local sname_en = spell.en or ""
                            local sname_fr = spell.fr or ""
                            local scallout = callout
                            local _idx     = SM.SpellIndex and SM.SpellIndex[spell.id]
                            local sboss    = (_idx and _idx.boss) or ""
                            local szone    = (_idx and _idx.zone) or ""

                            btn:SetScript("OnClick", function()
                                selSpellId = sid
                                local remapId  = SolaryMDB.spellIdRemap and SolaryMDB.spellIdRemap[sid]
                                local activeId = remapId or sid
                                if f._idInput      then SM.SetVal(f._idInput, tostring(activeId)) end
                                if f._calloutInput then SM.SetVal(f._calloutInput, SolaryMDB.spells[activeId] or scallout) end
                                if f._ttsInput then
                                    local ttsData = SolaryMDB.spells_tts and SolaryMDB.spells_tts[activeId]
                                    SM.SetVal(f._ttsInput, type(ttsData)=="string" and ttsData or "")
                                end
                                if f._sndInput then
                                    f._sndInput:SetText(SolaryMDB.spells_snd and SolaryMDB.spells_snd[activeId] or "")
                                end
                                if f._nameDisplay then
                                    f._nameDisplay:SetText((SM.LANG=="fr" and sname_fr~="" and sname_fr) or sname_en)
                                end
                                if f._noteDisplay then
                                    f._noteDisplay:SetText(sboss~="" and ("["..sboss.."] "..szone) or "—")
                                end
                                SM.RefreshSpellList()
                            end)
                            btn:SetScript("OnEnter", function(s)
                                if selSpellId ~= sid then s._bg:SetColorTexture(0.12, 0.08, 0.20, 1) end
                                GameTooltip:SetOwner(s,"ANCHOR_RIGHT")
                                GameTooltip:SetText(sname_en~="" and sname_en or tostring(sid), SM.OR[1],SM.OR[2],SM.OR[3])
                                if sname_fr~="" and sname_fr~=sname_en then
                                    GameTooltip:AddLine(sname_fr, 0.8, 0.8, 0.8, true)
                                end
                                GameTooltip:AddLine("Boss: "..sboss, 0.6, 0.6, 0.6, true)
                                GameTooltip:AddLine("Zone: "..szone, 0.5, 0.5, 0.5, true)
                                GameTooltip:AddLine("ID: "..sid, 0.4, 0.4, 0.4, true)
                                GameTooltip:Show()
                            end)
                            btn:SetScript("OnLeave", function(s)
                                if selSpellId ~= sid then s._bg:SetColorTexture(0.08, 0.06, 0.12, 1) end
                                GameTooltip:Hide()
                            end)
                            table.insert(spellBtns, btn); yOff = yOff + 28
                        end
                    end
                end
            end
            yOff = yOff + 4
        end
    end
    scroll.content:SetHeight(math.max(yOff, 1))
    if f._countLbl then
        f._countLbl:SetText(spellCount.." "..(SM.T("spells_found") or "sorts trouvés"))
    end
end

-- ============================================================
-- ONGLET 2 : GROUPES
-- ============================================================
local function BuildGroupsTab(parent)
    local f = CreateFrame("Frame",nil,parent)
    f:SetPoint("TOPLEFT",parent,"TOPLEFT",SIDEBAR_W,CONTENT_Y)
    f:SetSize(PANEL_W,CONTENT_H+8); f:Hide()
    SM.BG(f, 0.07, 0.07, 0.10, 1)  -- fond opaque

    local HALF = math.floor((PANEL_W-24)/2)

    -- ── Ligne de boutons ─────────────────────────────────────
    local btnOE = SM.OBtn(f, math.floor(HALF*0.9), 28, SM.T("split_odd_even"), function()
        SM.Groups.SplitOddEven()
        SM.RefreshGroupsTab("default", f)
        local oeA, oeB = SM.Groups.GetSplitLabels()
        SM.Print(string.format("Split |cFFFFD700%s|r vs |cFFFFD700%s|r", oeA, oeB))
    end)
    btnOE:SetPoint("TOPLEFT",f,"TOPLEFT",8,-10)

    local btnH = SM.OBtn(f, math.floor(HALF*0.9), 28, SM.T("split_halves"), function()
        SM.Groups.SplitHalves()
        SM.RefreshGroupsTab("default", f)
        local _, _, hA, hB = SM.Groups.GetSplitLabels()
        SM.Print(string.format("Split |cFFFFD700%s|r vs |cFFFFD700%s|r", hA, hB))
    end)
    btnH:SetPoint("TOPLEFT",f,"TOPLEFT", 8 + math.floor(HALF*0.9) + 12, -10)

    -- Labels dynamiques sous les boutons (affichent ex: "Grp 1/3/5" / "Grp 2/4/6")
    local lblSplit = f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    lblSplit:SetPoint("TOPLEFT",f,"TOPLEFT",8,-44)
    lblSplit:SetTextColor(0.6,0.6,0.6,1)
    lblSplit:SetText("Raid 10/25 → Impairs (1/3/5) vs Pairs (2/4/6)   |   Mythic 20 → 1/3 vs 2/4")
    f._lblSplit = lblSplit

    -- ── Colonnes A / B ────────────────────────────────────────
    local colA = CreateFrame("Frame",nil,f)
    colA:SetSize(HALF, CONTENT_H-62); colA:SetPoint("TOPLEFT",f,"TOPLEFT",8,-58)
    SM.BG(colA,SM.DK[1],SM.DK[2],SM.DK[3],0.7)
    SM.Lbl(colA,SM.T("group_a"),"GameFontNormal",8,-8,SM.OR)
    local sA = SM.Scroll(colA,HALF-4,CONTENT_H-90)
    sA:SetPoint("TOPLEFT",colA,"TOPLEFT",2,-28)

    local colB = CreateFrame("Frame",nil,f)
    colB:SetSize(HALF, CONTENT_H-62); colB:SetPoint("TOPLEFT",f,"TOPLEFT",8+HALF+8,-58)
    SM.BG(colB,SM.DK[1],SM.DK[2],SM.DK[3],0.7)
    SM.Lbl(colB,SM.T("group_b"),"GameFontNormal",8,-8,SM.OR)
    local sB = SM.Scroll(colB,HALF-4,CONTENT_H-90)
    sB:SetPoint("TOPLEFT",colB,"TOPLEFT",2,-28)

    f._scrollA=sA; f._scrollB=sB
    return f
end

function SM.RefreshGroupsTab(bossName, f)
    f = f or tabFrames[3]
    if not f or not f._scrollA then return end
    local key = "default"
    local groups = SolaryMDB.groups[key] or {A={},B={}}
    local rc = {TANK={0.2,0.6,1},HEALER={0.1,0.9,0.3},DAMAGER={1,0.8,0.1},NONE={0.7,0.7,0.7}}
    local function Fill(scroll, list)
        for _, c in ipairs({scroll.content:GetChildren()}) do c:Hide() end
        local sorted = SM.Groups.SortByRole()
        local roleMap = {}
        for _, g in ipairs({sorted.tanks, sorted.healers, sorted.dps}) do
            for _, m in ipairs(g) do roleMap[m.name] = m.role end
        end
        local yOff = 0
        for _, name in ipairs(list) do
            local row = CreateFrame("Frame",nil,scroll.content)
            row:SetSize(scroll.content:GetWidth(),24); row:SetPoint("TOPLEFT",0,-yOff)
            SM.BG(row,0.1,0.1,0.13,1)
            local role = roleMap[name] or "NONE"
            local c = rc[role] or rc.NONE
            local ri = role=="TANK" and "T" or role=="HEALER" and "H" or "D"
            local fr = row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            fr:SetPoint("LEFT",4,0); fr:SetWidth(14)
            fr:SetTextColor(c[1],c[2],c[3],1); fr:SetText(ri)
            local fn = row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            fn:SetPoint("LEFT",22,0); fn:SetPoint("RIGHT",row,"RIGHT",-4,0)
            fn:SetJustifyH("LEFT"); fn:SetTextColor(0.9,0.9,0.9,1); fn:SetText(name)
            yOff = yOff + 26
        end
        scroll.content:SetHeight(math.max(yOff,1))
    end
    Fill(f._scrollA, groups.A or {})
    Fill(f._scrollB, groups.B or {})

    if f._lblSplit then
        if IsInRaid() then
            local oeA, oeB, hA, hB = SM.Groups.GetSplitLabels()
            f._lblSplit:SetText(string.format("Impairs/Pairs : |cFFFFD700%s|r vs |cFFFFD700%s|r   |   Moitiés : |cFFFFD700%s|r vs |cFFFFD700%s|r", oeA, oeB, hA, hB))
        else
            f._lblSplit:SetText("Hors raid : split équilibré par rôle (T/H/DPS alternés)")
        end
    end
end

-- ============================================================
-- ONGLET 3 : INVITES
-- ============================================================
local function BuildInviteTab(parent)
    local f=CreateFrame("Frame",nil,parent)
    f:SetPoint("TOPLEFT",parent,"TOPLEFT",SIDEBAR_W,CONTENT_Y)
    f:SetSize(PANEL_W,CONTENT_H+8); f:Hide()
    SM.BG(f, 0.07, 0.07, 0.10, 1)  -- fond opaque

    local y=-14
    SM.Lbl(f,SM.T("autoinvite"),"GameFontNormal",8,y,SM.OR); y=y-20
    SM.Lbl(f,SM.T("autoinvite_desc"),nil,8,y); y=y-30

    local toggleBtn=SM.OBtn(f,160,26,SM.T("btn_enable"),function()
        local en=SM.Invite.IsAutoInviteEnabled()
        SM.Invite.SetAutoInvite(not en)
        if not en then
            f._toggle._fs:SetText(SM.T("btn_disable"))
            f._toggle._bg:SetColorTexture(SM.RED[1],SM.RED[2],SM.RED[3],0.88)
            f._toggle._r=SM.RED[1]; f._toggle._g=SM.RED[2]; f._toggle._b=SM.RED[3]
        else
            f._toggle._fs:SetText(SM.T("btn_enable"))
            f._toggle._bg:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.88)
            f._toggle._r=SM.OR[1]; f._toggle._g=SM.OR[2]; f._toggle._b=SM.OR[3]
        end
    end)
    toggleBtn:SetPoint("TOPLEFT",f,"TOPLEFT",8,y); f._toggle=toggleBtn

    local kwLbl=f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    kwLbl:SetPoint("LEFT",toggleBtn,"RIGHT",12,0); kwLbl:SetTextColor(0.6,0.6,0.6,1)
    local kws=SolaryMDB.invite and SolaryMDB.invite.keywords or {"inv","+1"}
    kwLbl:SetText(SM.T("keywords").." "..table.concat(kws,"  |  "))
    y=y-44

    local sep=f:CreateTexture(nil,"ARTWORK")
    sep:SetSize(PANEL_W-16,1); sep:SetPoint("TOPLEFT",f,"TOPLEFT",8,y)
    sep:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.4); y=y-16

    SM.Lbl(f,SM.T("guild_rank"),"GameFontNormal",8,y,SM.OR); y=y-20
    SM.Lbl(f,SM.T("guild_rank_desc"),nil,8,y); y=y-30

    local rf=CreateFrame("Frame",nil,f)
    rf:SetPoint("TOPLEFT",f,"TOPLEFT",8,y); rf:SetSize(PANEL_W-16,160)
    SM.BG(rf,SM.DK[1],SM.DK[2],SM.DK[3],0.7); f._rankFrame=rf
    y=y-170

    SM.BBtn(f,150,26,SM.T("btn_load_ranks"),function()
        SM.RefreshRankList(f)
    end):SetPoint("TOPLEFT",f,"TOPLEFT",8,y)

    SM.GBtn(f,150,26,SM.T("btn_invite_sel"),function()
        SM.Invite.InviteByRanks(f._selectedRanks or {})
    end):SetPoint("TOPLEFT",f,"TOPLEFT",166,y)

    f._selectedRanks={}
    return f
end

function SM.RefreshRankList(f)
    f=f or tabFrames[4]
    if not f or not f._rankFrame then return end
    local rf=f._rankFrame; f._selectedRanks={}
    for _,c in ipairs({rf:GetChildren()}) do c:Hide() end
    local ranks=SM.Invite.GetGuildRanks()
    if #ranks==0 then
        local lbl=rf:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
        lbl:SetPoint("CENTER"); lbl:SetText(SM.T("not_in_guild"))
        return
    end
    local BW,BH,COLS=165,28,4
    for i,rank in ipairs(ranks) do
        local col=(i-1)%COLS; local row=math.floor((i-1)/COLS)
        local btn=CreateFrame("Button",nil,rf)
        btn:SetSize(BW,BH); btn:SetPoint("TOPLEFT",rf,"TOPLEFT",8+col*(BW+6),-8-row*(BH+4))
        local bg=btn:CreateTexture(nil,"BACKGROUND")
        bg:SetAllPoints(); bg:SetColorTexture(0.1,0.1,0.13,1); btn._bg=bg
        local fs=btn:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        fs:SetAllPoints(); fs:SetJustifyH("CENTER"); fs:SetTextColor(0.8,0.8,0.8,1); fs:SetText(rank.name)
        local sel=false
        btn:SetScript("OnClick",function()
            sel=not sel
            if sel then
                bg:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.85); fs:SetTextColor(0.05,0.05,0.05,1)
                table.insert(f._selectedRanks,rank.index)
            else
                bg:SetColorTexture(0.1,0.1,0.13,1); fs:SetTextColor(0.8,0.8,0.8,1)
                for j,ri in ipairs(f._selectedRanks) do
                    if ri==rank.index then table.remove(f._selectedRanks,j); break end
                end
            end
        end)
    end
end

-- ============================================================
-- ONGLET 4 : PARAMÈTRES
-- ============================================================
local function MakeSlider(parent, label, minV, maxV, step, getValue, setValue, x, y, w)
    w = w or 200
    local H = 6   -- hauteur de la barre
    local THUMB = 12  -- taille du curseur

    -- Label + valeur sur la même ligne
    local lbl = parent:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    lbl:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    lbl:SetTextColor(0.65, 0.65, 0.7, 1)

    local valLbl = parent:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    valLbl:SetPoint("TOPLEFT", parent, "TOPLEFT", x + w + 8, y)
    valLbl:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
    valLbl:SetJustifyH("LEFT")

    -- Barre de fond (track)
    local track = parent:CreateTexture(nil, "ARTWORK")
    track:SetSize(w, H)
    track:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y - 16)
    track:SetColorTexture(0.15, 0.15, 0.20, 1)

    -- Barre de remplissage (fill)
    local fill = parent:CreateTexture(nil, "ARTWORK")
    fill:SetSize(1, H)
    fill:SetPoint("LEFT", track, "LEFT", 0, 0)
    fill:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 1)

    -- Curseur (thumb)
    local thumb = parent:CreateTexture(nil, "OVERLAY")
    thumb:SetSize(2, 14)
    thumb:SetPoint("CENTER", track, "LEFT", 0, 0)
    thumb:SetColorTexture(1, 1, 1, 1)

    -- Frame invisible pour capturer les clics/drag
    local hitbox = CreateFrame("Button", nil, parent)
    hitbox:SetSize(w, 18)
    hitbox:SetPoint("CENTER", track, "CENTER", 0, 0)
    hitbox:EnableMouse(true)

    local dragging = false
    local curVal = getValue()

    local function SetSliderValue(newVal)
        newVal = math.max(minV, math.min(maxV, newVal))
        newVal = math.floor(newVal / step + 0.5) * step
        curVal = newVal
        local pct = (newVal - minV) / (maxV - minV)
        fill:SetWidth(math.max(1, w * pct))
        thumb:SetPoint("CENTER", track, "LEFT", w * pct, 0)
        lbl:SetText(label .. " : " .. math.floor(newVal))
        valLbl:SetText(tostring(math.floor(newVal)))
        setValue(newVal)
    end

    local function GetMousePct()
        local mx = GetCursorPosition() / UIParent:GetEffectiveScale()
        local tx, _ = track:GetLeft(), track:GetBottom()
        local pct = math.max(0, math.min(1, (mx - tx) / w))
        return pct
    end

    hitbox:SetScript("OnMouseDown", function(s, btn)
        if btn == "LeftButton" then
            dragging = true
            SetSliderValue(minV + GetMousePct() * (maxV - minV))
        end
    end)
    hitbox:SetScript("OnMouseUp", function() dragging = false end)
    hitbox:SetScript("OnUpdate", function()
        if dragging then
            SetSliderValue(minV + GetMousePct() * (maxV - minV))
        end
    end)

    -- Scroll wheel
    hitbox:EnableMouseWheel(true)
    hitbox:SetScript("OnMouseWheel", function(_, delta)
        SetSliderValue(curVal + delta * step)
    end)

    SetSliderValue(curVal)
    return hitbox, y - 32
end

local function BuildSettingsTab(parent)
    local f=CreateFrame("Frame",nil,parent)
    f:SetPoint("TOPLEFT",parent,"TOPLEFT",SIDEBAR_W,CONTENT_Y)
    f:SetSize(PANEL_W,CONTENT_H+8); f:Hide()
    SM.BG(f, 0.07, 0.07, 0.10, 1)  -- fond opaque

    local y=-14
    local sep2=f:CreateTexture(nil,"ARTWORK"); sep2:SetSize(PANEL_W-16,1)
    sep2:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.4); y=y-10

    local alertCb = CreateFrame("CheckButton",nil,f,"UICheckButtonTemplate")
    alertCb:SetSize(22,22)
    alertCb:SetPoint("TOPLEFT",f,"TOPLEFT",8,y)
    alertCb:SetChecked(SolaryMDB.alerts_enabled ~= false)
    alertCb:SetScript("OnClick",function(s) SolaryMDB.alerts_enabled = s:GetChecked() end)
    local alertLbl = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    alertLbl:SetPoint("LEFT",alertCb,"RIGHT",4,0)
    alertLbl:SetText(SM.T("alerts_enabled"))
    alertLbl:SetTextColor(1,1,1,1)
    local alertDesc = f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    alertDesc:SetPoint("TOPLEFT",f,"TOPLEFT",34,y-18)
    alertDesc:SetTextColor(0.5,0.5,0.55,1)
    alertDesc:SetText(SM.T("alerts_desc"))
    y=y-46

    -- Pré-alerte boss
    local prealertLbl = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    prealertLbl:SetPoint("TOPLEFT",f,"TOPLEFT",8,y-4)
    prealertLbl:SetText(SM.T("prealert_label"))
    local prein=SM.Input(f,60,22,"5")
    prein:SetPoint("LEFT",prealertLbl,"RIGHT",6,0)
    SM.SetVal(prein,tostring((SolaryMDB.boss_timers and SolaryMDB.boss_timers.prealert_sec) or 5))
    prein:SetScript("OnTextChanged",function(s)
        local v=tonumber(SM.GetVal(s))
        if v and v>=1 and v<=30 then
            SolaryMDB.boss_timers=SolaryMDB.boss_timers or {}
            SolaryMDB.boss_timers.prealert_sec=v
        end
    end)
    y=y-34

    -- Private Aura Warning Text
    local pawCb = CreateFrame("CheckButton",nil,f,"UICheckButtonTemplate")
    pawCb:SetSize(22,22)
    pawCb:SetPoint("TOPLEFT",f,"TOPLEFT",8,y)
    pawCb:SetChecked(SolaryMDB.paw_enabled ~= false)
    pawCb:SetScript("OnClick",function(s)
        SolaryMDB.paw_enabled = s:GetChecked()
        SM.SetupPrivateWarningText()
    end)
    local pawLbl = f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    pawLbl:SetPoint("LEFT",pawCb,"RIGHT",4,0)
    pawLbl:SetText(SM.T("paw_label"))
    pawLbl:SetTextColor(1,1,1,1)
    y=y-26

    -- Slider échelle
    local scaleVal = SolaryMDB.paw_scale or 2
    local scaleLbl = f:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    scaleLbl:SetPoint("TOPLEFT",f,"TOPLEFT",32,y)
    scaleLbl:SetTextColor(0.55,0.55,0.6,1)
    scaleLbl:SetText(SM.T("paw_scale")..scaleVal)
    local scaleSlider = CreateFrame("Slider",nil,f,"MinimalSliderTemplate")
    scaleSlider:SetSize(160,16)
    scaleSlider:SetPoint("TOPLEFT",f,"TOPLEFT",100,y+2)
    scaleSlider:SetMinMaxValues(0.5,4)
    scaleSlider:SetValueStep(0.5)
    scaleSlider:SetValue(scaleVal)
    scaleSlider:SetScript("OnValueChanged",function(s,v)
        v = math.floor(v*10+0.5)/10
        SolaryMDB.paw_scale = v
        scaleLbl:SetText(SM.T("paw_scale")..v)
        SM.SetupPrivateWarningText()
    end)
    y=y-30

    -- Sons Private Auras — fenêtre séparée
    SM.Lbl(f,SM.T("pa_sounds"),"GameFontNormal",8,y,SM.OR); y=y-22

    -- Checkbox defaults
    local defCb = CreateFrame("CheckButton",nil,f,"UICheckButtonTemplate")
    defCb:SetSize(22,22); defCb:SetPoint("TOPLEFT",f,"TOPLEFT",8,y)
    defCb:SetChecked(SolaryMDB.pa_use_defaults ~= false)
    defCb:SetScript("OnClick",function(s)
        SolaryMDB.pa_use_defaults = s:GetChecked()
        SM.RegisterAllPASounds()
    end)
    local defLbl=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    defLbl:SetPoint("LEFT",defCb,"RIGHT",4,0)
    defLbl:SetText(SM.T("pa_defaults"))
    defLbl:SetTextColor(1,1,1,1)
    y=y-30

    SM.BBtn(f,200,26,SM.T("btn_edit_pa"),function()
        SM.OpenPASoundsWindow()
    end):SetPoint("TOPLEFT",f,"TOPLEFT",8,y)
    y=y-34

    local sepA=f:CreateTexture(nil,"ARTWORK"); sepA:SetSize(PANEL_W-16,1)
    sepA:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.4); y=y-12

    SM.Lbl(f,SM.T("frames_pos"),"GameFontNormal",8,y,SM.OR); y=y-20
    SM.Lbl(f,SM.T("frames_cmd"),nil,8,y)
    y=y-24

    SM.RBtn(f,200,24,SM.T("btn_lock"),function()
        if SM.LockAllFrames then SM.LockAllFrames() end
        SM.MoveMode = false
        
    end):SetPoint("TOPLEFT",f,"TOPLEFT",8,y)
    SM.OBtn(f,200,24,SM.T("btn_move"),function()
        if SM.UnlockAllFrames then SM.UnlockAllFrames() end
        SM.MoveMode = true
    end):SetPoint("TOPLEFT",f,"TOPLEFT",216,y)
    y=y-36

    local sep3=f:CreateTexture(nil,"ARTWORK"); sep3:SetSize(PANEL_W-16,1)
    sep3:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.4); y=y-16

    -- ── Apparence des alertes ─────────────────────────────
    SM.Lbl(f,SM.T("alert_appearance"),"GameFontNormal",8,y,SM.OR); y=y-26

    local function GetAlertW()  return (SolaryMDB.alert and SolaryMDB.alert.width)    or 380 end
    local function GetAlertFS() return (SolaryMDB.alert and SolaryMDB.alert.fontSize) or 22  end

    local slW, ny = MakeSlider(f, SM.T("alert_width"), 150, 700, 1, GetAlertW, function(v)
        SolaryMDB.alert = SolaryMDB.alert or {}
        SolaryMDB.alert.width = math.floor(v)
        if SM.SetAlertWidth then SM.SetAlertWidth(math.floor(v)) end
    end, 8, y, PANEL_W-200)
    y = ny

    local slFS, ny2 = MakeSlider(f, SM.T("alert_fontsize"), 10, 48, 1, GetAlertFS, function(v)
        SolaryMDB.alert = SolaryMDB.alert or {}
        SolaryMDB.alert.fontSize = math.floor(v)
    end, 8, y, PANEL_W-200)
    y = ny2

    local sep3b=f:CreateTexture(nil,"ARTWORK"); sep3b:SetSize(PANEL_W-16,1)
    sep3b:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.4); y=y-16

    SM.Lbl(f,SM.T("status_lbl"),"GameFontNormal",8,y,SM.OR); y=y-24
    local st=f:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    st:SetPoint("TOPLEFT",f,"TOPLEFT",8,y); st:SetTextColor(0.8,0.8,0.8,1)
    local bwS=BigWigsLoader and "|cFF55FF55BigWigs OK|r" or "|cFFAAAAAA—BigWigs|r"
    local dbS=DBM and "|cFF55FF55DBM OK|r" or "|cFFAAAAAA—DBM|r"
    local edS=SM.IsEditor() and ("|cFF55FF55"..SM.T("editor_lbl").."|r") or ("|cFFAAAAAAAA"..SM.T("reception_lbl").."|r")
    local spS="|cFFFFD700"..tostring(#SM.DefaultSpells).." "..SM.T("spells_loaded").."|r"
    st:SetText(bwS.."   "..dbS.."   "..edS.."   "..spS)
    y=y-30

    -- Break timer
    local sep3=f:CreateTexture(nil,"ARTWORK"); sep3:SetSize(PANEL_W-16,1)
    sep3:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.4); y=y-8

    if SM.IsEditor() or UnitIsGroupLeader("player") or UnitIsGroupAssistant("player") then
    SM.Lbl(f,SM.T("break_timer"),"GameFontNormal",8,y,SM.OR); y=y-16
    SM.Lbl(f,SM.T("break_desc"),nil,8,y); y=y-20

    -- Dropdown image break
    local breakImgSel = SM.T("random_lbl")
    local breakImgBtn = CreateFrame("Button",nil,f)
    breakImgBtn:SetSize(120,24); breakImgBtn:SetPoint("TOPLEFT",f,"TOPLEFT",8,y)
    local biBg=breakImgBtn:CreateTexture(nil,"BACKGROUND"); biBg:SetAllPoints(); biBg:SetColorTexture(0.12,0.12,0.16,1)
    local biBdr=breakImgBtn:CreateTexture(nil,"BORDER"); biBdr:SetAllPoints(); biBdr:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.25)
    local biLbl=breakImgBtn:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    biLbl:SetPoint("LEFT",breakImgBtn,"LEFT",6,0); biLbl:SetText(breakImgSel); biLbl:SetTextColor(0.9,0.9,0.9,1)
    local biArrow=breakImgBtn:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    biArrow:SetPoint("RIGHT",breakImgBtn,"RIGHT",-4,0); biArrow:SetText("v")

    local biMenu=CreateFrame("Frame",nil,f); biMenu:SetFrameStrata("TOOLTIP")
    biMenu:SetSize(120,22); biMenu:SetPoint("BOTTOMLEFT",breakImgBtn,"TOPLEFT",0,2)
    local biMenuBg=biMenu:CreateTexture(nil,"BACKGROUND"); biMenuBg:SetAllPoints(); biMenuBg:SetColorTexture(0.08,0.08,0.11,0.98)
    biMenu:Hide()

    breakImgBtn:SetScript("OnClick",function()
        if biMenu:IsShown() then biMenu:Hide(); return end
        for _,c in ipairs({biMenu:GetChildren()}) do c:Hide() end
        local imgs = {SM.T("random_lbl")}
        for _,n in ipairs(SM.MediaBreak or {}) do table.insert(imgs, n) end
        biMenu:SetHeight(#imgs*22)
        for i,name in ipairs(imgs) do
            local item=CreateFrame("Button",nil,biMenu)
            item:SetSize(120,22); item:SetPoint("TOPLEFT",biMenu,"TOPLEFT",0,-(i-1)*22)
            local ibg=item:CreateTexture(nil,"BACKGROUND"); ibg:SetAllPoints(); ibg:SetColorTexture(0,0,0,0)
            local ilbl=item:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            ilbl:SetPoint("LEFT",item,"LEFT",6,0); ilbl:SetText(name); ilbl:SetTextColor(0.85,0.85,0.9,1)
            item:SetScript("OnEnter",function() ibg:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.2) end)
            item:SetScript("OnLeave",function() ibg:SetColorTexture(0,0,0,0) end)
            local sn=name
            item:SetScript("OnClick",function()
                breakImgSel=sn; biLbl:SetText(sn); biMenu:Hide()
            end)
        end
        biMenu:Show()
    end)

    local durInput = SM.Input(f, 44, 24, "5")
    durInput:SetPoint("TOPLEFT",f,"TOPLEFT",134,y)
    SM.Lbl(f,"min",nil,184,y+6)

    local launchBreakBtn = SM.GBtn(f,110,26,SM.T("btn_launch_break"),function()
        biMenu:Hide()
        SM._breakForcedImage = (breakImgSel ~= SM.T("random_lbl")) and breakImgSel or nil
        local mins = tonumber(SM.GetVal(durInput)) or 5
        if SM.BroadcastBreak then SM.BroadcastBreak(mins * 60) end
    end)
    launchBreakBtn:SetPoint("TOPLEFT",f,"TOPLEFT",202,y)
    end -- fin if éditeur break



    return f
end

-- ============================================================
-- ONGLET 5 : NOTES / ASSIGNATIONS
-- ============================================================

-- ============================================================
-- BUILD + TOGGLE
-- ============================================================
-- ONGLET BOSS TIMERS
-- ============================================================
-- ============================================================
-- HELPER : Slider style BigWigs
-- ============================================================
-- ─── Toggle pill helper (réutilisable) ─────────────────────
local function MakeToggle(parent, isOn, onChange)
    local TW, TH = 40, 22
    local tog = CreateFrame("Button", nil, parent)
    tog:SetSize(TW, TH)
    local trackBg = tog:CreateTexture(nil, "BACKGROUND")
    trackBg:SetAllPoints()
    local thumb = tog:CreateTexture(nil, "ARTWORK")
    thumb:SetSize(TH - 4, TH - 4)
    local state = isOn
    local function Refresh()
        thumb:ClearAllPoints()
        if state then
            trackBg:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.85)
            thumb:SetColorTexture(0.96, 0.92, 1.0, 1)
            thumb:SetPoint("RIGHT", tog, "RIGHT", -2, 0)
        else
            trackBg:SetColorTexture(0.16, 0.14, 0.22, 1)
            thumb:SetColorTexture(0.45, 0.42, 0.55, 1)
            thumb:SetPoint("LEFT", tog, "LEFT", 2, 0)
        end
    end
    tog:SetScript("OnClick", function()
        state = not state; Refresh(); onChange(state)
    end)
    tog._setState = function(v) state = v; Refresh() end
    Refresh()
    return tog
end

local function GetSpellTex(id)
    if not id then return nil end
    if C_Spell and C_Spell.GetSpellTexture then return C_Spell.GetSpellTexture(id) end
    if GetSpellTexture then return GetSpellTexture(id) end
    return nil
end

local function BuildBossTimerTab(parent)
    local f = CreateFrame("Frame", nil, parent)
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", SIDEBAR_W, CONTENT_Y)
    f:SetSize(PANEL_W, CONTENT_H+8); f:Hide()
    SM.BG(f, 0.07, 0.06, 0.10, 1)

    local COL_W = math.floor((PANEL_W - 28) / 2)
    local HDR_H = 44
    local ROW_W = COL_W - 4   -- largeur des lignes dans le scroll

    -- ── COLONNE GAUCHE : Mécaniques intelligentes ────────
    local cL = CreateFrame("Frame", nil, f)
    cL:SetSize(COL_W, CONTENT_H + 4)
    cL:SetPoint("TOPLEFT", f, "TOPLEFT", 8, -4)

    local cLHdr = CreateFrame("Frame", nil, cL)
    cLHdr:SetPoint("TOPLEFT", cL, "TOPLEFT", 0, 0)
    cLHdr:SetPoint("TOPRIGHT", cL, "TOPRIGHT", 0, 0); cLHdr:SetHeight(HDR_H)
    local _hb = cLHdr:CreateTexture(nil,"BACKGROUND"); _hb:SetAllPoints(); _hb:SetColorTexture(0.05,0.04,0.09,1)
    local _hs = cLHdr:CreateTexture(nil,"ARTWORK")
    _hs:SetPoint("BOTTOMLEFT"); _hs:SetPoint("BOTTOMRIGHT"); _hs:SetHeight(1)
    _hs:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.4)
    local cLTitle = cLHdr:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    cLTitle:SetPoint("LEFT", cLHdr, "LEFT", 12, 0); cLTitle:SetTextColor(0.85,0.80,1.0,1)
    cLTitle:SetText(SM.T("smart_header") or "MÉCANIQUES INTELLIGENTES")
    local cLSub = cLHdr:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    cLSub:SetPoint("BOTTOMLEFT", cLHdr, "BOTTOMLEFT", 12, 6); cLSub:SetTextColor(0.45,0.40,0.60,1)
    cLSub:SetText(SM.T("smart_desc") or "")

    local leftScroll = SM.Scroll(cL, COL_W - 4, CONTENT_H + 4 - HDR_H - 2)
    leftScroll:SetPoint("TOPLEFT", cL, "TOPLEFT", 2, -HDR_H)

    local ly = 0
    if SM.SmartAlert then
        for _, mech in ipairs(SM.SmartAlert.GetMechanics()) do
            local MECH_H = 82
            local row = CreateFrame("Frame", nil, leftScroll.content)
            row:SetSize(ROW_W, MECH_H); row:SetPoint("TOPLEFT", 0, -ly)
            SM.BG(row, 0.09, 0.07, 0.14, 1)
            local acc = row:CreateTexture(nil,"ARTWORK")
            acc:SetSize(3, MECH_H); acc:SetPoint("LEFT")
            acc:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],1)

            -- Icône sort
            local ico = row:CreateTexture(nil,"ARTWORK")
            ico:SetSize(38,38); ico:SetPoint("LEFT", row, "LEFT", 12, 0)
            local icoTex = GetSpellTex(mech.spellID)
            if icoTex then ico:SetTexture(icoTex) else ico:SetColorTexture(SM.OR[1]*0.35, SM.OR[2]*0.2, SM.OR[3]*0.45, 1) end

            -- Toggle
            local mechID = mech.id
            local tog = MakeToggle(row, SM.SmartAlert.IsEnabled(mechID), function(v)
                SM.SmartAlert.SetEnabled(mechID, v)
            end)
            tog:SetPoint("TOPRIGHT", row, "TOPRIGHT", -10, -16)

            -- Go button
            local _soakCast, _belorenSim = 0, 0
            local goBtn = SM.GBtn(row, 46, 24, "Go", function()
                if mech.type == "group_soak_fixed" then
                    _soakCast = _soakCast + 1
                    local isOdd = (_soakCast % 2 == 1)
                    local sub = 1
                    local name = UnitName("player")
                    for i=1,40 do local n,_,sg=GetRaidRosterInfo(i); if n==name and sg then sub=sg; break end end
                    local iMyTurn = (isOdd and sub<=2) or (not isOdd and sub>=3)
                    local msg = iMyTurn and "|cFF00FF00SOAK|r" or ((SM.LANG=="fr") and "|cFFFF4444SOAK PAS|r" or "|cFFFF4444DONT SOAK|r")
                    if SM.ShowTimedAlert then SM.ShowTimedAlert(msg, nil, mech.duration) end
                elseif mech.type == "beloren_feather" then
                    _belorenSim = _belorenSim + 1
                    if SM.Beloren then SM.Beloren._simulate(_belorenSim%2==1 and "light" or "void") end
                end
            end)
            goBtn:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", -10, 10)

            local nameLbl = row:CreateFontString(nil,"OVERLAY","GameFontNormal")
            nameLbl:SetPoint("TOPLEFT", row, "TOPLEFT", 60, -12)
            nameLbl:SetPoint("RIGHT", tog, "LEFT", -8, 0)
            nameLbl:SetJustifyH("LEFT"); nameLbl:SetTextColor(0.92,0.88,1.0,1)
            nameLbl:SetText(mech.label)

            local descLbl = row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            descLbl:SetPoint("TOPLEFT", row, "TOPLEFT", 60, -30)
            descLbl:SetPoint("RIGHT", tog, "LEFT", -8, 0)
            descLbl:SetJustifyH("LEFT"); descLbl:SetTextColor(0.52,0.48,0.62,1)
            descLbl:SetText(SM.LANG=="fr" and (mech.desc_fr or mech.desc_en) or (mech.desc_en or mech.desc_fr))

            local bossLbl = row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            bossLbl:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", 60, 10)
            bossLbl:SetPoint("RIGHT", goBtn, "LEFT", -6, 0)
            bossLbl:SetJustifyH("LEFT"); bossLbl:SetTextColor(SM.OR[1]*0.7,SM.OR[2]*0.55,SM.OR[3]*0.8,1)
            bossLbl:SetText(mech.boss)

            ly = ly + MECH_H + 6
        end
    end
    leftScroll.content:SetHeight(math.max(ly, CONTENT_H - HDR_H))

    -- ── COLONNE DROITE : Alertes de cast + Mythic Casts ──
    local cR = CreateFrame("Frame", nil, f)
    cR:SetSize(COL_W, CONTENT_H + 4)
    cR:SetPoint("TOPLEFT", cL, "TOPRIGHT", 12, 0)

    local cRHdr = CreateFrame("Frame", nil, cR)
    cRHdr:SetPoint("TOPLEFT", cR, "TOPLEFT", 0, 0)
    cRHdr:SetPoint("TOPRIGHT", cR, "TOPRIGHT", 0, 0); cRHdr:SetHeight(HDR_H)
    local _rhb = cRHdr:CreateTexture(nil,"BACKGROUND"); _rhb:SetAllPoints(); _rhb:SetColorTexture(0.05,0.04,0.09,1)
    local _rhs = cRHdr:CreateTexture(nil,"ARTWORK")
    _rhs:SetPoint("BOTTOMLEFT"); _rhs:SetPoint("BOTTOMRIGHT"); _rhs:SetHeight(1)
    _rhs:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.4)
    local cRTitle = cRHdr:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    cRTitle:SetPoint("LEFT", cRHdr, "LEFT", 12, 0); cRTitle:SetTextColor(0.85,0.80,1.0,1)
    cRTitle:SetText(SM.T("castbar_header") or "ALERTES DE CAST")
    local cRSub = cRHdr:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
    cRSub:SetPoint("BOTTOMLEFT", cRHdr, "BOTTOMLEFT", 12, 6); cRSub:SetTextColor(0.45,0.40,0.60,1)
    cRSub:SetText(SM.T("castbar_desc") or "")

    -- Go test dans le header droite
    if SM.CastBar then
        local testCBBtn = SM.GBtn(cRHdr, 46, 26, "Go", function()
            for _, mech in ipairs(SM.CastBar.GetMechanics()) do
                if SM.CastBar.IsEnabled(mech.id) then
                    if SM.CastBar.Test then SM.CastBar.Test(mech.label, mech.duration) end
                    return
                end
            end
        end)
        testCBBtn:SetPoint("RIGHT", cRHdr, "RIGHT", -10, 0)
    end

    local rightScroll = SM.Scroll(cR, COL_W - 4, CONTENT_H + 4 - HDR_H - 2)
    rightScroll:SetPoint("TOPLEFT", cR, "TOPLEFT", 2, -HDR_H)

    local ry = 0
    local CAST_H = 48

    -- Lignes CastBar
    if SM.CastBar then
        for _, mech in ipairs(SM.CastBar.GetMechanics()) do
            local row = CreateFrame("Frame", nil, rightScroll.content)
            row:SetSize(ROW_W, CAST_H); row:SetPoint("TOPLEFT", 0, -ry)
            SM.BG(row, 0.09, 0.07, 0.14, 1)
            local acc = row:CreateTexture(nil,"ARTWORK")
            acc:SetSize(3, CAST_H); acc:SetPoint("LEFT")
            acc:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.6)

            -- Icône sort
            local ico = row:CreateTexture(nil,"ARTWORK")
            ico:SetSize(34, 34); ico:SetPoint("LEFT", row, "LEFT", 10, 0)
            local tex = GetSpellTex(mech.spellID)
            if tex then ico:SetTexture(tex) else ico:SetColorTexture(SM.OR[1]*0.35,SM.OR[2]*0.2,SM.OR[3]*0.45,1) end

            -- Toggle
            local mechID = mech.id
            local tog = MakeToggle(row, SM.CastBar.IsEnabled(mechID), function(v)
                SM.CastBar.SetEnabled(mechID, v)
            end)
            tog:SetPoint("RIGHT", row, "RIGHT", -10, 0)

            local nameLbl = row:CreateFontString(nil,"OVERLAY","GameFontNormal")
            nameLbl:SetPoint("TOPLEFT", row, "TOPLEFT", 54, -10)
            nameLbl:SetPoint("RIGHT", tog, "LEFT", -8, 0)
            nameLbl:SetJustifyH("LEFT"); nameLbl:SetTextColor(0.92,0.88,1.0,1)
            nameLbl:SetText(mech.label)

            local bossLbl = row:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
            bossLbl:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", 54, 8)
            bossLbl:SetPoint("RIGHT", tog, "LEFT", -8, 0)
            bossLbl:SetJustifyH("LEFT"); bossLbl:SetTextColor(SM.OR[1]*0.65,SM.OR[2]*0.5,SM.OR[3]*0.75,1)
            bossLbl:SetText(mech.boss)

            ry = ry + CAST_H + 4
        end
    end

    -- Section Mythic Casts
    if SM.MythicCasts then
        ry = ry + 10
        local sep = rightScroll.content:CreateTexture(nil,"ARTWORK")
        sep:SetSize(ROW_W - 16, 1); sep:SetPoint("TOPLEFT", rightScroll.content, "TOPLEFT", 8, -ry)
        sep:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.3)
        ry = ry + 14

        -- Mini header section
        local mcHdrRow = CreateFrame("Frame", nil, rightScroll.content)
        mcHdrRow:SetSize(ROW_W, 32); mcHdrRow:SetPoint("TOPLEFT", 0, -ry)
        SM.BG(mcHdrRow, 0.05, 0.04, 0.09, 1)
        local mcTitle = mcHdrRow:CreateFontString(nil,"OVERLAY","GameFontNormal")
        mcTitle:SetPoint("LEFT", mcHdrRow, "LEFT", 10, 0)
        mcTitle:SetTextColor(SM.OR[1],SM.OR[2],SM.OR[3],1)
        mcTitle:SetText(SM.T("mythic_casts_header") or "CASTS ADDS (M+ & RAID)")

        local mcUnlocked = false
        local goBtn = SM.GBtn(mcHdrRow, 52, 24, "Go", function() end)
        goBtn:SetScript("OnClick", function()
            if mcUnlocked then
                mcUnlocked=false; goBtn._fs:SetText("Go")
                if SM.MythicCasts.Lock then SM.MythicCasts.Lock() end
            else
                mcUnlocked=true; goBtn._fs:SetText("Lock")
                if SM.MythicCasts.Unlock then SM.MythicCasts.Unlock() end
            end
        end)
        goBtn:SetPoint("RIGHT", mcHdrRow, "RIGHT", -6, 0)
        ry = ry + 36

        -- Ligne activer/désactiver
        local ROW_H2 = 40
        local mcEnRow = CreateFrame("Frame", nil, rightScroll.content)
        mcEnRow:SetSize(ROW_W, ROW_H2); mcEnRow:SetPoint("TOPLEFT", 0, -ry)
        SM.BG(mcEnRow, 0.09, 0.07, 0.14, 1)
        local mcAcc = mcEnRow:CreateTexture(nil,"ARTWORK")
        mcAcc:SetSize(3,ROW_H2); mcAcc:SetPoint("LEFT")
        mcAcc:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.6)

        local mcTog = MakeToggle(mcEnRow, SM.MythicCasts.IsEnabled(), function(v)
            SM.MythicCasts.SetEnabled(v)
        end)
        mcTog:SetPoint("RIGHT", mcEnRow, "RIGHT", -10, 0)

        local mcLbl = mcEnRow:CreateFontString(nil,"OVERLAY","GameFontNormal")
        mcLbl:SetPoint("LEFT", mcEnRow, "LEFT", 14, 0)
        mcLbl:SetPoint("RIGHT", mcTog, "LEFT", -8, 0)
        mcLbl:SetJustifyH("LEFT"); mcLbl:SetTextColor(0.92,0.88,1.0,1)
        mcLbl:SetText(SM.T("mythic_casts_enable") or "Activer les casts adds")
        ry = ry + ROW_H2 + 4

        -- Ligne taille
        local scRow = CreateFrame("Frame", nil, rightScroll.content)
        scRow:SetSize(ROW_W, ROW_H2); scRow:SetPoint("TOPLEFT", 0, -ry)
        SM.BG(scRow, 0.09, 0.07, 0.14, 1)
        local scAcc = scRow:CreateTexture(nil,"ARTWORK")
        scAcc:SetSize(3,ROW_H2); scAcc:SetPoint("LEFT")
        scAcc:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.6)

        local scTitleLbl = scRow:CreateFontString(nil,"OVERLAY","GameFontNormal")
        scTitleLbl:SetPoint("LEFT", scRow, "LEFT", 14, 0)
        scTitleLbl:SetTextColor(0.9,0.9,0.95,1)
        scTitleLbl:SetText(SM.T("mythic_casts_scale") or "Taille")

        local curScale = SM.MythicCasts.GetScale and SM.MythicCasts.GetScale() or 1.0
        local scValLbl = scRow:CreateFontString(nil,"OVERLAY","GameFontNormal")
        scValLbl:SetPoint("CENTER", scRow, "CENTER", 0, 0)
        scValLbl:SetTextColor(SM.OR[1],SM.OR[2],SM.OR[3],1)
        scValLbl:SetText(math.floor(curScale*100+0.5).."%")

        local function applyScale(s)
            s = math.max(0.50, math.min(2.0, math.floor(s*20+0.5)/20))
            scValLbl:SetText(math.floor(s*100+0.5).."%")
            if SM.MythicCasts.SetScale then SM.MythicCasts.SetScale(s) end
            curScale = s
        end
        local scMin = SM.OBtn(scRow, 28, 24, "−", function() applyScale(curScale-0.05) end)
        scMin:SetPoint("RIGHT", scValLbl, "LEFT", -6, 0)
        local scPlus = SM.OBtn(scRow, 28, 24, "+", function() applyScale(curScale+0.05) end)
        scPlus:SetPoint("LEFT", scValLbl, "RIGHT", 6, 0)

        ry = ry + ROW_H2 + 4
    end

    rightScroll.content:SetHeight(math.max(ry, CONTENT_H - HDR_H))

    return f
end

-- ============================================================
local function BuildMemoryTab(parent)
    local f = CreateFrame("Frame", nil, parent)
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", SIDEBAR_W, CONTENT_Y)
    f:SetSize(PANEL_W, CONTENT_H+8); f:Hide()
    SM.BG(f, 0.07, 0.07, 0.10, 1)
    if SM.MemoryGame and SM.MemoryGame.BuildInputPanel then
        local p = SM.MemoryGame.BuildInputPanel(f, PANEL_W, CONTENT_H)
        p:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0)
    end
    return f
end

local function BuildVersionTab(parent)
    if SM.VersionCheck and SM.VersionCheck.BuildTab then
        local f = SM.VersionCheck.BuildTab(parent, PANEL_W, CONTENT_H+8)
        f:SetPoint("TOPLEFT", parent, "TOPLEFT", SIDEBAR_W, CONTENT_Y)
        return f
    end
    -- Fallback si module non chargé
    local f = CreateFrame("Frame", nil, parent)
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", SIDEBAR_W, CONTENT_Y)
    f:SetSize(PANEL_W, CONTENT_H+8); f:Hide()
    SM.BG(f, 0.07, 0.07, 0.10, 1)
    return f
end

local CHANGELOGS = {
    {
        version = "3.0.0",
        date    = "27 Avril 2026",
        fr = {
            "Général — Refonte graphique de l'addon, plus compréhensible, plus clair",
            "MythicCasts — Fix du bug de secretvalue, fonctionne à nouveau normalement",
            "Spells — Ajout d'un bouton 'Supprimé' et 'Ajouter un sort' dans l'onglet"
        },
        en = {
            "General — Addon visual overhaul, more understandable and clearer",
            "MythicCasts — Fixed the secretvalue bug; it now works normally again",
            "Spells — Added 'Delete' and 'Add Spell' buttons to the tab.",
        },
    },
    {
        version = "2.0.5",
        date    = "26 Avril 2026",
        fr = {
            "MythicCasts — Les adds de Vaelgor & Ezzorak ainsi que Chimaerus n'afficherons plus leurs castsbar",
            "BossTimers — Fix sur le retour de multiples erreurs LUA contre Belo'ren & Crown",
            "Général — Le panel n'empêche plus le déplacement du personnage"
        },
        en = {
            "MythicCasts — Vaelgor & Ezzorak's add, as well as Chimaerus, will no longer display their cast bars.",
            "BossTimers — Fix on the return of multiple LUA errors against Belo'ren & Crown",
            "General — Panel no longer prevents the character from moving"
        },
    },
        {
        version = "2.0.4",
        date    = "25 Avril 2026",
        fr = {
            "Notes — Notes personnels sont désormais fonctionnel dans l'onglet 'Notes'",
            "Notes — Dropdowns affichent désormais uniquement les boss qui ont une note existante",
            "Général — Appuyer sur 'Echap' ferme maintenant le panel de l'addon",
            "Général — Changer la langue de l'addon ne reset plus le panel au milieu de l'écran"
        },
        en = {
            "Notes — Personal notes are now working in 'Notes' tab",
            "Notes — Dropdowns now only show the bosses with existing notes",
            "General — Pressing 'Escape' button now close the addon panel",
            "General — Changing the addon's language no longer resets the panel in the middle of the screen",
        },
    },
    {
        version = "2.0.3",
        date    = "24 Avril 2026",
        fr = {
            "Notes — Refonte visuelle complète du panneau Notes Partagées (layout deux colonnes, liste scrollable, éditeur droit)",
            "Notes — Dropdown boss & difficulté avec flèche texturée, icônes de boss via l'Encounter Journal",
            "Notes — Liste des boss mise à jour pour l'extension Midnight (Flèche du vide, Marche sur Quel'Danas, La faille du rêve)",
            "Notes — Sous-onglet 'Mes Notes' marqué WIP",
            "Notes — Suppression des caractères Unicode non supportés par les polices du jeu",
            "Notes — Correction du layout des boutons d'action en bas du panneau droit",
            "Notes — Champ de renommage ajouté dans l'éditeur droit",
            "Notes — Créer une note pré-assigne le boss du filtre actif et focus le champ nom automatiquement",
            "BossTimers — Correction erreur 'secret keys' sur UNIT_SPELLCAST_START (sorts protégés ignorés)",
        },
        en = {
            "Notes — Full visual rework of the Shared Notes panel (two-column layout, scrollable list, right-side editor)",
            "Notes — Boss & difficulty dropdowns with textured arrow, boss icons via Encounter Journal",
            "Notes — Boss list updated for the Midnight expansion (The Voidspire, March on Quel'Danas, The Dreamrift)",
            "Notes — 'My Notes' sub-tab marked WIP",
            "Notes — Removed Unicode characters unsupported by game fonts",
            "Notes — Fixed action button layout at the bottom of the right panel",
            "Notes — Rename field added in the right editor panel",
            "Notes — Creating a note pre-assigns the active boss filter and auto-focuses the name field",
            "BossTimers — Fixed 'secret keys' error on UNIT_SPELLCAST_START (protected spells now ignored)",
        },
    },
    {
        version = "2.0.2",
        date    = "24 Avril 2026",
        fr = {
            "MythicCasts — A nouveau fonctionnel, sans erreur LUA",
            "Reminders — Onglet Note Personnel rajouté (WIP)",
            "BossTimers — Plus d'erreur LUA pendant Crown/Belo'ren"
        },
        en = {
            "MythicCasts — Now works properly, no more LUA errors",
            "Reminders — Personal Notes now with Reminders (WIP)",
            "BossTimers — No more LUA errors while fighting Crown/Belo'ren"
        },
    },
    {
        version = "2.0.1",
        date    = "22 Avril 2026",
        fr = {
            "TOC — Passer en version 12.0.5 ",
            "Reminders — Erreur LUA du aux changements API fixé",
            "Reminders — Bouton Envoyer au raid a été placé sous la note, il ne gêne plus la box",
        },
        en = {
            "TOC — Updated to match 12.0.5",
            "Reminders — LUA errors caused by API changes fixed",
            "Reminders — Send to raid button is now under the note, no longer inside the box"
        },
    },
    {
        version = "2.0.0",
        date    = "21 Avril 2026",
        fr = {
            "Memory Game — L'ura (Midnight Falls) : affichage des runes en combat via CHAT_MSG_RAID",
            "Memory Game — icônes affichées via FontString + SetFormattedText",
            "Memory Game — bridge propre : RegisterEvent depuis contexte non-tainté (C_Timer + OnUpdate)",
            "Memory Game — icônes redimensionnées à 256px pour une lisibilité optimale en raid",
            "Memory Game — macros SOLMG_1..5 (7242384, etc.)",
            "Reminder — zone de collage de note avec scroll (plus de débordement sur les boutons)",
        },
        en = {
            "Memory Game — L'ura (Midnight Falls): rune display in combat via CHAT_MSG_RAID",
            "Memory Game — icons displayed via FontString + SetFormattedText",
            "Memory Game — clean bridge: RegisterEvent from untainted context (C_Timer + OnUpdate)",
            "Memory Game — icons resized to 256px for optimal raid readability",
            "Memory Game — SOLMG_1..5 (7242384, etc.)",
            "Reminder — note paste box now has a scroll (no more overflow onto buttons)",
        },
    },
    {
        version = "1.1.2",
        date    = "18 Avril 2026",
        fr = {
            "Mythic Casts — barre verte (interruptible) / grise (non interruptible)",
            "Mythic Casts — timer (ex: 3.2s) affiché à droite, coloré selon temps restant",
            "Mythic Casts — target inline à droite du nom du sort, colorée par classe",
            "Mythic Casts — filtrage des mobs hors combat avec le joueur",
            "Mythic Casts — icône affichée par-dessus la barre (corrige le recouvrement)",
            "Mythic Casts — slider de taille (50%–200%) dans le panel, sauvegardé",
            "Mythic Casts — correction du bouton Go (preview) dans le panel",
            "Correction erreur ADDON_ACTION_FORBIDDEN au login (RegisterEvent déplacé dans PLAYER_LOGIN)",
        },
        en = {
            "Mythic Casts — green bar (interruptible) / grey (not interruptible)",
            "Mythic Casts — timer (e.g. 3.2s) displayed on the right, color-coded by time left",
            "Mythic Casts — target inline right of spell name, class-colored",
            "Mythic Casts — filter out mobs not in combat with the player",
            "Mythic Casts — icon rendered above the bar fill (fixes overlap)",
            "Mythic Casts — size slider (50%–200%) in panel, saved between sessions",
            "Mythic Casts — fixed Go button (preview) in panel",
            "Fix ADDON_ACTION_FORBIDDEN error on login (RegisterEvent moved to PLAYER_LOGIN)",
        },
    },
    {
        version = "1.1.1",
        date    = "17 Avril 2026",
        fr = {
            "Module Mythic Casts — casts des adds en M+ et en raid (nameplates)",
            "Mythic Casts — affichage texte avec icône, décompte et target ciblée",
            "Mythic Casts — accent orange (interruptible) ou rouge (non interruptible)",
            "Mythic Casts — conteneur indépendant, déplaçable via Paramètres",
            "Mythic Casts — système de callouts : alerte centrale sur casts critiques",
            "Demiar (Crown) — callout STOP CAST sur Interrupting Tremor (1243743)",
            "Boutons — redesign : fond solide sombre, accent coloré gauche, hover propre",
            "Mode Move — les cadres désactivés n'apparaissent plus lors du déplacement",
            "Suppression des traductions FR de la SpellDB (193 entrées)",
        },
        en = {
            "Mythic Casts module — add casts in M+ and raid (nameplates)",
            "Mythic Casts — text display with icon, countdown and spell target",
            "Mythic Casts — orange accent (interruptible) or red (not interruptible)",
            "Mythic Casts — independent container, movable via Settings",
            "Mythic Casts — callout system: central alert on critical casts",
            "Demiar (Crown) — STOP CAST callout on Interrupting Tremor (1243743)",
            "Buttons — redesign: solid dark background, colored left accent, clean hover",
            "Move mode — disabled frames no longer appear when repositioning",
            "Removed FR translations from SpellDB (193 entries)",
        },
    },
    {
        version = "1.1.0",
        date    = "16 Avril 2026",
        fr = {
            "SmartCast — onglet renommé, réorganisé avec deux colonnes (mécaniques / alertes cast)",
            "Alertes cast — affichage texte décompté, conteneur séparé des alertes boss",
            "Alertes cast — support fixed, phased et spell_cast (détection CLEU)",
            "L'ura — Glaives, Transition (6.5s) et Intermission (30s) ajoutées",
            "Belo'ren — fenêtre Rebirth 30s détectée via CLEU (spellID 1263412)",
            "Belo'ren — icônes Light/Void depuis C_Spell.GetSpellTexture en simulation",
            "SmartAlert — descriptions traduites (desc_fr / desc_en)",
            "SmartAlert — SOAK / DONT SOAK sans labels de groupe",
            "Internationalisation complète FR/EN — bouton bascule dans le panel",
            "Pré-alerte déplacée dans Paramètres, s'applique aux alertes boss en général",
            "Suppression du doublon Media/break.tga (-1.4 Mo)",
        },
        en = {
            "SmartCast — tab renamed, reorganised with two columns (mechanics / cast alerts)",
            "Cast alerts — counted-down text display, container separate from boss alerts",
            "Cast alerts — fixed, phased and spell_cast support (CLEU detection)",
            "L'ura — Glaives, Transition (6.5s) and Intermission (30s) added",
            "Belo'ren — Rebirth 30s window detected via CLEU (spellID 1263412)",
            "Belo'ren — Light/Void icons from C_Spell.GetSpellTexture in simulation",
            "SmartAlert — translated descriptions (desc_fr / desc_en)",
            "SmartAlert — SOAK / DONT SOAK without group labels",
            "Full FR/EN internationalisation — toggle button in panel",
            "Pre-alert moved to Settings, applies to boss alerts in general",
            "Removed duplicate Media/break.tga (-1.4 MB)",
        },
    },
    {
        version = "1.0.5",
        date    = "15 Avril 2026",
        fr = {
            "Onglets dynamiques selon le rôle — éditeurs et non-éditeurs voient des onglets différents",
            "Non-éditeurs : uniquement Boss Timers, Paramètres, Changelogs",
            "Éditeurs : accès complet à tous les onglets",
            "Break Timer masqué pour les non-éditeurs",
            "Memory Game restreint aux éditeurs (envoi des symboles uniquement)",
            "Onglet Invites masqué pour les non-éditeurs",
            "Onglet Versions masqué pour les non-éditeurs",
            "Bouton Stop Break supprimé",
        },
        en = {
            "Dynamic tabs based on role — editors and non-editors see different tabs",
            "Non-editors: Boss Timers, Settings, Changelogs only",
            "Editors: full access to all tabs",
            "Break Timer hidden for non-editors",
            "Memory Game restricted to editors (symbol sending only)",
            "Invites tab hidden for non-editors",
            "Versions tab hidden for non-editors",
            "Stop Break button removed",
        },
    },
    {
        version = "1.0.4",
        date    = "15 Avril 2026",
        fr = {
            "Bouton minimap — icône Solary cliquable autour de la minimap via LibDBIcon",
            "Break Timer — images aléatoires sans répétition (shuffle)",
            "Break Timer — dropdown pour choisir une image spécifique ou aléatoire",
            "Break Timer — correction du bug stop/restart (timer de fade annulé proprement)",
            "Break Timer — correction du stop broadcast qui se déclenchait sur soi-même",
            "Sons Private Auras — sons baseline Midnight S1 Raid (29 sorts)",
            "Sons Private Auras — fenêtre dédiée avec liste scrollable",
            "Onglet Changelogs avec toggle Français/English",
        },
        en = {
            "Minimap button — Solary icon around the minimap via LibDBIcon",
            "Break Timer — random images without repetition (shuffle)",
            "Break Timer — dropdown to pick a specific or random image",
            "Break Timer — fixed stop/restart bug (fade timer properly cancelled)",
            "Break Timer — fixed stop broadcast triggering on self",
            "Private Aura Sounds — Midnight S1 Raid baseline sounds (29 spells)",
            "Private Aura Sounds — dedicated window with scrollable list",
            "Changelogs tab with French/English toggle",
        },
    },
    {
        version = "1.0.3",
        date    = "14 Avril 2026",
        fr = {
            "Sons Private Auras — fenêtre dédiée avec liste scrollable",
            "Sons Private Auras baseline Midnight S1 Raid intégrés (29 sorts)",
            "Activation/désactivation des sons par défaut via checkbox",
            "Correction Belo'ren — plus de gate ENCOUNTER_START, détection via UNIT_AURA directement",
            "Correction BossTimer — ProcessBWBar hors de portée (nil value)",
            "Correction Alert — barText secret ne plante plus sur :lower()",
            "Break Timer — images aléatoires depuis Media/Break/",
            "Scan automatique Media/Sounds et Media/Break au login",
            "Dropdown sons dynamique (liste depuis scan, pas hardcodée)",
            "Dropdown sons dans l'onglet Spells pour chaque mécanique",
            "Private Aura Warning Text — repositionnement précis via deux frames",
            "Suppression de la liste des éditeurs de l'onglet Paramètres",
        },
        en = {
            "Private Aura Sounds — dedicated window with scrollable list",
            "Midnight S1 Raid baseline PA sounds built-in (29 spells)",
            "Enable/disable default PA sounds via checkbox",
            "Belo'ren fix — removed ENCOUNTER_START gate, direct UNIT_AURA detection",
            "BossTimer fix — ProcessBWBar out of scope (nil value)",
            "Alert fix — secret barText no longer crashes on :lower()",
            "Break Timer — random images from Media/Break/",
            "Auto-scan Media/Sounds and Media/Break on login",
            "Dynamic sound dropdown (from scan, not hardcoded)",
            "Sound dropdown in Spells tab per mechanic",
            "Private Aura Warning Text — precise repositioning via two frames",
            "Removed editors list from Settings tab",
        },
    },
    {
        version = "1.0.2",
        date    = "13 Avril 2026",
        fr = {
            "Module Belo'ren — détection Light/Void Feather via filtrage UNIT_AURA",
            "Affichage icône de la plume au centre de l'écran pendant 5 secondes",
            "Private Aura Warning Text — repositionner le texte Blizzard via SetPrivateWarningTextAnchor",
            "Son par mécanique — dropdown dans l'onglet Spells",
            "Suppression de SolaryM_Auras.lua (inutilisé)",
        },
        en = {
            "Belo'ren module — Light/Void Feather detection via UNIT_AURA filter",
            "Feather icon display centered on screen for 5 seconds",
            "Private Aura Warning Text — reposition Blizzard text via SetPrivateWarningTextAnchor",
            "Sound per mechanic — dropdown in Spells tab",
            "Removed SolaryM_Auras.lua (unused)",
        },
    },
    {
        version = "1.0.1",
        date    = "12 Avril 2026",
        fr = {
            "Version Check — sections RAID et GUILDE séparées",
            "Version Check — affiche les membres sans l'addon en rouge (NON INSTALLÉ)",
            "Version Check — réponses via canal RAID/GUILD (WHISPER bloqué en Midnight)",
            "Break Timer — Stop Break broadcast au raid (cache l'image chez tout le monde)",
            "TTS — joue 2 secondes avant l'impact de la mécanique",
            "Paramètres — compactage pour faire rentrer le Break Timer dans le cadre",
        },
        en = {
            "Version Check — separate RAID and GUILD sections",
            "Version Check — members without addon shown in red (NOT INSTALLED)",
            "Version Check — replies via RAID/GUILD channel (WHISPER blocked in Midnight)",
            "Break Timer — Stop Break broadcast to raid (hides image for everyone)",
            "TTS — plays 2 seconds before mechanic impact",
            "Settings — compacted to fit Break Timer inside frame",
        },
    },
    {
        version = "1.0.0",
        date    = "11 Avril 2026",
        fr = {
            "Sortie initiale de SolaryM",
            "Onglet Spells — callouts par sort avec TTS, broadcast raid",
            "Boss Timers — alertes visuelles via hook BigWigs",
            "Invites — gestion des invitations raid",
            "Memory Game L'ura — barre de saisie + broadcast en temps réel",
            "Version Check — vérifier qui a l'addon dans le raid/guilde",
            "Paramètres — seuil d'affichage, taille alertes, break timer",
        },
        en = {
            "Initial release of SolaryM",
            "Spells tab — per-spell callouts with TTS, raid broadcast",
            "Boss Timers — visual alerts via BigWigs hook",
            "Invites — raid invitation management",
            "Memory Game L'ura — input bar + real-time broadcast",
            "Version Check — see who has the addon in raid/guild",
            "Settings — display threshold, alert size, break timer",
        },
    },
}

local function BuildChangelogsTab(parent)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(PANEL_W, CONTENT_H+8)
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", SIDEBAR_W, CONTENT_Y)
    f:Hide()
    local bg = f:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints()
    bg:SetColorTexture(0.07,0.07,0.10,1)

    local y = -14

    local title = f:CreateFontString(nil,"OVERLAY","GameFontNormal")
    title:SetPoint("TOPLEFT",f,"TOPLEFT",14,y)
    title:SetTextColor(SM.OR[1],SM.OR[2],SM.OR[3],1)
    title:SetText("Changelogs — SolaryM")
    y = y - 28

    -- Toggle langue
    local lang = "fr"
    local langBtn = SM.BBtn(f, 80, 22, "English", nil)
    langBtn:SetPoint("TOPRIGHT", f, "TOPRIGHT", -14, y+24)

    -- Scroll
    local scroll = CreateFrame("ScrollFrame", nil, f, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", f, "TOPLEFT", 14, y)
    scroll:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -30, 8)
    local scrollContent = CreateFrame("Frame", nil, scroll)
    scrollContent:SetSize(PANEL_W - 50, 1)
    scroll:SetScrollChild(scrollContent)

    -- Pré-créer toutes les FontStrings et les stocker pour update rapide
    local lineLabels = {}  -- { {vhdr, lines={}}, ... }

    local function BuildLines()
        local ry = 0
        for _, entry in ipairs(CHANGELOGS) do
            local vhdr = scrollContent:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
            vhdr:SetPoint("TOPLEFT", scrollContent, "TOPLEFT", 0, -ry)
            vhdr:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
            ry = ry + 22

            local sep = scrollContent:CreateTexture(nil,"ARTWORK")
            sep:SetSize(PANEL_W-60, 1)
            sep:SetPoint("TOPLEFT", scrollContent, "TOPLEFT", 0, -ry)
            sep:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.3)
            ry = ry + 8

            local entryLines = {}
            local maxLines = math.max(#entry.fr, #entry.en)
            for i = 1, maxLines do
                local dot = scrollContent:CreateFontString(nil,"OVERLAY","GameFontHighlight")
                dot:SetPoint("TOPLEFT", scrollContent, "TOPLEFT", 4, -ry)
                dot:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 0.7)
                dot:SetText("•")

                local lbl = scrollContent:CreateFontString(nil,"OVERLAY","GameFontHighlight")
                lbl:SetPoint("TOPLEFT", scrollContent, "TOPLEFT", 16, -ry)
                lbl:SetPoint("RIGHT", scrollContent, "RIGHT", -4, 0)
                lbl:SetJustifyH("LEFT")
                lbl:SetTextColor(0.8, 0.8, 0.85, 1)
                table.insert(entryLines, {dot=dot, lbl=lbl})
                ry = ry + 22
            end
            table.insert(lineLabels, {vhdr=vhdr, lines=entryLines, entry=entry})
            ry = ry + 20
        end
        scrollContent:SetHeight(math.max(ry, 1))
    end

    local function Rebuild()
        for _, block in ipairs(lineLabels) do
            local entry = block.entry
            block.vhdr:SetText("v"..entry.version.."  |cFF666666"..entry.date.."|r")
            local lines = lang == "fr" and entry.fr or entry.en
            for i, pair in ipairs(block.lines) do
                local txt = lines[i] or ""
                pair.lbl:SetText(txt)
                pair.dot:SetShown(txt ~= "")
                pair.lbl:SetShown(txt ~= "")
            end
        end
    end

    BuildLines()

    langBtn:SetScript("OnClick", function()
        if lang == "fr" then
            lang = "en"
            if langBtn._fs then langBtn._fs:SetText("Français") end
        else
            lang = "fr"
            if langBtn._fs then langBtn._fs:SetText("English") end
        end
        Rebuild()
    end)

    Rebuild()
    return f
end

-- ============================================================
-- ONGLET NOTES — sous-onglets "Notes Partagées" | "Mes Notes"
-- ============================================================
local function BuildRemindersTab(parent)
    local RN = SM.ReminderNote

    if not StaticPopupDialogs["SOLARYM_CONFIRM_DEL"] then
        StaticPopupDialogs["SOLARYM_CONFIRM_DEL"] = {
            text = "%s", button1 = SM.T("rem_btn_delete"), button2 = SM.T("rem_btn_cancel"),
            OnAccept = function(self) if self._cb then self._cb() end end,
            timeout = 0, whileDead = true, hideOnEscape = true, preferredIndex = 3,
        }
    end
    local function ConfirmDel(text, cb)
        local d = StaticPopup_Show("SOLARYM_CONFIRM_DEL", text)
        if d then d._cb = cb end
    end

    local f = CreateFrame("Frame", nil, parent)
    f:SetPoint("TOPLEFT", parent, "TOPLEFT", SIDEBAR_W, CONTENT_Y)
    f:SetSize(PANEL_W, CONTENT_H+8); f:Hide()
    SM.BG(f, 0.07, 0.07, 0.10, 1)

    -- ── Barre de sous-onglets ─────────────────────────────────
    local STAB_H = 40
    local subH   = CONTENT_H + 8 - STAB_H - 1

    local function MakeSubTabBtn(label, xOff)
        local btn = CreateFrame("Button", nil, f)
        btn:SetSize(185, STAB_H)
        btn:SetPoint("TOPLEFT", f, "TOPLEFT", xOff, 0)
        local bg = btn:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints(); bg:SetColorTexture(0.06, 0.06, 0.09, 1)
        btn._bg = bg
        btn:SetHighlightTexture([[Interface\Buttons\UI-Listbox-Highlight2]])
        local hlt = btn:GetHighlightTexture()
        if hlt then hlt:SetBlendMode("ADD"); hlt:SetAlpha(0.12) end
        local lbl = btn:CreateFontString(nil, "OVERLAY")
        lbl:SetFont("Fonts\\ARIALN.TTF", 14, "")
        lbl:SetPoint("CENTER", btn, "CENTER", 0, 1)
        lbl:SetText(label)
        lbl:SetTextColor(0.48, 0.48, 0.55, 1)
        btn._lbl = lbl
        -- Liseré coloré en bas = indicateur d'onglet actif
        local accent = btn:CreateTexture(nil, "ARTWORK")
        accent:SetHeight(2)
        accent:SetPoint("BOTTOMLEFT",  btn, "BOTTOMLEFT",  2, 0)
        accent:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", -2, 0)
        accent:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 1)
        accent:Hide()
        btn._accent = accent
        return btn
    end

    local sharedBtn   = MakeSubTabBtn(SM.T("rem_subtab_shared"),   0)
    local personalBtn = MakeSubTabBtn(SM.T("rem_subtab_personal"), 187)

    -- Séparateur sous la barre
    local tabSep = f:CreateTexture(nil, "ARTWORK")
    tabSep:SetHeight(1)
    tabSep:SetPoint("TOPLEFT",  f, "TOPLEFT",  0, -STAB_H)
    tabSep:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, -STAB_H)
    tabSep:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.30)

    -- ── Panneau Notes Partagées ───────────────────────────────
    local sharedPane = CreateFrame("Frame", nil, f)
    sharedPane:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -(STAB_H + 1))
    sharedPane:SetSize(PANEL_W, subH)

    -- ── Panneau Mes Notes ─────────────────────────────────────
    local personalPane = SM.PersonalNotes.BuildTab(f, PANEL_W, subH)
    personalPane:ClearAllPoints()
    personalPane:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -(STAB_H + 1))
    personalPane:Hide()

    -- ── Logique de sélection ──────────────────────────────────
    local function activateShared()
        sharedPane:Show(); personalPane:Hide()
        sharedBtn._bg:SetColorTexture(SM.OR[1]*0.13, SM.OR[2]*0.13, SM.OR[3]*0.18, 1)
        sharedBtn._lbl:SetTextColor(1, 1, 1, 1)
        sharedBtn._accent:Show()
        personalBtn._bg:SetColorTexture(0.06, 0.06, 0.09, 1)
        personalBtn._lbl:SetTextColor(0.48, 0.48, 0.55, 1)
        personalBtn._accent:Hide()
    end

    local function activatePersonal()
        sharedPane:Hide(); personalPane:Show()
        personalBtn._bg:SetColorTexture(SM.OR[1]*0.13, SM.OR[2]*0.13, SM.OR[3]*0.18, 1)
        personalBtn._lbl:SetTextColor(1, 1, 1, 1)
        personalBtn._accent:Show()
        sharedBtn._bg:SetColorTexture(0.06, 0.06, 0.09, 1)
        sharedBtn._lbl:SetTextColor(0.48, 0.48, 0.55, 1)
        sharedBtn._accent:Hide()
    end

    sharedBtn:SetScript("OnClick",   activateShared)
    personalBtn:SetScript("OnClick", activatePersonal)

    -- ── Contenu Notes Partagées ───────────────────────────────
    local lPAD   = 8
    local LEFT_W = 285
    local L_ROW_H = 26
    local L_ROW_GAP = 1
    local L_HDR_H = 38
    local L_BTN_H = 24
    local L_DROP_H = 26
    local R_TBAR_H = 28
    local R_BBAR_H = 32
    local R_PAD    = 10

    -- Métadonnées boss/difficulté associées aux notes
    local function getMeta(name)
        if not SolaryMDB then return {} end
        SolaryMDB.reminders_meta = SolaryMDB.reminders_meta or {}
        SolaryMDB.reminders_meta[name] = SolaryMDB.reminders_meta[name] or {}
        return SolaryMDB.reminders_meta[name]
    end

    local selName    = nil
    local listRows   = {}
    local filterBoss = nil
    local filterDrop
    local noteEditor, noteNameInput, bossDrop, diffDrop, recvNameLbl, rNoSelLbl

    -- EJ icon cache: dungeonEncID → creature portrait texture (or false if not found)
    -- EJ_GetCreatureInfo requires journal encounter IDs, not dungeon IDs; iterate to map them.
    local ejIconCache = {}
    do
        local targets = {[3134]=true,[3135]=true,[3176]=true,[3177]=true,[3178]=true,
                         [3179]=true,[3180]=true,[3181]=true,[3182]=true,[3183]=true,[3306]=true}
        local found = 0
        for jID = 1, 4000 do
            if found >= 11 then break end
            -- EJ_GetEncounterInfo returns: name, desc, journalEncID, rootSectionID, link, journalInstID, dungeonEncID
            local name, _, _, _, _, _, dungeonEncID = EJ_GetEncounterInfo(jID)
            if name and dungeonEncID and targets[dungeonEncID] then
                local _, _, _, _, icon = EJ_GetCreatureInfo(1, jID)
                ejIconCache[dungeonEncID] = icon or false
                found = found + 1
            end
        end
    end

    -- Boss list (Midnight —)
    local BOSS_LIST = {
        {text=SM.T("rem_boss_none"),  value=nil},
        {text="-- The Voidspire --", value=nil, isHeader=true},
        {text="Imperator Averzian",   value=3176},
        {text="Vorasius",             value=3177},
        {text="Vaelgor & Ezzorak",    value=3178},
        {text="Fallen King Salhadaar",value=3179},
        {text="Lightblinded Vanguard",value=3180},
        {text="Crown of the Cosmos",  value=3181},
        {text="-- March on Quel'Danas --", value=nil, isHeader=true},
        {text="Belo'ren",             value=3182},
        {text="Midnight Falls",       value=3183},
        {text="-- The Dreamrift --",        value=nil, isHeader=true},
        {text="Chimaerus",                   value=3306},
    }
    local DIFF_LIST = {
        {text="Normal",                  value="normal"},
        {text=SM.T("rem_diff_heroic"),   value="heroic"},
        {text=SM.T("rem_diff_mythic"),   value="mythic"},
    }

    -- ── Dropdown helper ──────────────────────────────────────
    local function MakeDrop(parent, w, h, items, onSelect)
        local btn = CreateFrame("Button", nil, parent)
        btn:SetSize(w, h)
        local bg = btn:CreateTexture(nil, "BACKGROUND")
        bg:SetAllPoints(); bg:SetColorTexture(0.05, 0.05, 0.09, 1)

        -- Icon on the main button (boss portrait when one is selected)
        local btnIcon = btn:CreateTexture(nil, "ARTWORK")
        btnIcon:SetSize(h - 6, h - 6)
        btnIcon:SetPoint("LEFT", btn, "LEFT", 4, 0)
        btnIcon:Hide()

        local lbl = btn:CreateFontString(nil, "OVERLAY")
        lbl:SetFont("Fonts\\ARIALN.TTF", 12, "")
        lbl:SetPoint("LEFT",  btn, "LEFT",  8, 0)
        lbl:SetPoint("RIGHT", btn, "RIGHT", -18, 0)
        lbl:SetJustifyH("LEFT"); lbl:SetJustifyV("MIDDLE")
        lbl:SetTextColor(0.82, 0.82, 0.86, 1)
        btn._lbl = lbl

        -- Arrow: scroll-down texture
        local arr = btn:CreateTexture(nil, "OVERLAY")
        arr:SetSize(16, 14)
        arr:SetPoint("RIGHT", btn, "RIGHT", 2, -1)
        arr:SetTexture([[Interface\Buttons\UI-ScrollBar-ScrollDownButton-Up]])
        arr:SetVertexColor(SM.OR[1], SM.OR[2], SM.OR[3], 0.85)

        local popup = CreateFrame("Frame", nil, sharedPane, "BackdropTemplate")
        popup:SetWidth(w)
        popup:SetFrameLevel(sharedPane:GetFrameLevel() + 60)
        popup:SetBackdrop({
            bgFile="Interface\\Tooltips\\UI-Tooltip-Background", tile=true, tileSize=32,
            edgeFile="Interface\\Buttons\\WHITE8X8", edgeSize=1,
        })
        popup:SetBackdropColor(0.07, 0.07, 0.11, 0.98)
        popup:SetBackdropBorderColor(SM.OR[1], SM.OR[2], SM.OR[3], 0.28)
        popup:Hide()
        btn._popup = popup

        local selValue = nil
        local rowBtns  = {}

        -- EJ creature portrait from pre-built cache (dungeonEncID → icon)
        local function getEncIcon(encID)
            if type(encID) ~= "number" then return nil end
            local v = ejIconCache[encID]
            if v then return v end  -- string/number texture; false or nil = not found
            return nil
        end

        -- Reanchor label left side depending on whether icon is visible
        local function applyBtnIcon(iconImg)
            lbl:ClearAllPoints()
            if iconImg then
                btnIcon:SetTexture(iconImg); btnIcon:Show()
                lbl:SetPoint("LEFT",  btnIcon, "RIGHT", 4, 0)
            else
                btnIcon:Hide()
                lbl:SetPoint("LEFT",  btn, "LEFT", 8, 0)
            end
            lbl:SetPoint("RIGHT", btn, "RIGHT", -18, 0)
        end

        local function UpdateHL()
            for i, rb in ipairs(rowBtns) do
                local same = (items[i].value == selValue) and not items[i].isHeader
                rb._sel:SetAlpha(same and 1 or 0)
                local isH = items[i].isHeader
                rb._lbl:SetTextColor(
                    same and 1 or (isH and 0.45 or 0.80),
                    same and 1 or (isH and 0.45 or 0.80),
                    same and 1 or (isH and 0.52 or 0.84), 1)
            end
        end

        local totalPopH = 0
        for i, item in ipairs(items) do
            local itemH = item.isHeader and 16 or 24
            local rb = CreateFrame("Button", nil, popup)
            rb:SetHeight(itemH)
            rb:SetPoint("TOPLEFT",  popup, "TOPLEFT",  1, -(totalPopH + 1))
            rb:SetPoint("TOPRIGHT", popup, "TOPRIGHT", -1, -(totalPopH + 1))
            local rbSel = rb:CreateTexture(nil, "BACKGROUND")
            rbSel:SetAllPoints()
            rbSel:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.14)
            rbSel:SetAlpha(0); rb._sel = rbSel
            if not item.isHeader then
                rb:SetHighlightTexture([[Interface\Buttons\UI-Listbox-Highlight2]])
                local hlt = rb:GetHighlightTexture()
                if hlt then hlt:SetBlendMode("ADD"); hlt:SetAlpha(0.18) end
            end

            -- Boss portrait icon in popup row
            local lblXOff = item.isHeader and 6 or 10
            if not item.isHeader and type(item.value) == "number" then
                local iconImg = getEncIcon(item.value)
                if iconImg then
                    local rbIcon = rb:CreateTexture(nil, "ARTWORK")
                    rbIcon:SetSize(16, 16)
                    rbIcon:SetPoint("LEFT", rb, "LEFT", 4, 0)
                    rbIcon:SetTexture(iconImg)
                    lblXOff = 24
                end
            end

            local rbLbl = rb:CreateFontString(nil, "OVERLAY")
            rbLbl:SetFont("Fonts\\ARIALN.TTF", item.isHeader and 10 or 12, "")
            rbLbl:SetPoint("LEFT",  rb, "LEFT",  lblXOff, 0)
            rbLbl:SetPoint("RIGHT", rb, "RIGHT", -4, 0)
            rbLbl:SetJustifyH("LEFT"); rbLbl:SetJustifyV("MIDDLE")
            rbLbl:SetText(item.text)
            rbLbl:SetTextColor(item.isHeader and 0.45 or 0.80, item.isHeader and 0.45 or 0.80, item.isHeader and 0.52 or 0.84, 1)
            rb._lbl = rbLbl
            if not item.isHeader then
                local iv = item
                rb:SetScript("OnClick", function()
                    selValue = iv.value
                    lbl:SetText(iv.text)
                    applyBtnIcon(type(iv.value) == "number" and getEncIcon(iv.value) or nil)
                    UpdateHL(); popup:Hide()
                    if onSelect then onSelect(iv.value, iv.text) end
                end)
            end
            rowBtns[i] = rb
            totalPopH = totalPopH + itemH
        end
        popup:SetHeight(totalPopH + 2)

        for _, item in ipairs(items) do
            if not item.isHeader then
                selValue = item.value; lbl:SetText(item.text)
                applyBtnIcon(type(item.value) == "number" and getEncIcon(item.value) or nil)
                break
            end
        end
        UpdateHL()

        btn:SetScript("OnClick", function()
            if popup:IsShown() then popup:Hide()
            else
                popup:ClearAllPoints()
                popup:SetPoint("TOPLEFT", btn, "BOTTOMLEFT", 0, -1)
                popup:Show()
            end
        end)
        btn.GetValue = function() return selValue end
        btn.SetByID  = function(val)
            for _, item in ipairs(items) do
                if item.value == val then
                    selValue = item.value; lbl:SetText(item.text)
                    applyBtnIcon(type(item.value) == "number" and getEncIcon(item.value) or nil)
                    UpdateHL(); return
                end
            end
            selValue = nil; lbl:SetText(items[1].text)
            applyBtnIcon(nil); UpdateHL()
        end
        -- Affiche uniquement les entrées dont la valeur est dans visibleSet (nil = tout afficher)
        -- Les entrées à valeur nil (header / "Tous les boss") sont toujours visibles
        btn.RefreshVisible = function(visibleSet)
            local totalH = 0
            for i, rb in ipairs(rowBtns) do
                local iv = items[i]
                local show = (visibleSet == nil) or (iv.value == nil) or (visibleSet[iv.value] == true)
                if show then
                    rb:Show()
                    rb:ClearAllPoints()
                    rb:SetPoint("TOPLEFT",  popup, "TOPLEFT",  1, -(totalH + 1))
                    rb:SetPoint("TOPRIGHT", popup, "TOPRIGHT", -1, -(totalH + 1))
                    totalH = totalH + rb:GetHeight()
                else
                    rb:Hide()
                end
            end
            popup:SetHeight(totalH + 2)
        end
        return btn
    end

    -- ── Panneau gauche ────────────────────────────────────────
    local lBg = CreateFrame("Frame", nil, sharedPane, "BackdropTemplate")
    lBg:SetPoint("TOPLEFT", sharedPane, "TOPLEFT", 0, 0)
    lBg:SetSize(LEFT_W, subH)
    lBg:SetBackdrop({bgFile=[[Interface\Tooltips\UI-Tooltip-Background]], tile=true, tileSize=64})
    lBg:SetBackdropColor(0.07, 0.07, 0.10, 1)

    local lDivider = lBg:CreateTexture(nil, "OVERLAY")
    lDivider:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.20)
    lDivider:SetWidth(1)
    lDivider:SetPoint("TOPRIGHT",    lBg, "TOPRIGHT",    0, 0)
    lDivider:SetPoint("BOTTOMRIGHT", lBg, "BOTTOMRIGHT", 0, 0)

    -- Titre bicolore
    local blueHex = string.format("%02x%02x%02x",
        math.floor(SM.OR[1]*255), math.floor(SM.OR[2]*255), math.floor(SM.OR[3]*255))
    local titleHdr = lBg:CreateFontString(nil, "OVERLAY")
    titleHdr:SetFont("Fonts\\ARIALN.TTF", 15, "")
    titleHdr:SetPoint("TOPLEFT", lBg, "TOPLEFT", lPAD, -lPAD)
    titleHdr:SetText("|cff"..blueHex.."Notes|r "..SM.T("rem_notes_shared_suffix"))
    titleHdr:SetTextColor(1, 1, 1, 1)

    -- 3 boutons d'action
    local bW3 = math.floor((LEFT_W - lPAD * 2 - 4) / 3)
    local importBtn = SM.Btn(lBg, bW3, L_BTN_H, SM.T("rem_btn_import"),
        SM.OR[1]*0.10, SM.OR[2]*0.10, SM.OR[3]*0.16, nil)
    importBtn:SetPoint("TOPLEFT", lBg, "TOPLEFT", lPAD, -(lPAD + L_HDR_H))

    local unloadBtn = SM.Btn(lBg, bW3, L_BTN_H, SM.T("rem_btn_unload"),
        0.10, 0.10, 0.14, nil)
    unloadBtn:SetPoint("LEFT", importBtn, "RIGHT", 2, 0)

    local delAllBtn = SM.Btn(lBg, bW3, L_BTN_H, SM.T("rem_btn_del_all"),
        SM.RED[1]*0.38, SM.RED[2]*0.10, SM.RED[3]*0.10, nil)
    delAllBtn:SetPoint("LEFT", unloadBtn, "RIGHT", 2, 0)

    -- Ligne "Reçu"
    local recvY = -(lPAD + L_HDR_H + L_BTN_H + 6)
    local recvLabel = lBg:CreateFontString(nil, "OVERLAY")
    recvLabel:SetFont("Fonts\\ARIALN.TTF", 12, "")
    recvLabel:SetPoint("TOPLEFT", lBg, "TOPLEFT", lPAD, recvY)
    recvLabel:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
    recvLabel:SetText(SM.T("rem_recv_label"))

    recvNameLbl = lBg:CreateFontString(nil, "OVERLAY")
    recvNameLbl:SetFont("Fonts\\ARIALN.TTF", 12, "")
    recvNameLbl:SetPoint("LEFT",  recvLabel, "RIGHT",  4, 0)
    recvNameLbl:SetPoint("RIGHT", lBg,       "RIGHT", -22, 0)
    recvNameLbl:SetJustifyH("LEFT")
    recvNameLbl:SetTextColor(0.75, 0.75, 0.80, 1)
    recvNameLbl:SetText(SM.T("rem_recv_none"))

    local recvXBtn = CreateFrame("Button", nil, lBg)
    recvXBtn:SetSize(18, 18)
    recvXBtn:SetPoint("TOPRIGHT", lBg, "TOPRIGHT", -lPAD + 2, recvY + 2)
    local recvXFS = recvXBtn:CreateFontString(nil, "OVERLAY")
    recvXFS:SetFont("Fonts\\ARIALN.TTF", 11, "")
    recvXFS:SetAllPoints(); recvXFS:SetText("[X]")
    recvXFS:SetTextColor(0.40, 0.40, 0.46, 1)
    recvXBtn:SetScript("OnEnter", function() recvXFS:SetTextColor(1, 0.3, 0.3, 1) end)
    recvXBtn:SetScript("OnLeave", function() recvXFS:SetTextColor(0.40, 0.40, 0.46, 1) end)
    recvXBtn:SetScript("OnClick", function()
        if RN then RN.ClearReceived() end
        recvNameLbl:SetText(SM.T("rem_recv_none"))
    end)

    -- Séparateur
    local lSepY = recvY - 20
    local lSep = lBg:CreateTexture(nil, "ARTWORK")
    lSep:SetHeight(1)
    lSep:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.18)
    lSep:SetPoint("TOPLEFT",  lBg, "TOPLEFT",  0, lSepY)
    lSep:SetPoint("TOPRIGHT", lBg, "TOPRIGHT", 0, lSepY)

    -- Filter dropdown
    local filterItems = {{text=SM.T("rem_filter_all_boss"), value=nil}}
    for _, b in ipairs(BOSS_LIST) do
        if not b.isHeader and b.value then
            filterItems[#filterItems+1] = {text=b.text, value=b.value}
        end
    end
    filterDrop = MakeDrop(lBg, LEFT_W - lPAD * 2, L_DROP_H, filterItems, function(val)
        filterBoss = val
        RefreshList()
    end)
    local filterDropY = lSepY - 5
    filterDrop:SetPoint("TOPLEFT", lBg, "TOPLEFT", lPAD, filterDropY)

    -- Zone liste scrollable
    local lScrollW   = LEFT_W - lPAD * 2 - 14
    local lScrollTopY = filterDropY - L_DROP_H - 4
    local lScrollBtmY = L_BTN_H + lPAD * 2

    local listScroll = CreateFrame("ScrollFrame", nil, lBg)
    listScroll:SetPoint("TOPLEFT", lBg, "TOPLEFT", lPAD, lScrollTopY)
    listScroll:SetSize(lScrollW, (-lScrollTopY) - lScrollBtmY)

    local listScrollBar = CreateFrame("Slider", nil, lBg, "UIPanelScrollBarTemplate")
    listScrollBar:SetPoint("TOPLEFT",    listScroll, "TOPRIGHT",    2, -16)
    listScrollBar:SetPoint("BOTTOMLEFT", listScroll, "BOTTOMRIGHT", 2,  16)
    listScrollBar:SetMinMaxValues(0, 0); listScrollBar:SetValueStep(L_ROW_H)
    listScrollBar:SetScript("OnValueChanged", function(_, val)
        listScroll:SetVerticalScroll(val)
    end)
    listScrollBar:SetValue(0)
    listScroll:EnableMouseWheel(true)
    listScroll:SetScript("OnMouseWheel", function(_, delta)
        local cur    = listScrollBar:GetValue()
        local lo, hi = listScrollBar:GetMinMaxValues()
        listScrollBar:SetValue(math.max(lo, math.min(hi, cur - delta * L_ROW_H * 3)))
    end)

    local listChild = CreateFrame("Frame", nil, listScroll)
    listChild:SetSize(lScrollW, 1)
    listScroll:SetScrollChild(listChild)

    -- Bouton créer : lit le nom + boss/diff déjà saisis dans le panneau droit
    local createBtn = SM.OBtn(lBg, LEFT_W - lPAD * 2, L_BTN_H, SM.T("rem_btn_create"), function()
        if not RN then return end
        local noteName = noteNameInput and noteNameInput:GetText() or ""
        if noteName == "" then noteName = "Nouvelle note" end
        local finalName = RN.Import(noteName, "")
        local meta = getMeta(finalName)
        if bossDrop then meta.boss = bossDrop.GetValue() end
        if diffDrop then meta.diff = diffDrop.GetValue() end
        selName = finalName
        RefreshList()
        LoadNoteInEditor(finalName)
        noteEditor:SetFocus()
    end)
    createBtn:SetPoint("BOTTOMLEFT", lBg, "BOTTOMLEFT", lPAD, lPAD)

    -- ── Panneau droit ─────────────────────────────────────────
    local rX = LEFT_W + 1
    local rW = PANEL_W - rX
    local rBg = CreateFrame("Frame", nil, sharedPane, "BackdropTemplate")
    rBg:SetPoint("TOPLEFT", sharedPane, "TOPLEFT", rX, 0)
    rBg:SetSize(rW, subH)
    rBg:SetBackdrop({bgFile=[[Interface\Tooltips\UI-Tooltip-Background]], tile=true, tileSize=64})
    rBg:SetBackdropColor(0.07, 0.07, 0.10, 1)

    -- Boss + Difficulté dropdowns
    local bossDropW = math.floor(rW * 0.56) - R_PAD
    local diffDropW = math.floor(rW * 0.30)

    bossDrop = MakeDrop(rBg, bossDropW, R_TBAR_H, BOSS_LIST, nil)
    bossDrop:SetPoint("TOPLEFT", rBg, "TOPLEFT", R_PAD, -R_PAD)

    diffDrop = MakeDrop(rBg, diffDropW, R_TBAR_H, DIFF_LIST, nil)
    diffDrop:SetPoint("LEFT", bossDrop, "RIGHT", 6, 0)

    -- Champ nom de la note
    local nameInputY = -(R_PAD + R_TBAR_H + 5)
    noteNameInput = CreateFrame("EditBox", nil, rBg, "InputBoxTemplate")
    noteNameInput:SetPoint("TOPLEFT",  rBg, "TOPLEFT",  R_PAD + 4, nameInputY)
    noteNameInput:SetPoint("TOPRIGHT", rBg, "TOPRIGHT", -R_PAD - 4, nameInputY)
    noteNameInput:SetHeight(22)
    noteNameInput:SetFont("Fonts\\ARIALN.TTF", 14, "")
    noteNameInput:SetAutoFocus(false)
    noteNameInput:SetMaxLetters(128)
    noteNameInput:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
    noteNameInput:SetScript("OnEnterPressed",  function(s) s:ClearFocus() end)
    noteNameInput:SetScript("OnEditFocusLost", function(s)
        if not selName then return end
        local newName = s:GetText()
        if newName == "" or newName == selName then return end
        -- Renommage : déplacer contenu + meta sous le nouveau nom
        if SolaryMDB then
            SolaryMDB.reminders = SolaryMDB.reminders or {}
            SolaryMDB.reminders[newName] = SolaryMDB.reminders[selName]
            SolaryMDB.reminders[selName] = nil
            SolaryMDB.reminders_meta = SolaryMDB.reminders_meta or {}
            SolaryMDB.reminders_meta[newName] = SolaryMDB.reminders_meta[selName]
            SolaryMDB.reminders_meta[selName] = nil
            if SolaryMDB.active_reminder == selName then
                SolaryMDB.active_reminder = newName
            end
        end
        selName = newName
        RefreshList()
    end)

    local rTopSep = rBg:CreateTexture(nil, "ARTWORK")
    rTopSep:SetHeight(1)
    rTopSep:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.18)
    local sepY = nameInputY - 22 - 4
    rTopSep:SetPoint("TOPLEFT",  rBg, "TOPLEFT",  0, sepY)
    rTopSep:SetPoint("TOPRIGHT", rBg, "TOPRIGHT", 0, sepY)

    -- Placeholder
    rNoSelLbl = rBg:CreateFontString(nil, "OVERLAY")
    rNoSelLbl:SetFont("Fonts\\ARIALN.TTF", 14, "")
    rNoSelLbl:SetPoint("CENTER", rBg, "CENTER", 0, 14)
    rNoSelLbl:SetText(SM.T("rem_no_selection"))
    rNoSelLbl:SetTextColor(0.28, 0.28, 0.32, 1)

    -- Éditeur de note
    local edTopY = sepY - 4
    local edScroll = CreateFrame("ScrollFrame", nil, rBg, "UIPanelScrollFrameTemplate")
    edScroll:SetPoint("TOPLEFT",     rBg, "TOPLEFT",      R_PAD,         edTopY)
    edScroll:SetPoint("BOTTOMRIGHT", rBg, "BOTTOMRIGHT", -(R_PAD + 18), R_BBAR_H + R_PAD)

    noteEditor = CreateFrame("EditBox", nil, edScroll)
    noteEditor:SetMultiLine(true); noteEditor:SetAutoFocus(false)
    noteEditor:SetFont("Fonts\\ARIALN.TTF", 13, "")
    noteEditor:SetMaxLetters(0)
    noteEditor:SetWidth(rW - R_PAD * 2 - 20)
    noteEditor:SetTextColor(0.88, 0.88, 0.92, 1)
    noteEditor:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
    noteEditor:SetScript("OnTextChanged", function(s)
        local w = edScroll:GetWidth()
        if w > 0 then s:SetWidth(w) end
    end)
    edScroll:SetScrollChild(noteEditor)
    edScroll:SetScript("OnSizeChanged", function(s, w)
        if w > 0 then noteEditor:SetWidth(w) end
    end)
    edScroll:SetScript("OnMouseDown", function() noteEditor:SetFocus() end)

    -- Boutons d'action (bas du panneau droit)
    local B_H  = 24
    local B_Y  = R_PAD
    local loadSendBtn = SM.BBtn(rBg, 130, B_H, SM.T("rem_btn_load_send"), nil)
    local saveBtn2    = SM.OBtn(rBg,  90, B_H, SM.T("rem_btn_save"),     nil)
    local delBtn2     = SM.RBtn(rBg,  90, B_H, SM.T("rem_btn_delete"),   nil)
    local showBtn     = SM.Btn( rBg,  90, B_H, SM.T("rem_btn_show"), 0.08, 0.12, 0.20, nil)
    local testBtn     = SM.OBtn(rBg,  55, B_H, SM.T("rem_btn_test"),     nil)
    local stopBtn     = SM.RBtn(rBg,  55, B_H, SM.T("rem_btn_stop"),     nil)

    loadSendBtn:SetPoint("BOTTOMLEFT",  rBg, "BOTTOMLEFT",  R_PAD,                          B_Y)
    saveBtn2:SetPoint(   "BOTTOMLEFT",  rBg, "BOTTOMLEFT",  R_PAD + 130 + 4,                B_Y)
    delBtn2:SetPoint(    "BOTTOMLEFT",  rBg, "BOTTOMLEFT",  R_PAD + 130 + 4 + 90 + 4,      B_Y)
    showBtn:SetPoint(    "BOTTOMLEFT",  rBg, "BOTTOMLEFT",  R_PAD + 130 + 4 + 90 + 4 + 90 + 4, B_Y)
    stopBtn:SetPoint(    "BOTTOMRIGHT", rBg, "BOTTOMRIGHT", -R_PAD,                         B_Y)
    testBtn:SetPoint(    "BOTTOMRIGHT", rBg, "BOTTOMRIGHT", -R_PAD - 55 - 4,                B_Y)

    -- ── Overlay Import ────────────────────────────────────────
    local importOverlay = CreateFrame("Frame", nil, sharedPane, "BackdropTemplate")
    importOverlay:SetPoint("TOPLEFT", sharedPane, "TOPLEFT", rX, 0)
    importOverlay:SetSize(rW, subH)
    importOverlay:SetBackdrop({bgFile=[[Interface\Tooltips\UI-Tooltip-Background]], tile=true, tileSize=64})
    importOverlay:SetBackdropColor(0.06, 0.06, 0.10, 0.97)
    importOverlay:SetFrameLevel(rBg:GetFrameLevel() + 10)
    importOverlay:Hide()

    local impTitle = importOverlay:CreateFontString(nil, "OVERLAY")
    impTitle:SetFont("Fonts\\ARIALN.TTF", 14, "")
    impTitle:SetPoint("TOPLEFT", importOverlay, "TOPLEFT", R_PAD, -R_PAD)
    impTitle:SetText(SM.T("rem_import_header"))
    impTitle:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)

    local impCloseBtn = CreateFrame("Button", nil, importOverlay)
    impCloseBtn:SetSize(20, 20)
    impCloseBtn:SetPoint("TOPRIGHT", importOverlay, "TOPRIGHT", -R_PAD, -R_PAD)
    local impCloseFS = impCloseBtn:CreateFontString(nil, "OVERLAY")
    impCloseFS:SetFont("Fonts\\ARIALN.TTF", 13, "")
    impCloseFS:SetAllPoints(); impCloseFS:SetText("[X]")
    impCloseFS:SetTextColor(0.40, 0.40, 0.46, 1)
    impCloseBtn:SetScript("OnEnter", function() impCloseFS:SetTextColor(1, 0.3, 0.3, 1) end)
    impCloseBtn:SetScript("OnLeave", function() impCloseFS:SetTextColor(0.40, 0.40, 0.46, 1) end)
    impCloseBtn:SetScript("OnClick", function() importOverlay:Hide() end)

    local impNameHdr = importOverlay:CreateFontString(nil, "OVERLAY")
    impNameHdr:SetFont("Fonts\\ARIALN.TTF", 12, "")
    impNameHdr:SetPoint("TOPLEFT", importOverlay, "TOPLEFT", R_PAD, -(R_PAD + 28))
    impNameHdr:SetText(SM.T("rem_name_label"))
    impNameHdr:SetTextColor(0.60, 0.60, 0.66, 1)

    local impNameInput = SM.Input(importOverlay, rW - R_PAD * 2, 22, "Ex: Crown Mythique")
    impNameInput:SetPoint("TOPLEFT", importOverlay, "TOPLEFT", R_PAD, -(R_PAD + 46))

    local impPasteHdr = importOverlay:CreateFontString(nil, "OVERLAY")
    impPasteHdr:SetFont("Fonts\\ARIALN.TTF", 12, "")
    impPasteHdr:SetPoint("TOPLEFT", importOverlay, "TOPLEFT", R_PAD, -(R_PAD + 78))
    impPasteHdr:SetText(SM.T("rem_paste_label"))
    impPasteHdr:SetTextColor(0.60, 0.60, 0.66, 1)

    local impPasteScroll = CreateFrame("ScrollFrame", nil, importOverlay, "UIPanelScrollFrameTemplate")
    impPasteScroll:SetPoint("TOPLEFT",     importOverlay, "TOPLEFT",      R_PAD,         -(R_PAD + 96))
    impPasteScroll:SetPoint("BOTTOMRIGHT", importOverlay, "BOTTOMRIGHT", -(R_PAD + 18),  36)
    SM.BG(impPasteScroll, 0.04, 0.04, 0.07, 1)

    local impPasteBox = CreateFrame("EditBox", nil, impPasteScroll)
    impPasteBox:SetMultiLine(true); impPasteBox:SetAutoFocus(false)
    impPasteBox:SetFont("Fonts\\ARIALN.TTF", 12, "")
    impPasteBox:SetMaxLetters(0)
    impPasteBox:SetWidth(rW - R_PAD * 2 - 20)
    impPasteBox:SetTextColor(0.88, 0.88, 0.92, 1)
    impPasteBox:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
    impPasteScroll:SetScrollChild(impPasteBox)
    impPasteScroll:SetScript("OnMouseDown", function() impPasteBox:SetFocus() end)

    local impConfirmBtn = SM.OBtn(importOverlay, 110, 24, SM.T("rem_btn_import"), nil)
    impConfirmBtn:SetPoint("BOTTOMLEFT", importOverlay, "BOTTOMLEFT", R_PAD, R_PAD)

    local impCancelBtn = SM.RBtn(importOverlay, 80, 24, SM.T("rem_btn_cancel"), nil)
    impCancelBtn:SetPoint("LEFT", impConfirmBtn, "RIGHT", 4, 0)
    impCancelBtn:SetScript("OnClick", function() importOverlay:Hide() end)

    -- ── Logique ───────────────────────────────────────────────
    function LoadNoteInEditor(name)
        selName = name
        rNoSelLbl:Hide()
        noteNameInput:SetText(name)
        noteNameInput:SetTextColor(1, 1, 1, 1)
        local content = (SolaryMDB and SolaryMDB.reminders and SolaryMDB.reminders[name]) or ""
        noteEditor:SetText(content)
        local meta = getMeta(name)
        bossDrop.SetByID(meta.boss)
        diffDrop.SetByID(meta.diff)
        RefreshList()
    end

    function RefreshList()
        for _, ro in ipairs(listRows) do ro.btn:Hide() end
        listRows = {}
        if not RN then return end

        -- Received indicator
        if RN.GetLastReceived then
            local recv = RN.GetLastReceived()
            recvNameLbl:SetText(recv and recv or SM.T("rem_recv_none"))
        end

        local names = RN.GetNames()
        local totalH = 0
        local hasVisible = false

        -- Bosses ayant au moins une note
        local bossesWithNotes = {}
        for _, n in ipairs(names) do
            local m = getMeta(n)
            if m.boss then bossesWithNotes[m.boss] = true end
        end
        -- Si le filtre actuel n'a plus de notes, réinitialiser
        if filterBoss and not bossesWithNotes[filterBoss] then
            filterBoss = nil
            if filterDrop then filterDrop.SetByID(nil) end
        end

        for _, name in ipairs(names) do
            local skip = filterBoss and (getMeta(name).boss ~= filterBoss)
            if not skip then
                hasVisible = true
                local btn = CreateFrame("Button", nil, listChild)
                btn:SetSize(lScrollW, L_ROW_H)
                btn:SetPoint("TOPLEFT", listChild, "TOPLEFT", 0, -totalH)

                btn:SetHighlightTexture([[Interface\Buttons\UI-Listbox-Highlight2]])
                local hlt = btn:GetHighlightTexture()
                if hlt then hlt:SetBlendMode("ADD"); hlt:SetAlpha(0.22) end

                local isSel    = (name == selName)
                local isActive = (SolaryMDB and SolaryMDB.active_reminder == name)

                local sel = btn:CreateTexture(nil, "BACKGROUND")
                sel:SetPoint("LEFT",   btn, "LEFT",   2, 0)
                sel:SetPoint("RIGHT",  btn, "RIGHT",  0, 0)
                sel:SetPoint("TOP",    btn, "TOP",    0, 0)
                sel:SetPoint("BOTTOM", btn, "BOTTOM", 0, 0)
                sel:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.15)
                sel:SetAlpha(isSel and 1 or 0)

                local accent = btn:CreateTexture(nil, "ARTWORK")
                accent:SetWidth(2)
                accent:SetPoint("TOPLEFT",    btn, "TOPLEFT",    0, 0)
                accent:SetPoint("BOTTOMLEFT", btn, "BOTTOMLEFT", 0, 0)
                accent:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 1)
                if isSel then accent:Show() else accent:Hide() end

                local activeDot = btn:CreateTexture(nil, "OVERLAY")
                activeDot:SetSize(6, 6)
                activeDot:SetPoint("LEFT", btn, "LEFT", 6, 0)
                activeDot:SetColorTexture(0.2, 0.9, 0.2, 1)
                if isActive then activeDot:Show() else activeDot:Hide() end

                -- Icône rename (côté droit)
                local editBtn = CreateFrame("Button", nil, btn)
                editBtn:SetSize(16, 16)
                editBtn:SetPoint("RIGHT", btn, "RIGHT", -3, 0)
                local editIcon = editBtn:CreateTexture(nil, "ARTWORK")
                editIcon:SetAllPoints()
                editIcon:SetTexture([[Interface\GossipFrame\PetitionGossipIcon]])
                editIcon:SetTexCoord(0.05, 0.95, 0.05, 0.95)
                editIcon:SetVertexColor(SM.OR[1], SM.OR[2], SM.OR[3], 0.65)
                editBtn:SetHighlightTexture([[Interface\Buttons\UI-Listbox-Highlight2]])
                local eH = editBtn:GetHighlightTexture()
                if eH then eH:SetBlendMode("ADD"); eH:SetAlpha(0.5) end

                local lbl = btn:CreateFontString(nil, "OVERLAY")
                lbl:SetFont("Fonts\\ARIALN.TTF", 13, "")
                lbl:SetPoint("LEFT",  btn, "LEFT",  isActive and 16 or 10, 0)
                lbl:SetPoint("RIGHT", editBtn, "LEFT", -2, 0)
                lbl:SetJustifyH("LEFT"); lbl:SetJustifyV("MIDDLE")
                lbl:SetText(name)
                if isSel then
                    lbl:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
                elseif isActive then
                    lbl:SetTextColor(0.4, 0.9, 0.4, 1)
                else
                    lbl:SetTextColor(0.85, 0.85, 0.88, 1)
                end

                -- EditBox inline pour renommer
                local renameBox = CreateFrame("EditBox", nil, btn, "InputBoxTemplate")
                renameBox:SetPoint("LEFT",  btn,     "LEFT",  isActive and 16 or 8, 0)
                renameBox:SetPoint("RIGHT", editBtn, "LEFT",  -2, 0)
                renameBox:SetHeight(L_ROW_H - 8)
                renameBox:SetFont("Fonts\\ARIALN.TTF", 13, "")
                renameBox:SetAutoFocus(false)
                renameBox:Hide()
                renameBox:SetScript("OnEscapePressed", function(s) s:Hide(); lbl:Show() end)
                renameBox:SetScript("OnEditFocusLost", function(s) s:Hide(); lbl:Show() end)
                local rn = name
                renameBox:SetScript("OnEnterPressed", function(s)
                    local newName = s:GetText()
                    s:Hide()
                    if newName == "" or newName == rn or not SolaryMDB then lbl:Show(); return end
                    SolaryMDB.reminders = SolaryMDB.reminders or {}
                    SolaryMDB.reminders[newName] = SolaryMDB.reminders[rn]
                    SolaryMDB.reminders[rn] = nil
                    SolaryMDB.reminders_meta = SolaryMDB.reminders_meta or {}
                    SolaryMDB.reminders_meta[newName] = SolaryMDB.reminders_meta[rn]
                    SolaryMDB.reminders_meta[rn] = nil
                    if SolaryMDB.active_reminder == rn then SolaryMDB.active_reminder = newName end
                    if selName == rn then selName = newName; LoadNoteInEditor(newName) end
                    RefreshList()
                end)
                editBtn:SetScript("OnClick", function()
                    lbl:Hide()
                    renameBox:SetText(rn)
                    renameBox:Show()
                    renameBox:SetFocus()
                end)

                local cn = name
                btn:SetScript("OnClick", function() LoadNoteInEditor(cn) end)

                listRows[#listRows+1] = {btn=btn, sel=sel, accent=accent, lbl=lbl}
                totalH = totalH + L_ROW_H + L_ROW_GAP
            end
        end

        if not hasVisible and not listChild._emptyLbl then
            listChild._emptyLbl = listChild:CreateFontString(nil, "OVERLAY")
            listChild._emptyLbl:SetFont("Fonts\\ARIALN.TTF", 12, "")
            listChild._emptyLbl:SetPoint("TOPLEFT", listChild, "TOPLEFT", 8, -10)
            listChild._emptyLbl:SetTextColor(0.35, 0.35, 0.40, 1)
            listChild._emptyLbl:SetText(SM.T("rem_list_empty"))
        end
        if listChild._emptyLbl then
            listChild._emptyLbl:SetShown(not hasVisible)
        end

        listChild:SetHeight(math.max(totalH, 1))
        local sh = listScroll:GetHeight()
        local maxScroll = sh > 0 and math.max(0, totalH - sh) or 0
        listScrollBar:SetMinMaxValues(0, maxScroll)
        if listScrollBar:GetValue() > maxScroll then listScrollBar:SetValue(maxScroll) end

        if filterDrop then filterDrop.RefreshVisible(bossesWithNotes) end
    end

    -- Handlers boutons
    importBtn:SetScript("OnClick", function() importOverlay:Show() end)

    unloadBtn:SetScript("OnClick", function()
        if SolaryMDB then SolaryMDB.active_reminder = nil end
        RefreshList()
    end)

    delAllBtn:SetScript("OnClick", function()
        if not SolaryMDB then return end
        local count = 0
        if SolaryMDB.reminders then for _ in pairs(SolaryMDB.reminders) do count = count + 1 end end
        if count == 0 then return end
        ConfirmDel(SM.T("rem_confirm_del_all_fmt"):format(count), function()
            SolaryMDB.reminders      = {}
            SolaryMDB.reminders_meta = {}
            selName = nil
            noteEditor:SetText(""); noteNameInput:SetText(""); rNoSelLbl:Show()
            RefreshList()
        end)
    end)

    loadSendBtn:SetScript("OnClick", function()
        if not selName or not RN then return end
        -- Sauvegarde avant envoi
        if SolaryMDB then
            SolaryMDB.reminders = SolaryMDB.reminders or {}
            SolaryMDB.reminders[selName] = noteEditor:GetText()
        end
        RN.SetActive(selName)
        RN.BroadcastNote()
        RefreshList()
    end)

    saveBtn2:SetScript("OnClick", function()
        if not selName or not SolaryMDB then return end
        SolaryMDB.reminders = SolaryMDB.reminders or {}
        SolaryMDB.reminders[selName] = noteEditor:GetText()
    end)

    delBtn2:SetScript("OnClick", function()
        if not selName or not RN then return end
        local n = selName
        ConfirmDel(SM.T("rem_confirm_del_note"):format(n), function()
            RN.Delete(n)
            selName = nil
            noteEditor:SetText(""); noteNameInput:SetText(""); rNoSelLbl:Show()
            RefreshList()
        end)
    end)

    showBtn:SetScript("OnClick", function()
        if RN then RN.ToggleNote() end
    end)

    testBtn:SetScript("OnClick", function()
        if not RN then return end
        local ids = RN.GetEncounterIDs and RN.GetEncounterIDs() or {}
        local id  = ids[1] and tostring(ids[1]) or ""
        if id ~= "" then RN.TestEncounter(id) end
    end)

    stopBtn:SetScript("OnClick", function()
        if RN then RN.StopTest() end
    end)

    impConfirmBtn:SetScript("OnClick", function()
        if not RN then return end
        local name    = SM.GetVal(impNameInput)
        local content = impPasteBox:GetText()
        if name == "" or content == "" then return end
        local finalName = RN.Import(name, content)
        SM.SetVal(impNameInput, "")
        impPasteBox:SetText("")
        importOverlay:Hide()
        LoadNoteInEditor(finalName)
    end)

    f._refreshList = RefreshList
    f:SetScript("OnShow", RefreshList)

    activateShared()
    return f
end

-- ============================================================
-- FENÊTRE PRIVATE AURA SOUNDS
-- ============================================================
local paSoundsWindow = nil


local function Build()
    if mainFrame then return end

    -- ─── Frame principale (sans template) ─────────────────────
    mainFrame = CreateFrame("Frame","SolaryMPanel",UIParent)
    mainFrame:SetSize(TOTAL_W, PANEL_H)
    mainFrame:SetPoint("CENTER")
    mainFrame:SetMovable(true); mainFrame:EnableMouse(true)
    mainFrame:RegisterForDrag("LeftButton")
    mainFrame:SetScript("OnDragStart", mainFrame.StartMoving)
    mainFrame:SetScript("OnDragStop",  mainFrame.StopMovingOrSizing)
    mainFrame:SetFrameStrata("DIALOG")

    -- Fond principal
    local mainBg = mainFrame:CreateTexture(nil,"BACKGROUND")
    mainBg:SetAllPoints()
    mainBg:SetColorTexture(0.07, 0.06, 0.10, 1)

    -- Bordure 1px
    local bT = mainFrame:CreateTexture(nil,"BORDER")
    bT:SetPoint("TOPLEFT"); bT:SetPoint("TOPRIGHT"); bT:SetHeight(1)
    bT:SetColorTexture(0.22, 0.16, 0.32, 1)
    local bB = mainFrame:CreateTexture(nil,"BORDER")
    bB:SetPoint("BOTTOMLEFT"); bB:SetPoint("BOTTOMRIGHT"); bB:SetHeight(1)
    bB:SetColorTexture(0.22, 0.16, 0.32, 1)
    local bL = mainFrame:CreateTexture(nil,"BORDER")
    bL:SetPoint("TOPLEFT"); bL:SetPoint("BOTTOMLEFT"); bL:SetWidth(1)
    bL:SetColorTexture(0.22, 0.16, 0.32, 1)
    local bR = mainFrame:CreateTexture(nil,"BORDER")
    bR:SetPoint("TOPRIGHT"); bR:SetPoint("BOTTOMRIGHT"); bR:SetWidth(1)
    bR:SetColorTexture(0.22, 0.16, 0.32, 1)

    -- ─── Header ───────────────────────────────────────────────
    local header = CreateFrame("Frame", nil, mainFrame)
    header:SetPoint("TOPLEFT",  mainFrame, "TOPLEFT",  0, 0)
    header:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", 0, 0)
    header:SetHeight(HEADER_H)
    header:EnableMouse(true)
    header:RegisterForDrag("LeftButton")
    header:SetScript("OnDragStart", function() mainFrame:StartMoving() end)
    header:SetScript("OnDragStop",  function() mainFrame:StopMovingOrSizing() end)

    local headerBg = header:CreateTexture(nil,"BACKGROUND")
    headerBg:SetAllPoints()
    headerBg:SetColorTexture(0.04, 0.04, 0.08, 1)

    -- Ligne séparatrice sous le header
    local headerLine = mainFrame:CreateTexture(nil,"ARTWORK")
    headerLine:SetPoint("TOPLEFT",  mainFrame, "TOPLEFT",  0, -HEADER_H)
    headerLine:SetPoint("TOPRIGHT", mainFrame, "TOPRIGHT", 0, -HEADER_H)
    headerLine:SetHeight(1)
    headerLine:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.35)

    -- Icône logo dans le header
    local logoIcon = header:CreateTexture(nil,"OVERLAY")
    logoIcon:SetSize(28, 28)
    logoIcon:SetPoint("LEFT", header, "LEFT", 8, 0)
    logoIcon:SetTexture("Interface\\AddOns\\SolaryM\\Media\\solary_icon.png")

    -- SOLARYM + sous-titre dans le header
    local logoText = header:CreateFontString(nil,"OVERLAY","GameFontNormalLarge")
    logoText:SetPoint("LEFT", header, "LEFT", 42, 5)
    logoText:SetTextColor(0.72, 0.55, 0.95, 1)
    logoText:SetText("SOLARY|cFFDD88FFM|r")

    local subText = header:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    subText:SetPoint("LEFT", header, "LEFT", 44, -10)
    subText:SetTextColor(0.52, 0.42, 0.68, 1)
    subText:SetText("Mythic Tools")

    -- Bouton langue FR/EN
    local langBtn = CreateFrame("Button", nil, header)
    langBtn:SetSize(38, 20)
    langBtn:SetPoint("TOPRIGHT", header, "TOPRIGHT", -46, -10)
    local langBg = langBtn:CreateTexture(nil,"BACKGROUND")
    langBg:SetAllPoints(); langBg:SetColorTexture(0.10, 0.11, 0.18, 1)
    local langBdr = langBtn:CreateTexture(nil,"BORDER")
    langBdr:SetAllPoints(); langBdr:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.40)
    local langLbl = langBtn:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
    langLbl:SetPoint("CENTER"); langLbl:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
    langLbl:SetText(SM.LANG == "fr" and "FR" or "EN")
    langBtn:SetScript("OnClick", function()
        SM.SetLang(SM.LANG == "fr" and "en" or "fr")
        local point, _, relPoint, x, y = mainFrame:GetPoint()
        local prevTab = activeTab
        mainFrame:Hide()
        mainFrame = nil
        wipe(tabBtns)
        wipe(tabFrames)
        Build()
        if point then
            mainFrame:ClearAllPoints()
            mainFrame:SetPoint(point, UIParent, relPoint, x, y)
        end
        ShowTab(prevTab <= #tabFrames and prevTab or 1)
        if SM.IsEditor() and prevTab == 1 then SM.RefreshSpellList() end
        mainFrame:Show()
        tinsert(UISpecialFrames, "SolaryMPanel")
    end)
    langBtn:SetScript("OnEnter", function() langBdr:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 1) end)
    langBtn:SetScript("OnLeave", function() langBdr:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.40) end)

    -- Bouton fermer
    local closeBtn = CreateFrame("Button", nil, header)
    closeBtn:SetSize(24, 24)
    closeBtn:SetPoint("TOPRIGHT", header, "TOPRIGHT", -8, -8)
    local closeBg = closeBtn:CreateTexture(nil,"BACKGROUND")
    closeBg:SetAllPoints(); closeBg:SetColorTexture(0.32, 0.07, 0.07, 0.85)
    local closeLbl = closeBtn:CreateFontString(nil,"OVERLAY","GameFontNormal")
    closeLbl:SetPoint("CENTER"); closeLbl:SetTextColor(0.90, 0.90, 0.90, 1)
    closeLbl:SetText("\195\151")
    closeBtn:SetScript("OnClick",  function() mainFrame:Hide() end)
    closeBtn:SetScript("OnEnter", function() closeBg:SetColorTexture(0.65, 0.12, 0.12, 1) end)
    closeBtn:SetScript("OnLeave", function() closeBg:SetColorTexture(0.32, 0.07, 0.07, 0.85) end)

    -- ─── Sidebar gauche ──────────────────────────────────────
    local sidebar = CreateFrame("Frame", nil, mainFrame)
    sidebar:SetPoint("TOPLEFT",    mainFrame, "TOPLEFT",    0, -HEADER_H)
    sidebar:SetPoint("BOTTOMLEFT", mainFrame, "BOTTOMLEFT", 0,  0)
    sidebar:SetWidth(SIDEBAR_W)

    local sidebarBg = sidebar:CreateTexture(nil,"BACKGROUND")
    sidebarBg:SetAllPoints()
    sidebarBg:SetColorTexture(0.05, 0.05, 0.09, 1)

    -- Ligne de séparation sidebar / contenu
    local sideDiv = mainFrame:CreateTexture(nil,"ARTWORK")
    sideDiv:SetPoint("TOPLEFT",    mainFrame, "TOPLEFT",    SIDEBAR_W, -HEADER_H)
    sideDiv:SetPoint("BOTTOMLEFT", mainFrame, "BOTTOMLEFT", SIDEBAR_W,  0)
    sideDiv:SetWidth(1)
    sideDiv:SetColorTexture(0.20, 0.14, 0.28, 1)

    -- Version en bas de la sidebar
    local sideVer = sidebar:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
    sideVer:SetPoint("BOTTOMLEFT", sidebar, "BOTTOMLEFT", 12, 10)
    sideVer:SetTextColor(0.38, 0.34, 0.50, 1)
    sideVer:SetText("v"..SM.VERSION)

    -- ─── Onglets verticaux ────────────────────────────────────
    local tabNames
    if SM.IsEditor() then
        tabNames = {SM.T("tab_spells"),SM.T("tab_smartcast"),SM.T("tab_invites"),SM.T("tab_memory"),SM.T("tab_versions"),SM.T("tab_settings"),SM.T("tab_changelogs"),SM.T("tab_reminders")}
    else
        tabNames = {SM.T("tab_smartcast"),SM.T("tab_settings"),SM.T("tab_changelogs"),SM.T("tab_reminders")}
    end
    local TAB_BTN_H = 40
    local TAB_BTN_W = SIDEBAR_W

    local function MakeSideTab(idx, name, yOff)
        local tb = CreateFrame("Button", nil, sidebar)
        tb:SetSize(TAB_BTN_W, TAB_BTN_H)
        tb:SetPoint("TOPLEFT", sidebar, "TOPLEFT", 0, yOff)

        local bg = tb:CreateTexture(nil,"BACKGROUND")
        bg:SetAllPoints(); bg:SetColorTexture(0, 0, 0, 0)
        tb._bg = bg

        local accent = tb:CreateTexture(nil,"ARTWORK")
        accent:SetSize(2, TAB_BTN_H - 4)
        accent:SetPoint("LEFT", tb, "LEFT", 0, 0)
        accent:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 1)
        accent:Hide()
        tb._accent = accent

        local lbl = tb:CreateFontString(nil,"OVERLAY","GameFontNormal")
        lbl:SetPoint("LEFT", tb, "LEFT", 18, 0)
        lbl:SetJustifyH("LEFT")
        lbl:SetTextColor(0.55, 0.55, 0.58, 1)
        lbl:SetText(name)
        tb._lbl = lbl

        tb:SetScript("OnEnter", function(s)
            if activeTab ~= idx then
                s._bg:SetColorTexture(0.10, 0.07, 0.16, 1)
                s._lbl:SetTextColor(0.82, 0.75, 0.95, 1)
            end
        end)
        tb:SetScript("OnLeave", function(s)
            if activeTab ~= idx then
                s._bg:SetColorTexture(0, 0, 0, 0)
                s._lbl:SetTextColor(0.55, 0.50, 0.62, 1)
            end
        end)

        local i = idx
        tb:SetScript("OnClick", function() ShowTab(i) end)
        table.insert(tabBtns, tb)
    end

    local startY = -8
    for i, name in ipairs(tabNames) do
        MakeSideTab(i, name, startY - (i-1) * (TAB_BTN_H + 1))
    end

    -- ─── Contenu des onglets ─────────────────────────────────
    if SM.IsEditor() then
        tabFrames[1] = BuildSpellsTab(mainFrame)
        SM._spellTabFrame = tabFrames[1]
        tabFrames[2] = BuildBossTimerTab(mainFrame)
        tabFrames[3] = BuildInviteTab(mainFrame)
        tabFrames[4] = BuildMemoryTab(mainFrame)
        tabFrames[5] = BuildVersionTab(mainFrame)
        tabFrames[6] = BuildSettingsTab(mainFrame)
        tabFrames[7] = BuildChangelogsTab(mainFrame)
        tabFrames[8] = BuildRemindersTab(mainFrame)
    else
        tabFrames[1] = BuildBossTimerTab(mainFrame)
        tabFrames[2] = BuildSettingsTab(mainFrame)
        tabFrames[3] = BuildChangelogsTab(mainFrame)
        tabFrames[4] = BuildRemindersTab(mainFrame)
    end
    mainFrame:EnableKeyboard(true)
    mainFrame:SetPropagateKeyboardInput(true)
    mainFrame:SetScript("OnKeyDown", function(self, key)
        if key == "ESCAPE" then
            self:SetPropagateKeyboardInput(false)
            self:Hide()
        else
            self:SetPropagateKeyboardInput(true)
        end
    end)
    mainFrame:Hide()
end

-- Une seule insertion dans UISpecialFrames — permet Échap pour fermer
tinsert(UISpecialFrames, "SolaryMPanel")

function SM.TogglePanel()
    Build()
    if mainFrame:IsShown() then
        mainFrame:Hide()
    else
        SolaryMDB=SolaryMDB or {}
        if SM.IsEditor() then
            ShowTab(1)
            SM.RefreshSpellList()
        else
            ShowTab(1)  -- Boss Timers est tab 1 pour non-éditeurs
        end
        mainFrame:Show()
    end
end

-- SM.OpenPanel = alias pour SM.TogglePanel (appelé par Core)
-- Met à jour le label "N changements en attente" dans l'onglet Spells
function SM._UpdatePendingCount()
    local f = SM._spellTabFrame
    if not f or not f._pendingLbl then return end
    local n = 0
    for _ in pairs(SM.PendingSpellChanges) do n = n + 1 end
    if n == 0 then
        f._pendingLbl:SetText(SM.T("pending_none"))
        f._pendingLbl:SetTextColor(0.5, 0.5, 0.5, 1)
    elseif n == 1 then
        f._pendingLbl:SetText("|cFFFFAA00"..SM.T("pending_one").."|r — "..SM.T("pending_ready"))
        f._pendingLbl:SetTextColor(1, 0.82, 0, 1)
    else
        f._pendingLbl:SetText("|cFFFFAA00"..n.." "..SM.T("pending_multi").."|r — "..SM.T("pending_ready_pl"))
        f._pendingLbl:SetTextColor(1, 0.82, 0, 1)
    end
end

SM.OpenPanel = SM.TogglePanel


-- ============================================================
-- ONGLET CHANGELOGS
-- ============================================================

function SM.OpenPASoundsWindow()
    if paSoundsWindow then
        if paSoundsWindow:IsShown() then paSoundsWindow:Hide() else paSoundsWindow:Show() end
        return
    end

    local W, H = 500, 560
    paSoundsWindow = CreateFrame("Frame", "SolaryMPASoundsWindow", UIParent, "BackdropTemplate")
    paSoundsWindow:SetSize(W, H)
    paSoundsWindow:SetPoint("CENTER", UIParent, "CENTER", 200, 0)
    paSoundsWindow:SetFrameStrata("DIALOG")
    paSoundsWindow:SetMovable(true)
    paSoundsWindow:EnableMouse(true)
    paSoundsWindow:RegisterForDrag("LeftButton")
    paSoundsWindow:SetScript("OnDragStart", paSoundsWindow.StartMoving)
    paSoundsWindow:SetScript("OnDragStop", paSoundsWindow.StopMovingOrSizing)
    paSoundsWindow:SetBackdrop({bgFile="Interface\Buttons\WHITE8X8", edgeFile="Interface\Buttons\WHITE8X8", edgeSize=1})
    paSoundsWindow:SetBackdropColor(0.06,0.06,0.09,0.98)
    paSoundsWindow:SetBackdropBorderColor(SM.OR[1],SM.OR[2],SM.OR[3],0.5)

    -- Titre
    local title = paSoundsWindow:CreateFontString(nil,"OVERLAY","GameFontNormal")
    title:SetPoint("TOP",paSoundsWindow,"TOP",0,-10)
    title:SetTextColor(SM.OR[1],SM.OR[2],SM.OR[3],1)
    title:SetText("Sons Private Auras")

    -- Bouton fermer
    SM.RBtn(paSoundsWindow,60,22,SM.T("btn_close"),function() paSoundsWindow:Hide() end):SetPoint("TOPRIGHT",paSoundsWindow,"TOPRIGHT",-8,-6)

    -- Background complet (titre + liste + barre ajout)
    local fullBg=paSoundsWindow:CreateTexture(nil,"BACKGROUND")
    fullBg:SetPoint("TOPLEFT",paSoundsWindow,"TOPLEFT",1,-1)
    fullBg:SetPoint("BOTTOMRIGHT",paSoundsWindow,"BOTTOMRIGHT",-1,1)
    fullBg:SetColorTexture(0.06,0.06,0.09,1)

    -- Background zone liste (légèrement différent)
    local listBg=paSoundsWindow:CreateTexture(nil,"BACKGROUND")
    listBg:SetPoint("TOPLEFT",paSoundsWindow,"TOPLEFT",8,-28)
    listBg:SetPoint("BOTTOMRIGHT",paSoundsWindow,"BOTTOMRIGHT",-8,88)
    listBg:SetColorTexture(0.04,0.04,0.07,1)

    -- Headers
    local function Hdr(txt,x)
        local h=paSoundsWindow:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
        h:SetPoint("TOPLEFT",paSoundsWindow,"TOPLEFT",x,-32)
        h:SetTextColor(0.35,0.35,0.4,1); h:SetText(txt)
    end
    Hdr(SM.T("col_spell"),12); Hdr("SPELLID",230); Hdr(SM.T("col_sound"),310)

    local sep=paSoundsWindow:CreateTexture(nil,"ARTWORK"); sep:SetSize(W-16,1)
    sep:SetPoint("TOPLEFT",paSoundsWindow,"TOPLEFT",8,-44)
    sep:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.3)

    -- Scroll list
    local scroll=CreateFrame("ScrollFrame",nil,paSoundsWindow,"UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT",paSoundsWindow,"TOPLEFT",8,-50)
    scroll:SetPoint("BOTTOMRIGHT",paSoundsWindow,"BOTTOMRIGHT",-28,90)
    local scrollContent=CreateFrame("Frame",nil,scroll)
    scrollContent:SetSize(W-36,1)
    scroll:SetScrollChild(scrollContent)

    local function MakeDropdown(parent, x, y, w, getVal, onSelect)
        local btn=CreateFrame("Button",nil,parent)
        btn:SetSize(w,22); btn:SetPoint("TOPLEFT",parent,"TOPLEFT",x,y)
        local bg=btn:CreateTexture(nil,"BACKGROUND"); bg:SetAllPoints(); bg:SetColorTexture(0.1,0.1,0.14,1)
        local bdr=btn:CreateTexture(nil,"BORDER"); bdr:SetAllPoints(); bdr:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.2)
        local lbl=btn:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
        lbl:SetPoint("LEFT",btn,"LEFT",6,0); lbl:SetText(getVal()); lbl:SetTextColor(0.9,0.9,0.9,1)
        local arr=btn:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
        arr:SetPoint("RIGHT",btn,"RIGHT",-4,0); arr:SetText("v")

        local menu=CreateFrame("Frame",nil,paSoundsWindow); menu:SetFrameStrata("TOOLTIP")
        menu:SetSize(w,22); menu:SetPoint("TOPLEFT",btn,"BOTTOMLEFT",0,-2)
        local mbg=menu:CreateTexture(nil,"BACKGROUND"); mbg:SetAllPoints(); mbg:SetColorTexture(0.06,0.06,0.09,0.98)
        menu:Hide()

        btn:SetScript("OnClick",function()
            if menu:IsShown() then menu:Hide(); return end
            for _,c in ipairs({menu:GetChildren()}) do c:Hide() end
            local sounds={"(aucun)"}
            for _, s in ipairs(SM.MediaSounds or {}) do table.insert(sounds, s) end
            menu:SetHeight(#sounds*22)
            for i,sname in ipairs(sounds) do
                local item=CreateFrame("Button",nil,menu)
                item:SetSize(w,22); item:SetPoint("TOPLEFT",menu,"TOPLEFT",0,-(i-1)*22)
                local ibg=item:CreateTexture(nil,"BACKGROUND"); ibg:SetAllPoints(); ibg:SetColorTexture(0,0,0,0)
                local ilbl=item:CreateFontString(nil,"OVERLAY","GameFontHighlightSmall")
                ilbl:SetPoint("LEFT",item,"LEFT",6,0); ilbl:SetText(sname); ilbl:SetTextColor(0.85,0.85,0.9,1)
                item:SetScript("OnEnter",function() ibg:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.2) end)
                item:SetScript("OnLeave",function() ibg:SetColorTexture(0,0,0,0) end)
                local sn=sname
                item:SetScript("OnClick",function() lbl:SetText(sn); onSelect(sn); menu:Hide() end)
            end
            menu:Show()
        end)
        return btn, lbl
    end

    local function RefreshList()
        for _,c in ipairs({scrollContent:GetChildren()}) do c:Hide() end
        SolaryMDB.pa_sounds = SolaryMDB.pa_sounds or {}

        -- Construire liste combinée : defaults + custom
        local rows = {}
        if SolaryMDB.pa_use_defaults ~= false then
            for id, snd in pairs(SM.PA_DEFAULTS_RAID) do
                local custom = SolaryMDB.pa_sounds[id]
                rows[id] = {sound=custom or snd, isDefault=(custom==nil), isCustom=(custom~=nil)}
            end
        end
        for id, snd in pairs(SolaryMDB.pa_sounds) do
            if not rows[id] then rows[id]={sound=snd, isDefault=false, isCustom=true} end
        end

        -- Trier par nom de sort
        local sorted = {}
        for id, info in pairs(rows) do
            local si = C_Spell.GetSpellInfo(id)
            table.insert(sorted, {id=id, name=(si and si.name or "SpellID "..id), sound=info.sound, isDefault=info.isDefault, isCustom=info.isCustom})
        end
        table.sort(sorted, function(a,b) return a.name < b.name end)

        local ry = 0
        local ROW_H = 26
        for i, entry in ipairs(sorted) do
            local row=CreateFrame("Frame",nil,scrollContent)
            row:SetSize(W-36,ROW_H); row:SetPoint("TOPLEFT",scrollContent,"TOPLEFT",0,-ry)
            local rb=row:CreateTexture(nil,"BACKGROUND"); rb:SetAllPoints()
            if i%2==0 then rb:SetColorTexture(0.09,0.09,0.12,1) else rb:SetColorTexture(0.06,0.06,0.09,1) end

            -- Nom du sort
            local nl=row:CreateFontString(nil,"OVERLAY","GameFontNormalSmall")
            nl:SetPoint("LEFT",row,"LEFT",4,0); nl:SetWidth(218)
            nl:SetJustifyH("LEFT")
            -- Truncate name to avoid overflow
            local dispName = entry.name
            nl:SetText(dispName)
            nl:SetTextColor(entry.isDefault and 0.5 or 0.9, entry.isDefault and 0.5 or 0.9, entry.isDefault and 0.55 or 0.9, 1)

            -- SpellID
            local il=row:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
            il:SetPoint("LEFT",row,"LEFT",222,0)
            il:SetText(tostring(entry.id)); il:SetTextColor(0.35,0.35,0.4,1)

            -- Dropdown son
            local eid = entry.id
            local _, sndLbl = MakeDropdown(row, 300, -2, 130, function() return entry.sound end, function(sn)
                SolaryMDB.pa_sounds[eid] = sn
                SM.RegisterPASound(eid, sn)
                RefreshList()
            end)
            sndLbl:SetText(entry.sound)

            -- Bouton supprimer (custom seulement)
            if entry.isCustom or not entry.isDefault then
                SM.RBtn(row,22,20,"x",function()
                    SolaryMDB.pa_sounds[eid]=nil
                    SM.RegisterPASound(eid,nil)
                    RefreshList()
                end):SetPoint("RIGHT",row,"RIGHT",-2,0)
            end

            ry = ry + ROW_H
        end

        if #sorted == 0 then
            local el=scrollContent:CreateFontString(nil,"OVERLAY","GameFontDisableSmall")
            el:SetPoint("TOPLEFT",scrollContent,"TOPLEFT",4,0)
            el:SetTextColor(0.4,0.4,0.45,1); el:SetText(SM.T("pa_empty"))
        end

        scrollContent:SetHeight(math.max(ry,22))
    end

    -- Barre d'ajout — ancrée en bas de la fenêtre
    local addBar=CreateFrame("Frame",nil,paSoundsWindow)
    addBar:SetSize(W-16,32); addBar:SetPoint("BOTTOMLEFT",paSoundsWindow,"BOTTOMLEFT",8,52)

    local addId=SM.Input(addBar,90,24,"SpellID")
    addId:SetPoint("LEFT",addBar,"LEFT",0,0)

    local addSndSel = (SM.MediaSounds and SM.MediaSounds[1]) or "Soak"
    local _, addSndLbl = MakeDropdown(addBar, 96, -3, 150, function() return addSndSel end, function(sn)
        addSndSel = sn
    end)

    SM.GBtn(addBar,60,24,"Add",function()
        local id=tonumber(SM.GetVal(addId))
        if not id then SM.Print(SM.T("invalid_spellid")); return end
        SolaryMDB.pa_sounds=SolaryMDB.pa_sounds or {}
        SolaryMDB.pa_sounds[id]=addSndSel
        SM.RegisterPASound(id,addSndSel)
        SM.SetVal(addId,"")
        RefreshList()
    end):SetPoint("LEFT",addBar,"LEFT",252,0)

    SM.RBtn(addBar,100,24,SM.T("btn_delete_all"),function()
        SolaryMDB.pa_sounds={}
        SM.PASoundIDs={}
        RefreshList()
    end):SetPoint("RIGHT",addBar,"RIGHT",-4,0)

    local sep2=paSoundsWindow:CreateTexture(nil,"ARTWORK"); sep2:SetSize(W-16,1)
    sep2:SetPoint("BOTTOMLEFT",paSoundsWindow,"BOTTOMLEFT",8,86)
    sep2:SetColorTexture(SM.OR[1],SM.OR[2],SM.OR[3],0.3)

    RefreshList()
    paSoundsWindow:Show()
end
