-- SolaryM_BossTimer.lua — Timers boss via COMBAT_LOG (standalone ou BigWigs/DBM)

SM.BossTimer = SM.BossTimer or {}
local BT = SM.BossTimer

-- ============================================================
-- ÉTAT
-- ============================================================
local currentEncounterID  = nil
local bwBarBuffer = {}  -- bars reçues avant ENCOUNTER_START
local currentEncounterName = nil
local activeTimers  = {}   -- { [spellID] = { ticker, nextFireAt, count } }
local pendingAlerts = {}   -- { C_Timer handle, ... }
local pullTime      = nil  -- GetTime() au moment du pull
local bwHandle      = {}

-- ============================================================
-- HELPERS
-- ============================================================
local function CancelAll()
    for _, t in pairs(activeTimers) do
        if t.ticker and not t.ticker:IsCancelled() then t.ticker:Cancel() end
    end
    activeTimers = {}
    for _, t in ipairs(pendingAlerts) do
        if t and not t:IsCancelled() then t:Cancel() end
    end
    pendingAlerts = {}
    pullTime = nil
end

-- Calcule le prochain temps de cast depuis maintenant
-- cdSeries est soit un nombre (cooldown fixe) soit une table {cd1, cd2, ...}
local function NextCastTime(first, cd, count)
    if not first then return nil end
    if count == 0 then return first end
    if not cd then return nil end

    if type(cd) == "number" then
        return first + cd * count
    elseif type(cd) == "table" then
        local t = first
        for i = 1, count do
            local idx = ((i - 1) % #cd) + 1
            t = t + cd[idx]
        end
        return t
    end
    return nil
end

-- ============================================================
-- DÉCLENCHEMENT D'UNE ALERTE
-- ============================================================
local function FireAlert(entry, timeUntil)
    -- Lire le callout depuis SolaryMDB.spells si disponible (permet le broadcast éditeur)
    local callout = SolaryMDB.spells and SolaryMDB.spells[entry.id]
    if not callout or callout == "" then
        callout = (SM.LANG == "fr") and entry.fr or entry.en
    end

    if SolaryMDB.boss_timers and SolaryMDB.boss_timers.sounds ~= false then
        SM.PlaySoundForCallout(callout)
    end

    if callout and callout ~= "" then
        local mechName = entry.en  -- nom technique toujours en EN pour le sous-titre
        local duration = SolaryMDB.boss_timers and SolaryMDB.boss_timers.prealert_sec or 5
        if SM.ShowTimedAlert then
            SM.ShowTimedAlert(callout, entry and entry.id, duration)
        end

    end

    if SM.IsEditor() and SolaryMDB.boss_timers and SolaryMDB.boss_timers.raid_warn then
        local msg = string.format("[SolaryM] %s — %.0fs",
            callout,
            timeUntil or 0)
        if IsInRaid() then
            -- Defer to next frame to avoid combat taint
            C_Timer.NewTimer(0, function()
                if IsInRaid() then SendChatMessage(msg, "RAID_WARNING") end
            end)
        end
    end
end

-- ============================================================
-- PLANIFIER LES TIMERS POUR UN BOSS
-- Appelé à ENCOUNTER_START
-- ============================================================
local function ScheduleBossTimers(encounterID)
    local spells = SM.GetBossSpells(encounterID)

    local prealert = (SolaryMDB.boss_timers and SolaryMDB.boss_timers.prealert_sec) or 5

    for _, entry in ipairs(spells) do
        if entry.first and entry.first > 0 then

                local delay = entry.first - prealert
            if delay > 0 then
                local t = C_Timer.NewTimer(delay, function()
                    FireAlert(entry, prealert)
                end)
                table.insert(pendingAlerts, t)
            elseif delay <= 0 and entry.first > 0 then
                        local t = C_Timer.NewTimer(0.1, function()
                    FireAlert(entry, entry.first)
                end)
                table.insert(pendingAlerts, t)
            end

                    if entry.cd then
                local count = 1
                local maxCasts = 30  -- sécurité anti-boucle infinie
                local nextTime = NextCastTime(entry.first, entry.cd, count)

                while nextTime and nextTime < 600 and count <= maxCasts do
                    local fireAt = nextTime - prealert
                    if fireAt > 0 then
                        local captured_entry = entry
                        local captured_next = nextTime
                        local t = C_Timer.NewTimer(fireAt, function()
                                                    if currentEncounterID ~= encounterID then return end
                            FireAlert(captured_entry, prealert)
                        end)
                        table.insert(pendingAlerts, t)
                    end
                    count = count + 1
                    nextTime = NextCastTime(entry.first, entry.cd, count)
                end

            end
        end
    end
end

-- ============================================================
-- RESYNCHRO sur cast réel (COMBAT_LOG)
-- Si on voit le boss caster un sort connu, on recalibre
-- ============================================================
local lastSeenCast = {}  -- [spellID] = GetTime()

local function OnRealCast(spellID, castType)
    local entry = SM.GetSpellEntry(spellID)
    if not entry then return end

    local now = GetTime()
    if lastSeenCast[spellID] and (now - lastSeenCast[spellID]) < 2 then return end
    lastSeenCast[spellID] = now

    -- Callout custom ou défaut DB
    local callout = SolaryMDB.spells and SolaryMDB.spells[spellID]
    if not callout or callout == "" then
        callout = (SM.LANG == "fr") and entry.fr or entry.en
    end

    if callout and callout ~= "" then
        if SM.ShowTimedAlert then
            SM.ShowTimedAlert(callout, entry and entry.id, 3)
        end
        SM.PlaySoundForCallout(callout)
    end

end

-- ============================================================
-- FRAME PRINCIPALE — EVENTS WoW
-- RegisterEvent appelé dans PLAYER_LOGIN pour éviter ADDON_ACTION_FORBIDDEN
-- ============================================================
local frame = CreateFrame("Frame")  -- pas de nom global = pas de protection

frame:SetScript("OnEvent", function(self, event, ...)
    -- ── ENCOUNTER_START ──────────────────────────────────────
    if event == "ENCOUNTER_START" then
        local encID, encName, diff, groupSize = ...

        -- Ne pas se déclencher si désactivé
        if SolaryMDB.boss_timers and SolaryMDB.boss_timers.enabled == false then
            return
        end

        CancelAll()
        currentEncounterID   = encID
        currentEncounterName = encName
        pullTime = GetTime()
        lastSeenCast = {}

        local spells = SM.GetBossSpells and SM.GetBossSpells(encID) or {}
        if #spells == 0 then
            return
        end

        SM.Print(string.format("Boss Timer actif — |cffFFAA00%s|r (%d sorts)", encName or "?", #spells))
        ScheduleBossTimers(encID)

        -- Rejouer les barres BW reçues avant ENCOUNTER_START
        if #bwBarBuffer > 0 then
            local now = GetTime()
            for _, bar in ipairs(bwBarBuffer) do
                local elapsed = now - bar.t
                local adjustedTime = (bar.barTime or 0) - elapsed
                if adjustedTime > 0 then
                    ProcessBWBar(bar.key, bar.barText, adjustedTime)
                end
            end
            wipe(bwBarBuffer)
        end

    -- ── ENCOUNTER_END ────────────────────────────────────────
    elseif event == "ENCOUNTER_END" then
        local encID, encName, diff, groupSize, success = ...
        CancelAll()
        currentEncounterID   = nil
        wipe(bwBarBuffer)
        currentEncounterName = nil
        lastSeenCast = {}

    -- ── PLAYER_REGEN_ENABLED (hors encounter) ────────────────
    elseif event == "PLAYER_REGEN_ENABLED" then
        if currentEncounterID then return end  -- en cours d'encounter → pas de reset
        CancelAll()
        lastSeenCast = {}

    -- ── COMBAT_LOG ───────────────────────────────────────────
    elseif event == "COMBAT_LOG_EVENT_UNFILTERED" then
        -- Pas de gate sur currentEncounterID : fonctionne aussi en M+
        local _, subevent, _, srcGUID, srcName, srcFlags, _,
              dstGUID, dstName, _, _, spellID = CombatLogGetCurrentEventInfo()

        if not srcFlags or not spellID then return end
        if bit.band(srcFlags, 0x800) == 0 then return end  -- pas un NPC
        if bit.band(srcFlags, 0x40)  == 0 then return end  -- pas hostile

        if subevent == "SPELL_CAST_START" or subevent == "SPELL_CAST_SUCCESS" then
            if SM.SpellIndex and SM.SpellIndex[spellID] then
                local castType = (subevent == "SPELL_CAST_START") and "begincast" or "cast"
                if currentEncounterID then
                    OnRealCast(spellID, castType)
                else
                    -- Hors encounter (M+) : alerte + son
                    local entry = SM.GetSpellEntry(spellID)
                    if entry then
                        local callout = SolaryMDB.spells and SolaryMDB.spells[spellID]
                        if not callout or callout == "" then
                            callout = (SM.LANG == "fr") and entry.fr or entry.en
                        end
                        SM.PlaySoundForCallout(callout)
                        if SM.ShowTimedAlert then SM.ShowTimedAlert(callout, entry and entry.id, 3) end
                    end
                end
            end
        end

        if subevent == "SPELL_AURA_APPLIED" and dstGUID == UnitGUID("player") then
            if SM.SpellIndex and SM.SpellIndex[spellID] then
                if currentEncounterID then OnRealCast(spellID, "aura") end
            end
        end
    end
end)


-- ============================================================
-- HOOK BIGWIGS (optionnel — pour les Private Auras Midnight)
-- BigWigs gère nativement les private auras que le log ne voit pas
-- On se branche dessus si présent
-- ============================================================

local function ProcessBWBar(key, barText, barTime)
    if not currentEncounterID then return end
    local spellId = nil
    if type(key) == "number" then spellId = key end
    if not spellId and barText then
        local ok, r = pcall(function() return SM.NameToSpellId and SM.NameToSpellId[barText:lower()] end)
        if ok then spellId = r end
    end
    if spellId and SM.SpellIndex and SM.SpellIndex[spellId] then
        local entry = SM.SpellIndex[spellId]
        local prealert = (SolaryMDB.boss_timers and SolaryMDB.boss_timers.prealert_sec) or 5
        local threshold = prealert
        if barTime and barTime > threshold then
            local t = C_Timer.NewTimer(barTime - threshold, function()
                if currentEncounterID then FireAlert(entry, threshold) end
            end)
            table.insert(pendingAlerts, t)
        elseif barTime then
            FireAlert(entry, barTime)
        end
    end
end

local function OnBWBar(_, module, key, barText, barTime)
    if not currentEncounterID then
        -- Bufferer la barre — l'encounter n'a pas encore commencé
        table.insert(bwBarBuffer, {key=key, barText=barText, barTime=barTime, t=GetTime()})
        return
    end

    ProcessBWBar(key, barText, barTime)
end

-- ============================================================
-- HOOK DBM (optionnel)
-- ============================================================
local dbmFrame = CreateFrame("Frame")
dbmFrame:SetScript("OnEvent", function(_, event, id, timeLeft, timerType, spellId, dbmType, spellName)
    if not currentEncounterID then return end
    if event == "DBM_TimerStart" and spellId and SM.SpellIndex and SM.SpellIndex[spellId] then
        local entry = SM.SpellIndex[spellId]
        local prealert = (SolaryMDB.boss_timers and SolaryMDB.boss_timers.prealert_sec) or 5
        if timeLeft and timeLeft > prealert then
            local t = C_Timer.NewTimer(timeLeft - prealert, function()
                if currentEncounterID then FireAlert(entry, prealert) end
            end)
            table.insert(pendingAlerts, t)
        elseif timeLeft then
            FireAlert(entry, timeLeft)
        end
    end
end)

-- ============================================================
-- INIT
-- ============================================================
local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("PLAYER_LOGIN")
initFrame:SetScript("OnEvent", function(self, event)
    if event ~= "PLAYER_LOGIN" then return end
    frame:RegisterEvent("ENCOUNTER_START")
    frame:RegisterEvent("ENCOUNTER_END")
    frame:RegisterEvent("PLAYER_REGEN_ENABLED")


    SolaryMDB.boss_timers = SolaryMDB.boss_timers or {}
    if SolaryMDB.boss_timers.enabled == nil then SolaryMDB.boss_timers.enabled = true end
    if SolaryMDB.boss_timers.prealert_sec == nil then SolaryMDB.boss_timers.prealert_sec = 5 end
    if SolaryMDB.boss_timers.sounds == nil then SolaryMDB.boss_timers.sounds = true end
    if SolaryMDB.boss_timers.raid_warn == nil then SolaryMDB.boss_timers.raid_warn = false end


    if BigWigsLoader then
        BigWigsLoader.RegisterMessage(bwHandle, "BigWigs_StartBar",     OnBWBar)
        BigWigsLoader.RegisterMessage(bwHandle, "BigWigs_OnBossWipe",   function()
        end)
    end

    if DBM then
        dbmFrame:RegisterEvent("DBM_TimerStart")
    end

end)

-- ============================================================
-- FONCTIONS PUBLIQUES
-- ============================================================
function BT.Reset()
    CancelAll()
    currentEncounterID = nil
    currentEncounterName = nil
end

function BT.GetCurrentBoss()
    return currentEncounterID, currentEncounterName
end

function BT.IsActive()
    return currentEncounterID ~= nil
end

-- Test : simule un encounter pour tester les timers
function BT.TestEncounter(encounterID)
    encounterID = encounterID or 3306  -- Chimaerus par défaut
    SM.Print(string.format("Test BossTimer pour encounterID=%d", encounterID))
    CancelAll()
    currentEncounterID = encounterID
    currentEncounterName = "TEST"
    pullTime = GetTime()
    ScheduleBossTimers(encounterID)
end
