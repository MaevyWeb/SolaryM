-- SolaryM_MemoryGame.lua
-- Memory Game L'ura (Midnight Falls)
-- Envoi : SecureActionButtonTemplate → macro /raid SOLMG:N (C-level, fonctionne en combat)
-- Réception : CHAT_MSG_RAID/PARTY — tous les clients affichent la map via l'écho

SM.MemoryGame = SM.MemoryGame or {}
local MG = SM.MemoryGame

local MEDIA_PATH = "Interface\\AddOns\\SolaryM\\Media\\"

MG.Runes = {
    { name="Ceinture",  tex=MEDIA_PATH.."inv_belt_39a.tga"           },
    { name="Bracelet",  tex=MEDIA_PATH.."inv_bracer_45green.tga"     },
    { name="Pantalon",  tex=MEDIA_PATH.."inv_pants_leather_10.tga"   },
    { name="Tissu",     tex=MEDIA_PATH.."inv_pants_cloth_38.tga"     },
    { name="Fusée",     tex=MEDIA_PATH.."ui_majorfaction_rocket.tga" },
}

local PX = { 50,  60,   0, -60, -50 }
local PY = { 50, -25, -70, -25,  50 }

local MG_TAG = "SOLMG:"  -- préfixe dans le raid/party chat

local mainFrame     = nil
local iconDisplay   = {}
local numDisplay    = {}
local sequence      = {}
local hideTimer     = nil
local sequenceOwner = nil

-- ============================================================
-- AFFICHAGE LOCAL — SetTexture/Show uniquement (pas de Create en combat)
-- ============================================================
local function DisplayRune(pos, runeIdx)
    if not mainFrame then return end
    local tex = MG.Runes[runeIdx] and MG.Runes[runeIdx].tex
    if not tex then return end
    if not iconDisplay[pos] or not numDisplay[pos] then return end
    iconDisplay[pos]:SetTexture(tex)
    iconDisplay[pos]:Show()
    numDisplay[pos]:SetText(tostring(pos))
    numDisplay[pos]:Show()
    mainFrame:Show()
    if hideTimer then hideTimer:Cancel() end
    hideTimer = C_Timer.NewTimer(30, function() LocalReset() end)
end

local function HideAll()
    for i = 1, 5 do
        if iconDisplay[i] then iconDisplay[i]:Hide() end
        if numDisplay[i]  then numDisplay[i]:Hide()  end
    end
end

-- ============================================================
-- RESET LOCAL (tous les clients)
-- ============================================================
function LocalReset()
    sequence      = {}
    sequenceOwner = nil
    HideAll()
    if mainFrame then mainFrame:Hide() end
    if hideTimer then hideTimer:Cancel(); hideTimer = nil end
end

-- ============================================================
-- FILTRES CHAT — masquer les messages SOLMG: dans le chat
-- (appliqués au chargement, avant tout combat, contexte propre)
-- ============================================================
ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID", function(_, _, msg)
    if msg:sub(1, #MG_TAG) == MG_TAG then return true end
end)
ChatFrame_AddMessageEventFilter("CHAT_MSG_RAID_LEADER", function(_, _, msg)
    if msg:sub(1, #MG_TAG) == MG_TAG then return true end
end)
ChatFrame_AddMessageEventFilter("CHAT_MSG_PARTY", function(_, _, msg)
    if msg:sub(1, #MG_TAG) == MG_TAG then return true end
end)

-- ============================================================
-- TRAITEMENT PAYLOAD (appelé localement ET depuis réception réseau)
-- ============================================================
local lastReceivedTime = {}

local function ProcessMGPayload(msg, senderName)
    if msg == "reset" then
        LocalReset(); return
    end
    if msg == "undo" then
        if sequenceOwner and sequenceOwner ~= senderName then return end
        local pos = #sequence
        if pos > 0 then
            table.remove(sequence, pos)
            if iconDisplay[pos] then iconDisplay[pos]:Hide() end
            if numDisplay[pos]  then numDisplay[pos]:Hide()  end
            if #sequence == 0 and mainFrame then mainFrame:Hide() end
        end
        return
    end
    local runeIdx = tonumber(msg)
    if not runeIdx or runeIdx < 1 or runeIdx > 5 then return end
    if not MG.Runes[runeIdx] then return end
    if sequenceOwner == nil then
        sequenceOwner = senderName
    elseif sequenceOwner ~= senderName then
        return
    end
    if #sequence >= 5 then return end
    local pos = #sequence + 1
    table.insert(sequence, runeIdx)
    DisplayRune(pos, runeIdx)
end

-- ============================================================
-- RÉCEPTION réseau (CHAT_MSG_RAID/PARTY)
-- ============================================================
local function OnMGMessage(msg, sender)
    local shortSender = (sender or ""):match("^([^%-]+)") or (sender or "")
    SM.Print("|cffffff00[MG-DEBUG] reçu: '"..tostring(msg).."' de '"..tostring(shortSender).."'|r")
    -- Dédup : ignorer l'écho du RL (déjà traité localement via PostClick)
    local key = shortSender .. ":" .. msg
    local t = lastReceivedTime[key]
    if t and (GetTime() - t) < 1.0 then return end
    lastReceivedTime[key] = GetTime()
    ProcessMGPayload(msg, shortSender)
end

local commFrame = CreateFrame("Frame")
commFrame:RegisterEvent("CHAT_MSG_RAID")
commFrame:RegisterEvent("CHAT_MSG_RAID_LEADER")
commFrame:RegisterEvent("CHAT_MSG_PARTY")
commFrame:RegisterEvent("ENCOUNTER_END")
commFrame:SetScript("OnEvent", function(_, event, msg, sender)
    if event == "ENCOUNTER_END" then
        C_Timer.NewTimer(3, LocalReset); return
    end
    if msg and msg:sub(1, #MG_TAG) == MG_TAG then
        OnMGMessage(msg:sub(#MG_TAG + 1), sender)
    end
end)

-- ============================================================
-- ENVOI réseau (hors combat uniquement — utilisé par l'API publique)
-- En combat, les boutons SecureActionButtonTemplate gèrent l'envoi via macro C-level.
-- ============================================================
local function BroadcastMG(payload)
    local payloadStr = tostring(payload)
    local myName = UnitName("player"):match("^([^%-]+)") or UnitName("player")

    ProcessMGPayload(payloadStr, myName)
    lastReceivedTime[myName .. ":" .. payloadStr] = GetTime()

    local channel = UnitInRaid("player") and "RAID" or (UnitInParty("player") and "PARTY" or nil)
    if not channel then return end

    local ok = pcall(C_ChatInfo.SendChatMessage, MG_TAG .. payloadStr, channel)
    if not ok then
        SM.Print("|cffff8800MG: envoi bloqué (combat). Utilise les boutons de la barre.|r")
    end
end

-- ============================================================
-- API publique (utilisée par le panel)
-- ============================================================
function MG.AddRune(runeIdx)
    if not SM.IsEditor() then return false end
    BroadcastMG(runeIdx)
    return true
end

function MG.RemoveLast()
    if not SM.IsEditor() then return end
    BroadcastMG("undo")
end

function MG.Reset()
    if not SM.IsEditor() then return end
    BroadcastMG("reset")
end

local mgInitFrame = CreateFrame("Frame")
mgInitFrame:RegisterEvent("PLAYER_LOGIN")
mgInitFrame:SetScript("OnEvent", function()
    MG.BuildDisplayFrame()
    MG.BuildInputBar()
    mgInitFrame:UnregisterAllEvents()
end)

-- ============================================================
-- DISPLAY FRAME — tous les textures pré-créés ici (avant combat)
-- ============================================================
function MG.BuildDisplayFrame()
    if mainFrame then return mainFrame end

    mainFrame = CreateFrame("Frame", "SolaryMMGFrame", UIParent, "BackdropTemplate")
    mainFrame:SetSize(200, 200)
    mainFrame:SetFrameStrata("HIGH")
    mainFrame:SetMovable(true)
    mainFrame:EnableMouse(true)
    mainFrame:RegisterForDrag("LeftButton")
    mainFrame:SetScript("OnDragStart", function(s) if MG.unlocked then s:StartMoving() end end)
    mainFrame:SetScript("OnDragStop", function(s)
        s:StopMovingOrSizing()
        local pt, _, rp, x, y = s:GetPoint()
        SolaryMDB.mg_pos = { point = pt, rp = rp, x = math.floor(x), y = math.floor(y) }
    end)
    mainFrame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    mainFrame:SetBackdropColor(0.05, 0.05, 0.08, 0.92)
    mainFrame:SetBackdropBorderColor(SM.OR[1], SM.OR[2], SM.OR[3], 0.6)

    local s = SolaryMDB and SolaryMDB.mg_pos
    if s and s.x then
        mainFrame:SetPoint(s.point or "CENTER", UIParent, s.rp or "CENTER", s.x, s.y)
    else
        mainFrame:SetPoint("CENTER", UIParent, "CENTER", 300, 0)
    end

    local bossBg = mainFrame:CreateTexture(nil, "ARTWORK")
    bossBg:SetSize(34, 34)
    bossBg:SetPoint("CENTER", mainFrame, "CENTER", 0, 0)
    bossBg:SetTexture("Interface\\Buttons\\WHITE8X8")
    bossBg:SetVertexColor(0.8, 0.08, 0.08, 1)

    local bossLbl = mainFrame:CreateFontString(nil, "OVERLAY")
    bossLbl:SetFont("Fonts\\FRIZQT__.TTF", 9, "OUTLINE")
    bossLbl:SetPoint("CENTER", mainFrame, "CENTER", 0, 0)
    bossLbl:SetTextColor(1, 1, 1, 1)
    bossLbl:SetText("BOSS")

    local tankIcon = mainFrame:CreateTexture(nil, "OVERLAY")
    tankIcon:SetSize(34, 34)
    tankIcon:SetPoint("CENTER", mainFrame, "CENTER", 0, 48)
    tankIcon:SetTexture("Interface\\AddOns\\SolaryM\\Media\\tank_icon.tga")

    -- Pré-créer les 5 slots avant tout combat
    for i = 1, 5 do
        iconDisplay[i] = mainFrame:CreateTexture(nil, "OVERLAY")
        iconDisplay[i]:SetSize(36, 36)
        iconDisplay[i]:SetPoint("CENTER", mainFrame, "CENTER", PX[i], PY[i])
        iconDisplay[i]:Hide()

        numDisplay[i] = mainFrame:CreateFontString(nil, "OVERLAY")
        numDisplay[i]:SetFont("Fonts\\FRIZQT__.TTF", 16, "OUTLINE")
        numDisplay[i]:SetTextColor(1, 1, 1, 1)
        numDisplay[i]:SetShadowColor(0, 0, 0, 1)
        numDisplay[i]:SetShadowOffset(1, -1)
        numDisplay[i]:SetPoint("CENTER", mainFrame, "CENTER", PX[i], PY[i] + 24)
        numDisplay[i]:Hide()
    end

    mainFrame:Hide()
    return mainFrame
end

-- ============================================================
-- BARRE FLOTTANTE (éditeur)
-- ============================================================
local inputBar = nil

function MG.BuildInputBar()
    if inputBar then return inputBar end
    local ICON, PAD = 40, 4
    local N = #MG.Runes
    local W = N * (ICON + PAD) + PAD
    local H = ICON + PAD * 2 + 20
    inputBar = CreateFrame("Frame", "SolaryMMGBar", UIParent, "BackdropTemplate")
    inputBar:SetSize(W, H); inputBar:SetFrameStrata("HIGH")
    inputBar:SetMovable(true); inputBar:EnableMouse(true)
    inputBar:RegisterForDrag("RightButton")
    inputBar:SetScript("OnDragStart", function(s) s:StartMoving() end)
    inputBar:SetScript("OnDragStop", function(s)
        s:StopMovingOrSizing()
        local pt, _, rp, x, y = s:GetPoint()
        SolaryMDB.mg_bar_pos = { point = pt, rp = rp, x = math.floor(x), y = math.floor(y) }
    end)
    inputBar:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
    inputBar:SetBackdropColor(0.05, 0.05, 0.08, 0.92)
    inputBar:SetBackdropBorderColor(SM.OR[1], SM.OR[2], SM.OR[3], 0.7)
    local bp = SolaryMDB and SolaryMDB.mg_bar_pos
    if bp and bp.x then
        inputBar:SetPoint(bp.point or "CENTER", UIParent, bp.rp or "CENTER", bp.x, bp.y)
    else
        inputBar:SetPoint("CENTER", UIParent, "CENTER", 0, -200)
    end

    -- Boutons parентés à UIParent (SecureActionButtonTemplate ne fonctionne qu'avec UIParent comme parent)
    -- SetPoint sur inputBar → les boutons suivent le drag automatiquement
    -- SetFrameLevel au dessus de inputBar pour recevoir les clics avant lui
    local mgBarBtns = {}
    local barLevel = inputBar:GetFrameLevel()
    SM.Print("|cffaaaaff[MG-BUILD] secure=" .. tostring(issecure()) .. " barLevel=" .. barLevel .. "|r")

    for i, rune in ipairs(MG.Runes) do
        local btn = CreateFrame("Button", "SolaryMMGRuneBtn" .. i, UIParent, "SecureActionButtonTemplate")
        btn:SetSize(ICON, ICON)
        btn:SetPoint("TOPLEFT", inputBar, "TOPLEFT", PAD + (i - 1) * (ICON + PAD), -PAD)
        btn:SetFrameStrata("HIGH")
        btn:SetFrameLevel(barLevel + 2)
        btn:RegisterForClicks("LeftButtonUp")
        btn:SetAttribute("type", "macro")
        btn:SetAttribute("macrotext", "/say MGTEST" .. i .. "\n/raid " .. MG_TAG .. i .. "\n/party " .. MG_TAG .. i)
        if i == 1 then
            SM.Print("|cffaaaaff[MG-BUILD] btn1 type=" .. tostring(btn:GetAttribute("type")) .. " macro=" .. tostring(btn:GetAttribute("macrotext")) .. "|r")
        end

        local t = btn:CreateTexture(nil, "ARTWORK"); t:SetAllPoints(); t:SetTexture(rune.tex)
        local hl = btn:CreateTexture(nil, "OVERLAY"); hl:SetAllPoints()
        hl:SetTexture("Interface\\Buttons\\WHITE8X8"); hl:SetVertexColor(1, 1, 1, 0)

        local runeIdx = i
        btn:SetScript("PostClick", function()
            SM.Print("|cff00ff00[MG] PostClick btn" .. runeIdx .. " fired (editor=" .. tostring(SM.IsEditor()) .. ")|r")
            if not SM.IsEditor() then return end
            local myName = UnitName("player"):match("^([^%-]+)") or UnitName("player")
            local key = myName .. ":" .. tostring(runeIdx)
            lastReceivedTime[key] = GetTime()
            ProcessMGPayload(tostring(runeIdx), myName)
            hl:SetVertexColor(0.2, 0.9, 0.2, 0.6)
            C_Timer.NewTimer(0.25, function() hl:SetVertexColor(1, 1, 1, 0) end)
        end)
        btn:SetScript("OnEnter", function() hl:SetVertexColor(SM.OR[1], SM.OR[2], SM.OR[3], 0.35) end)
        btn:SetScript("OnLeave", function() hl:SetVertexColor(1, 1, 1, 0) end)
        btn:Hide()
        table.insert(mgBarBtns, btn)
    end

    local bw = math.floor((W - PAD * 3) / 2)

    local resetBtn = CreateFrame("Button", "SolaryMMGResetBtn", UIParent, "SecureActionButtonTemplate")
    resetBtn:SetSize(bw, 16)
    resetBtn:SetPoint("BOTTOMLEFT", inputBar, "BOTTOMLEFT", PAD, PAD)
    resetBtn:SetFrameStrata("HIGH")
    resetBtn:SetFrameLevel(barLevel + 2)
    resetBtn:SetAttribute("type", "macro")
    resetBtn:SetAttribute("macrotext", "/raid " .. MG_TAG .. "reset\n/party " .. MG_TAG .. "reset")
    resetBtn:SetScript("PostClick", function()
        if not SM.IsEditor() then return end
        local myName = UnitName("player"):match("^([^%-]+)") or UnitName("player")
        lastReceivedTime[myName .. ":reset"] = GetTime()
        ProcessMGPayload("reset", myName)
    end)
    local rBg = resetBtn:CreateTexture(nil, "BACKGROUND"); rBg:SetAllPoints()
    rBg:SetTexture("Interface\\Buttons\\WHITE8X8"); rBg:SetVertexColor(0.55, 0.08, 0.08, 1)
    local rLbl = resetBtn:CreateFontString(nil, "OVERLAY")
    rLbl:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE"); rLbl:SetAllPoints()
    rLbl:SetJustifyH("CENTER"); rLbl:SetJustifyV("MIDDLE"); rLbl:SetText("Reset"); rLbl:SetTextColor(1, 1, 1, 1)
    resetBtn:Hide()
    table.insert(mgBarBtns, resetBtn)

    local undoBtn = CreateFrame("Button", "SolaryMMGUndoBtn", UIParent, "SecureActionButtonTemplate")
    undoBtn:SetSize(bw, 16)
    undoBtn:SetPoint("BOTTOMRIGHT", inputBar, "BOTTOMRIGHT", -PAD, PAD)
    undoBtn:SetFrameStrata("HIGH")
    undoBtn:SetFrameLevel(barLevel + 2)
    undoBtn:SetAttribute("type", "macro")
    undoBtn:SetAttribute("macrotext", "/raid " .. MG_TAG .. "undo\n/party " .. MG_TAG .. "undo")
    undoBtn:SetScript("PostClick", function()
        if not SM.IsEditor() then return end
        local myName = UnitName("player"):match("^([^%-]+)") or UnitName("player")
        lastReceivedTime[myName .. ":undo"] = GetTime()
        ProcessMGPayload("undo", myName)
    end)
    local uBg = undoBtn:CreateTexture(nil, "BACKGROUND"); uBg:SetAllPoints()
    uBg:SetTexture("Interface\\Buttons\\WHITE8X8"); uBg:SetVertexColor(0.1, 0.2, 0.5, 1)
    local uLbl = undoBtn:CreateFontString(nil, "OVERLAY")
    uLbl:SetFont("Fonts\\FRIZQT__.TTF", 10, "OUTLINE"); uLbl:SetAllPoints()
    uLbl:SetJustifyH("CENTER"); uLbl:SetJustifyV("MIDDLE"); uLbl:SetText("Annuler"); uLbl:SetTextColor(1, 1, 1, 1)
    undoBtn:Hide()
    table.insert(mgBarBtns, undoBtn)

    -- Propagation show/hide : quand la barre se montre/cache, les boutons suivent
    inputBar:HookScript("OnShow", function()
        for _, b in ipairs(mgBarBtns) do b:Show() end
    end)
    inputBar:HookScript("OnHide", function()
        for _, b in ipairs(mgBarBtns) do b:Hide() end
    end)

    inputBar:Hide()
    return inputBar
end

function MG.HasSequence()
    return #sequence > 0
end

-- Test sans boss : simule la réception de 5 runes
function MG.TestSequence()
    LocalReset()
    local order = { 3, 1, 5, 2, 4 }
    for i, runeIdx in ipairs(order) do
        C_Timer.NewTimer(i * 0.4, function()
            OnMGMessage(tostring(runeIdx), "TestSender-Test")
        end)
    end
    SM.Print("|cff00ff00MG test : simulation réception de 5 runes...|r")
end

function MG.ToggleInputBar()
    if not SM.IsEditor() then return end
    if not inputBar then MG.BuildInputBar() end
    if inputBar:IsShown() then inputBar:Hide() else inputBar:Show() end
end

-- ============================================================
-- INPUT PANEL (onglet panel)
-- ============================================================
function MG.BuildInputPanel(parent, w, h)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(w, h)
    local y = -14

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOPLEFT", f, "TOPLEFT", 14, y)
    title:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
    title:SetText("Memory Game — L'ura (Midnight Falls)")
    y = y - 22

    local sub = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    sub:SetPoint("TOPLEFT", f, "TOPLEFT", 14, y)
    sub:SetPoint("RIGHT", f, "RIGHT", -14, 0)
    sub:SetJustifyH("LEFT")
    sub:SetTextColor(0.45, 0.45, 0.5, 1)
    sub:SetText("Clique les icones dans l'ordre affiché par le boss — broadcasté au raid.")
    y = y - 30

    local function makeBtn(name, label, color, payload)
        local b = CreateFrame("Button", name, f, "SecureActionButtonTemplate")
        b:SetSize(100, 24)
        b:SetAttribute("type", "macro")
        b:SetAttribute("macrotext", "/raid " .. MG_TAG .. payload .. "\n/party " .. MG_TAG .. payload)
        b:SetScript("PostClick", function()
            if not SM.IsEditor() then return end
            local myName = UnitName("player"):match("^([^%-]+)") or UnitName("player")
            lastReceivedTime[myName .. ":" .. payload] = GetTime()
            ProcessMGPayload(payload, myName)
        end)
        local bg = b:CreateTexture(nil, "BACKGROUND"); bg:SetAllPoints()
        bg:SetTexture("Interface\\Buttons\\WHITE8X8"); bg:SetVertexColor(unpack(color))
        local lbl = b:CreateFontString(nil, "OVERLAY")
        lbl:SetFont("Fonts\\FRIZQT__.TTF", 11, "OUTLINE"); lbl:SetAllPoints()
        lbl:SetJustifyH("CENTER"); lbl:SetJustifyV("MIDDLE"); lbl:SetText(label); lbl:SetTextColor(1, 1, 1, 1)
        return b
    end

    makeBtn("SolaryMMGPanelReset", "Reset", { 0.55, 0.08, 0.08, 1 }, "reset")
        :SetPoint("TOPLEFT", f, "TOPLEFT", 14, y)

    makeBtn("SolaryMMGPanelUndo", "Annuler dernier", { 0.1, 0.2, 0.5, 1 }, "undo")
        :SetPoint("TOPLEFT", f, "TOPLEFT", 122, y)
    y = y - 36

    local sep = f:CreateTexture(nil, "ARTWORK")
    sep:SetSize(w - 28, 1)
    sep:SetPoint("TOPLEFT", f, "TOPLEFT", 14, y)
    sep:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.3)
    y = y - 14

    local hint = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("TOPLEFT", f, "TOPLEFT", 14, y)
    hint:SetTextColor(0.45, 0.45, 0.5, 1)
    hint:SetText("Clique les icones dans l'ordre :")
    y = y - 24

    local ICON_SIZE = 52
    local PADDING   = 10
    local perRow    = math.floor((w - 28) / (ICON_SIZE + PADDING))
    local col, row  = 0, 0

    for i, rune in ipairs(MG.Runes) do
        local btn = CreateFrame("Button", "SolaryMMGPanelRuneBtn" .. i, f, "SecureActionButtonTemplate")
        btn:SetSize(ICON_SIZE, ICON_SIZE)
        btn:SetPoint("TOPLEFT", f, "TOPLEFT",
            14 + col * (ICON_SIZE + PADDING),
            y  - row * (ICON_SIZE + PADDING + 16))
        btn:SetAttribute("type", "macro")
        btn:SetAttribute("macrotext", "/raid " .. MG_TAG .. i .. "\n/party " .. MG_TAG .. i)

        local tex = btn:CreateTexture(nil, "ARTWORK")
        tex:SetAllPoints(); tex:SetTexture(rune.tex)

        local border = btn:CreateTexture(nil, "BACKGROUND")
        border:SetAllPoints()
        border:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.12)

        local nameLbl = btn:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        nameLbl:SetPoint("TOP", btn, "BOTTOM", 0, -2)
        nameLbl:SetText(rune.name)
        nameLbl:SetTextColor(0.6, 0.6, 0.65, 1)

        btn:SetScript("OnEnter", function() border:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.4) end)
        btn:SetScript("OnLeave", function() border:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.12) end)

        local runeIdx = i
        btn:SetScript("PostClick", function()
            if not SM.IsEditor() then return end
            local myName = UnitName("player"):match("^([^%-]+)") or UnitName("player")
            local key = myName .. ":" .. tostring(runeIdx)
            lastReceivedTime[key] = GetTime()
            ProcessMGPayload(tostring(runeIdx), myName)
            border:SetColorTexture(0.2, 0.85, 0.2, 0.6)
            C_Timer.NewTimer(0.3, function() border:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.12) end)
        end)

        col = col + 1
        if col >= perRow then col = 0; row = row + 1 end
    end

    return f
end

-- ============================================================
-- TEST DIAGNOSTIC — /mgtest crée un bouton SecureActionButtonTemplate
-- isolé sur UIParent pour vérifier si le mécanisme fonctionne en combat
-- ============================================================
SLASH_MGTEST1 = "/mgtest"
SlashCmdList["MGTEST"] = function()
    if _G["SolaryMMGTestBtn"] then
        _G["SolaryMMGTestBtn"]:Show()
        SM.Print("Bouton test déjà créé — visible au centre de l'écran.")
        return
    end
    local b = CreateFrame("Button", "SolaryMMGTestBtn", UIParent, "SecureActionButtonTemplate")
    b:SetSize(120, 40)
    b:SetPoint("CENTER", UIParent, "CENTER", 0, 200)
    b:SetAttribute("type", "macro")
    b:SetAttribute("macrotext", "/raid SOLMG:TEST\n/party SOLMG:TEST")
    b:SetScript("PostClick", function()
        SM.Print("|cff00ff00[MGTEST] PostClick fired — macro executée!|r")
    end)
    local bg = b:CreateTexture(nil, "BACKGROUND"); bg:SetAllPoints()
    bg:SetColorTexture(1, 0.3, 0, 0.9)
    local lbl = b:CreateFontString(nil, "OVERLAY")
    lbl:SetFont("Fonts\\FRIZQT__.TTF", 12, "OUTLINE"); lbl:SetAllPoints()
    lbl:SetJustifyH("CENTER"); lbl:SetJustifyV("MIDDLE")
    lbl:SetText("MG TEST\nClique en combat!")
    lbl:SetTextColor(1, 1, 1, 1)
    SM.Print("Bouton test créé au centre — clique-le en combat pour tester SecureActionButtonTemplate.")
end
