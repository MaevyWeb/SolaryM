-- SolaryM_PersonalNotes.lua
-- Notes texte libres, personnelles, non partagées.
-- Format : SolaryMDB.personal_notes = { {name="", text=""}, ... }
-- Entry-point : SM.PersonalNotes.BuildTab(parent, W, H) → Frame

SM.PersonalNotes = SM.PersonalNotes or {}
local PN = SM.PersonalNotes

local LIST_W  = 260
local PAD     = 10
local ROW_H   = 28
local ROW_GAP = 2

function PN.BuildTab(parent, W, H)
    local f = CreateFrame("Frame", nil, parent)
    f:SetSize(W, H)
    f:Hide()

    -- ── State ──────────────────────────────────────────────────
    local selectedIdx = nil
    local rowObjects  = {}

    local listScroll, listScrollBar, listChild
    local nameBox, textBox, edScroll, noSelLbl

    -- ── Data ───────────────────────────────────────────────────
    local function getNotes()
        if not SolaryMDB then return {} end
        SolaryMDB.personal_notes = SolaryMDB.personal_notes or {}
        return SolaryMDB.personal_notes
    end

    local function flushCurrent()
        if not selectedIdx then return end
        local note = getNotes()[selectedIdx]
        if not note then return end
        note.name = nameBox:GetText()
        note.text = textBox:GetText()
    end

    local function refreshHighlights()
        for i, ro in ipairs(rowObjects) do
            if i == selectedIdx then
                ro.sel:SetAlpha(1)
                ro.accent:Show()
                ro.lbl:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
            else
                ro.sel:SetAlpha(0)
                ro.accent:Hide()
                ro.lbl:SetTextColor(0.88, 0.88, 0.90, 1)
            end
        end
    end

    local function selectNote(idx)
        selectedIdx = idx
        local note = getNotes()[idx]
        if note then
            nameBox:SetText(note.name or "")
            nameBox:SetTextColor(1, 1, 1, 1)
            textBox:SetText(note.text or "")
            noSelLbl:Hide()
            nameBox:Show()
        else
            nameBox:SetText("")
            textBox:SetText("")
        end
        refreshHighlights()
    end

    local scrollW = LIST_W - PAD * 2 - 16

    local function rebuildList()
        for _, ro in ipairs(rowObjects) do ro.btn:Hide() end
        rowObjects = {}
        local notes  = getNotes()
        local totalH = 0

        for i, note in ipairs(notes) do
            local btn = CreateFrame("Button", nil, listChild)
            btn:SetSize(scrollW, ROW_H)
            btn:SetPoint("TOPLEFT", listChild, "TOPLEFT", 0, -totalH)

            -- Hover highlight
            btn:SetHighlightTexture([[Interface\Buttons\UI-Listbox-Highlight2]])
            local hlt = btn:GetHighlightTexture()
            if hlt then hlt:SetBlendMode("ADD"); hlt:SetAlpha(0.25) end

            -- Selected background overlay
            local sel = btn:CreateTexture(nil, "BACKGROUND")
            sel:SetPoint("LEFT",   btn, "LEFT",   2, 0)
            sel:SetPoint("RIGHT",  btn, "RIGHT",  0, 0)
            sel:SetPoint("TOP",    btn, "TOP",    0, 0)
            sel:SetPoint("BOTTOM", btn, "BOTTOM", 0, 0)
            sel:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.16)
            sel:SetAlpha(i == selectedIdx and 1 or 0)

            -- Left accent stripe (2px, full opacity when selected)
            local accent = btn:CreateTexture(nil, "ARTWORK")
            accent:SetWidth(2)
            accent:SetPoint("TOPLEFT",    btn, "TOPLEFT",    0, 0)
            accent:SetPoint("BOTTOMLEFT", btn, "BOTTOMLEFT", 0, 0)
            accent:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 1)
            if i == selectedIdx then accent:Show() else accent:Hide() end

            local lbl = btn:CreateFontString(nil, "OVERLAY")
            lbl:SetFont("Fonts\\ARIALN.TTF", 13, "")
            lbl:SetPoint("LEFT",  btn, "LEFT",  10, 0)
            lbl:SetPoint("RIGHT", btn, "RIGHT", -4, 0)
            lbl:SetJustifyH("LEFT")
            lbl:SetJustifyV("MIDDLE")
            lbl:SetText((note.name and note.name ~= "") and note.name or ("Note " .. i))
            if i == selectedIdx then
                lbl:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
            else
                lbl:SetTextColor(0.88, 0.88, 0.90, 1)
            end

            local ci = i
            btn:SetScript("OnClick", function()
                flushCurrent()
                selectNote(ci)
            end)

            rowObjects[i] = {btn=btn, sel=sel, accent=accent, lbl=lbl}
            totalH = totalH + ROW_H + ROW_GAP
        end

        listChild:SetHeight(math.max(totalH, 1))
        local sh = listScroll:GetHeight()
        local maxScroll = sh > 0 and math.max(0, totalH - sh) or 0
        listScrollBar:SetMinMaxValues(0, maxScroll)
        if listScrollBar:GetValue() > maxScroll then listScrollBar:SetValue(maxScroll) end
    end

    -- ── Left panel ─────────────────────────────────────────────
    local panelH = H - PAD * 2

    local listBg = CreateFrame("Frame", nil, f, "BackdropTemplate")
    listBg:SetPoint("TOPLEFT", f, "TOPLEFT", PAD, -PAD)
    listBg:SetSize(LIST_W, panelH)
    listBg:SetBackdrop({bgFile=[[Interface\Tooltips\UI-Tooltip-Background]], tile=true, tileSize=64})
    listBg:SetBackdropColor(0.07, 0.07, 0.10, 1)

    -- Right-edge divider
    local divider = listBg:CreateTexture(nil, "OVERLAY")
    divider:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.22)
    divider:SetWidth(1)
    divider:SetPoint("TOPRIGHT",    listBg, "TOPRIGHT",    0, 0)
    divider:SetPoint("BOTTOMRIGHT", listBg, "BOTTOMRIGHT", 0, 0)

    local hdr = listBg:CreateFontString(nil, "OVERLAY")
    hdr:SetFont("Fonts\\ARIALN.TTF", 13, "")
    hdr:SetTextColor(SM.OR[1], SM.OR[2], SM.OR[3], 1)
    hdr:SetText("Mes notes")
    hdr:SetPoint("TOPLEFT", listBg, "TOPLEFT", PAD, -PAD)

    local hdrSep = listBg:CreateTexture(nil, "ARTWORK")
    hdrSep:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.20)
    hdrSep:SetHeight(1)
    hdrSep:SetPoint("TOPLEFT",  listBg, "TOPLEFT",  0,     -(PAD + 18))
    hdrSep:SetPoint("TOPRIGHT", listBg, "TOPRIGHT", 0,     -(PAD + 18))

    -- Bottom action buttons
    local btnW = math.floor((LIST_W - PAD * 2 - 4) / 2)

    local newBtn = SM.OBtn(listBg, btnW, 24, "+ Nouvelle note", function()
        flushCurrent()
        table.insert(getNotes(), {name="Nouvelle note", text=""})
        rebuildList()
        selectNote(#getNotes())
    end)
    newBtn:SetPoint("BOTTOMLEFT", listBg, "BOTTOMLEFT", PAD, PAD)

    local delBtn = SM.RBtn(listBg, btnW, 24, "Supprimer", function()
        if not selectedIdx then return end
        flushCurrent()
        table.remove(getNotes(), selectedIdx)
        selectedIdx = nil
        nameBox:SetText("")
        textBox:SetText("")
        noSelLbl:Show()
        rebuildList()
    end)
    delBtn:SetPoint("BOTTOMRIGHT", listBg, "BOTTOMRIGHT", -PAD, PAD)

    -- Scrollable list
    local scrollTop   = PAD + 18 + 6
    local scrollBtm   = 24 + PAD * 2
    local scrollAreaH = panelH - scrollTop - scrollBtm

    listScroll = CreateFrame("ScrollFrame", nil, listBg)
    listScroll:SetPoint("TOPLEFT", listBg, "TOPLEFT", PAD, -scrollTop)
    listScroll:SetSize(scrollW, scrollAreaH)

    listScrollBar = CreateFrame("Slider", nil, listBg, "UIPanelScrollBarTemplate")
    listScrollBar:SetPoint("TOPLEFT",    listScroll, "TOPRIGHT",    2, -16)
    listScrollBar:SetPoint("BOTTOMLEFT", listScroll, "BOTTOMRIGHT", 2,  16)
    listScrollBar:SetMinMaxValues(0, 0)
    listScrollBar:SetValueStep(ROW_H)
    listScrollBar:SetScript("OnValueChanged", function(_, val)
        listScroll:SetVerticalScroll(val)
    end)
    listScrollBar:SetValue(0)
    listScroll:EnableMouseWheel(true)
    listScroll:SetScript("OnMouseWheel", function(_, delta)
        local cur    = listScrollBar:GetValue()
        local lo, hi = listScrollBar:GetMinMaxValues()
        listScrollBar:SetValue(math.max(lo, math.min(hi, cur - delta * ROW_H * 3)))
    end)

    listChild = CreateFrame("Frame", nil, listScroll)
    listChild:SetSize(scrollW, 1)
    listScroll:SetScrollChild(listChild)

    -- ── Right panel ────────────────────────────────────────────
    local edX = LIST_W + PAD * 2
    local edW = W - edX - PAD

    local editorBg = CreateFrame("Frame", nil, f, "BackdropTemplate")
    editorBg:SetPoint("TOPLEFT", f, "TOPLEFT", edX, -PAD)
    editorBg:SetSize(edW, panelH)
    editorBg:SetBackdrop({bgFile=[[Interface\Tooltips\UI-Tooltip-Background]], tile=true, tileSize=64})
    editorBg:SetBackdropColor(0.07, 0.07, 0.10, 1)

    -- Placeholder when nothing is selected
    noSelLbl = editorBg:CreateFontString(nil, "OVERLAY")
    noSelLbl:SetFont("Fonts\\ARIALN.TTF", 14, "")
    noSelLbl:SetPoint("CENTER", editorBg, "CENTER", 0, 20)
    noSelLbl:SetText("Selectionne ou cree une note")
    noSelLbl:SetTextColor(0.32, 0.32, 0.36, 1)
    noSelLbl:Show()

    -- Name editbox
    nameBox = CreateFrame("EditBox", nil, editorBg, "InputBoxTemplate")
    nameBox:SetPoint("TOPLEFT", editorBg, "TOPLEFT", PAD + 4, -PAD)
    nameBox:SetSize(edW - PAD * 2 - 8, 24)
    nameBox:SetFont("Fonts\\ARIALN.TTF", 15, "")
    nameBox:SetAutoFocus(false)
    nameBox:SetMaxLetters(128)
    nameBox:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
    nameBox:SetScript("OnEditFocusLost", function(s)
        local note = getNotes()[selectedIdx]
        if note then
            note.name = s:GetText()
            rebuildList()
        end
    end)

    -- Separator under name
    local edSep = editorBg:CreateTexture(nil, "ARTWORK")
    edSep:SetColorTexture(SM.OR[1], SM.OR[2], SM.OR[3], 0.20)
    edSep:SetHeight(1)
    edSep:SetPoint("TOPLEFT",  editorBg, "TOPLEFT",  PAD,  -(PAD + 24 + 6))
    edSep:SetPoint("TOPRIGHT", editorBg, "TOPRIGHT", -PAD, -(PAD + 24 + 6))

    -- Body scrollframe + editbox
    edScroll = CreateFrame("ScrollFrame", nil, editorBg, "UIPanelScrollFrameTemplate")
    edScroll:SetPoint("TOPLEFT",     editorBg, "TOPLEFT",      PAD,       -(PAD + 24 + 10))
    edScroll:SetPoint("BOTTOMRIGHT", editorBg, "BOTTOMRIGHT", -(PAD + 18),  PAD + 30)

    textBox = CreateFrame("EditBox", nil, edScroll)
    textBox:SetMultiLine(true)
    textBox:SetAutoFocus(false)
    textBox:SetFont("Fonts\\ARIALN.TTF", 13, "")
    textBox:SetMaxLetters(0)
    textBox:SetWidth(edW - PAD * 2 - 20)
    textBox:SetTextColor(0.88, 0.88, 0.92, 1)
    textBox:SetScript("OnEscapePressed", function(s) s:ClearFocus() end)
    textBox:SetScript("OnTextChanged", function(s)
        local w = edScroll:GetWidth()
        if w > 0 then s:SetWidth(w) end
    end)
    edScroll:SetScrollChild(textBox)
    edScroll:SetScript("OnSizeChanged", function(s, w)
        if w > 0 then textBox:SetWidth(w) end
    end)
    edScroll:SetScript("OnMouseDown", function() textBox:SetFocus() end)

    -- Save button
    local saveBtn = SM.OBtn(editorBg, 140, 24, "Sauvegarder", function()
        flushCurrent()
        rebuildList()
    end)
    saveBtn:SetPoint("BOTTOMRIGHT", editorBg, "BOTTOMRIGHT", -PAD, PAD)

    -- ── Lifecycle ──────────────────────────────────────────────
    f:HookScript("OnShow", function() rebuildList() end)
    f:HookScript("OnHide", function() flushCurrent() end)

    rebuildList()
    return f
end
